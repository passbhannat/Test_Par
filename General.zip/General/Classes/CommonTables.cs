﻿namespace General.Classes
{ 
    public static class CommonTables
    {
        public const string ItemMasterTable = "OITM";
        public const string ItemGroupMasterTable = "OITB";

    }
}
 