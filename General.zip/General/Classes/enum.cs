﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace General.Classes
{
    public enum YesNoEnum
    {
        [Description("Yes")]
        Y,
        [Description("No")]
        N,
    }

    public enum SAPButtonEnum
    {
        Add = 1,
        Cancel = 2,
    }

    public enum SAPMenuEnum
    {
        AddRecord = 1282,
        FindRecord = 1281,
        FirstRecord = 1290,
        LastRecord = 1291,
        NextRecord = 1288,
        PreviousRecord = 1289,
        RemoveRecord = 1283,
        CancelRecord = 1284,
        DuplicateRecord = 1287,
        AddRow = 1292,
        DeleteRow = 1293,
        UDFForm = 6913,
        SystemInitialisation = 8192,
        SalesAR = 2048,
        Modules = 43520
    }

    public enum SAPFormUIDEnum
    {
        MainMenu = 169,
        BusinessPartner = 134,
        ServiceContract = 60126,

        SalesOrder = 139,
        ARInvoice = 133,
        PurchaseOrder = 142,
        GRPO = 143,
        APInvoice = 141,
        GoodsReceipt = 721,
        ProductionOrder = 65211,
        ReceiptFromProduction = 65214,
        IncomingPayment = 170,
        OutgoingPayment = 426,
        BatchInWard = 41,
        SerialInWard = 21
    }

    public enum SAPCustomFormUIDEnum
    { 

        [Description("Create UDO")]
        GENERAL_UDO,
    }

    public enum SAPFieldEnum
    {
        CardCode,
        ItemCode
    }

    public enum SAPUDFFieldType
    {
        Alpha,
        Text,
        Integer,
        Date,
        Time,
        Amount,
        Quantity,
        Percent,
        UnitTotal,
        Rate,
        Price,
        Link,
        YN,
        BarCodeType,
        TransactionType,
        ProcessType,
        ActivityType,
        NumberType
    }

    public enum SAPMaskModeEnum
    {
        All = -1,
        Ok = 1,
        Add = 2,
        Find = 4,
        View = 8
    }

    public enum TableType
    {
        StandardTable,
        CustomTable
    }

    public enum TransactionTypeEnum
    {
        [Description("CS")]
        ChemicalSlurry,
        [Description("CC")]
        ChemicalCoating,
        [Description("CA")]
        Calendering,
        [Description("SL")]
        Slitting,
        [Description("CT")]
        Cutting,
        [Description("PA")]
        Packing
    }


}
