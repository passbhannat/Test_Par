using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using General.Classes;
using General.Extensions;

namespace General
{
    class clsServiceContract : Connection
    {
        #region Variables

        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        StringBuilder sbQuery = new StringBuilder();
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        const string formTitle = "Service Contract";
        const string headerTable = "OCTR";

        const string matrixItem = "54";
        const string matrixItemGroupUID = "6";
        const string matrixItemCodeUDF = "U_ItemCode";
        const string matrixItemCodeCFL = "CFL_Item";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "1")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {

                                }
                            }
                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == matrixItem)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (pVal.ColUID == matrixItemCodeUDF)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixItem).Specific;

                                    string itmsGrpCode = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixItemGroupUID, pVal.Row)).Value.Trim();
                                    SAPbouiCOM.DataTable oDataTable = null;
                                    SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                                    oDataTable = oCFLEvento.SelectedObjects;
                                    string sCFL_ID = oCFLEvento.ChooseFromListUID;
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    temp = new ArrayList();
                                    temp = new ArrayList();
                                    temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                    temp.Add(CommonFields.ItmsGrpCod); //Condition Alias             
                                    temp.Add(itmsGrpCode); //Condition Value
                                    temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                    alCondVal.Add(temp);

                                    objclsComman.AddChooseFromList_WithCond(oForm, sCFL_ID, "", "", "", alCondVal);
                                }
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixItem).Specific;
                            //  oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixItemCodeUDF, 1);
                            SAPbouiCOM.Column oColumn = (SAPbouiCOM.Column)oMatrix.Columns.Item(matrixItemCodeUDF);
                            ArrayList alCondVal = new ArrayList();
                            objclsComman.AddChooseFromList_WithCond(oForm, matrixItemCodeCFL, "4", "", CommonFields.DocEntry, alCondVal);
                            oColumn.ChooseFromListUID = matrixItemCodeCFL;
                            oColumn.ChooseFromListAlias = CommonFields.ItemCode;
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                        }
                        #endregion

                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ColUID == matrixItemCodeUDF)
                            {
                                oForm = oApplication.Forms.GetFormByTypeAndCount(pVal.FormType, pVal.FormTypeCount);

                                SAPbouiCOM.ChooseFromListCollection oCFLs = null;

                                oCFLs = oForm.ChooseFromLists;

                                SAPbouiCOM.IChooseFromListEvent oCFLEvento = null;
                                oCFLEvento = ((SAPbouiCOM.IChooseFromListEvent)(pVal));
                                string sCFL_ID = null;
                                sCFL_ID = oCFLEvento.ChooseFromListUID;

                                SAPbouiCOM.ChooseFromList oCFL = null;
                                oCFL = oForm.ChooseFromLists.Item(sCFL_ID);
                                SAPbouiCOM.DataTable oDataTable = null;
                                oDataTable = oCFLEvento.SelectedObjects;

                                if (oDataTable != null)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixItem).Specific;
                                    string selectedItemCode = oDataTable.GetValue("ItemCode", 0).ToString();
                                    sbQuery.Length = 0;
                                    sbQuery.Append(" SELECT \"U_DomainName\",\"U_Suffix\",\"U_Country\",\"U_LocalPresence_P\",\"U_LocalPresence_B\",\"U_WHOISprivacy_P\", ");
                                    sbQuery.Append(" \"U_WHOISprivacy_B\",\"U_OwnerContact\",\"U_AdminContact\",\"U_TechContact\",\"U_BillingContact\",\"U_DNS\", ");
                                    sbQuery.Append(" \"U_Status\",\"U_Createdon\",\"U_Renewaldate\",\"U_Transferdate\",\"U_Whoordered\",\"U_Ordernumber\",\"U_Notes\" ");
                                    sbQuery.Append(" FROM OITM T0 ");
                                    sbQuery.Append(" WHERE \"" + CommonFields.ItemCode + "\" = '" + selectedItemCode + "'");

                                    SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_DomainName", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_DomainName").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Country", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_Country").Value.ToString();
                                    }
                                    catch { }

                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LocalPresence_P", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_LocalPresence_P").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_LocalPresence_B", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_LocalPresence_B").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_WHOISprivacy_P", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_WHOISprivacy_P").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_WHOISprivacy_B", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_WHOISprivacy_B").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_OwnerContact", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_OwnerContact").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_AdminContact", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_AdminContact").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_TechContact", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_TechContact").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_BillingContact", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_BillingContact").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_DNS", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_DNS").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Status", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_Status").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Createdon", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_Createdon").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Renewaldate", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_Renewaldate").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Transferdate", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_Transferdate").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Whoordered", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_Whoordered").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Ordernumber", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_Ordernumber").Value.ToString();
                                    }
                                    catch { }
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("U_Notes", pVal.Row);
                                        oEdit.String = oRs.Fields.Item("U_Notes").Value.ToString();
                                    }
                                    catch { }

                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixItemCodeUDF, pVal.Row);
                                        oEdit.String = selectedItemCode;
                                    }
                                    catch { }

                                }
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(formTitle + " Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

    }
}
