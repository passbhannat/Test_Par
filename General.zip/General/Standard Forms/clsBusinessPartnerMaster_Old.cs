using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using General.Classes;
using General.Extensions;

namespace General
{
    class clsBusinessPartnerMaster : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        const string formTypEx = "134";
        const string formTitle = "Business Partner Master";
        const string headerTable = "OCRD";

        const string typeUDF = "U_Type";
        const string typeUID = "Type";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == "1")
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string type = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(typeUDF, 0).Trim();
                                    if (type == string.Empty)
                                    {
                                        oApplication.StatusBar.SetText("Please select type", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                    SetCardCode(oForm.UniqueID);
                                }
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            SAPbouiCOM.Item oNewItem;
                            SAPbouiCOM.Item oItem;
                            oNewItem = oForm.Items.Add("lblType", SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item("40");
                            SAPbouiCOM.StaticText oStatic = (SAPbouiCOM.StaticText)oNewItem.Specific;
                            oStatic.Caption = "Type";
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left + oItem.Width;

                            oNewItem = oForm.Items.Add(typeUID, SAPbouiCOM.BoFormItemTypes.it_COMBO_BOX);
                            oItem = oForm.Items.Item("lblType");
                            oNewItem.Top = oForm.Items.Item("lblType").Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left + oItem.Width;
                            oNewItem.DisplayDesc = true;
                            oCombo = (SAPbouiCOM.ComboBox)oNewItem.Specific;
                            oCombo.DataBind.SetBound(true, headerTable, typeUDF);

                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == typeUID)
                            {
                                SetCardCode(oForm.UniqueID);
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(formTitle + " Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("CardCode", 0);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        private void SetCardCode(string formUID)
        {
            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(formUID);

            string type = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(typeUDF, 0);
            string autoNo = objclsComman.SelectRecord("SELECT MAX(Cast(\"CardCode\" as numeric(18))) + 1 FROM OCRD WHERE \"U_Type\" = '" + type + "' ");
            if (autoNo == string.Empty || autoNo == "0")
            {
                autoNo = objclsComman.SelectRecord("SELECT U_StartNo FROM \"@NUMBERING\" WHERE \"Code\" = '" + type + "' ");
            }
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("5").Specific;
            oEdit.String = autoNo;
        }
    }
}
