using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using Production.Classes;

namespace Production
{
    class clsDailyPlanItemSelection : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.DBDataSource oDBDataSource;
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Grid oGrid;
        SAPbouiCOM.EditText oEdit;

        const string formTypeEx = "DAILYPLANITEM";
        const string formMenuUID = "DAILYPLANITEM";
        const string gridUID = "grd1";
        const string gridDataTableUID = "grdDT";
        const string rowNoUID = "RowNo";
        const string machineCodeUID = "MacCode";
        const string soDocEntryUID = "SODocEntry";
        const string soItemCodeUID = "SOItemCode";


        const string buttonChoose = "btnChoose";
        const string buttonGetPlanQty = "btnGetPQty";

        StringBuilder sbQuery = new StringBuilder();

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Select
                            if (pVal.ItemUID == buttonChoose)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDT = oForm.DataSources.DataTables.Item(gridDataTableUID);
                                string barCode = string.Empty;
                                List<clsBOMEntity> list = new List<clsBOMEntity>();
                                for (int i = 0; i < oDT.Rows.Count; i++)
                                {
                                    if (oDT.GetValue("Chk", i) == "Y")
                                    {
                                        list.Add(new clsBOMEntity()
                                        {
                                            SOItemCode = oDT.GetValue("SOItemCode", i),
                                            ItemCode = oDT.GetValue("ItemCode", i),
                                            Qty = oDT.GetValue("SOQuantity", i).ToString(),
                                            PlanQty = oDT.GetValue("PlanQty", i).ToString(),
                                        });
                                    }
                                }
                                if (list.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("No row selected", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                //if (list.Count > 1)
                                //{
                                //    oApplication.StatusBar.SetText("Please select only 1 row", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                //    return;
                                //}

                                int rowNo = int.Parse(oForm.DataSources.UserDataSources.Item(rowNoUID).Value.ToString());
                                string soDocEntry = oForm.DataSources.UserDataSources.Item(soDocEntryUID).Value.ToString();
                                string machineCode = oForm.DataSources.UserDataSources.Item(machineCodeUID).Value.ToString();
                                double planQty = double.Parse(list[0].PlanQty);
                                if (planQty == 0)
                                {
                                    oApplication.StatusBar.SetText("Plan Quantity is already completed", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                oForm.Items.Item("2").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                SAPbouiCOM.Form oBaseForm = oApplication.Forms.Item(clsVariables.BaseFormUID);
                                SAPbouiCOM.Matrix oBaseMatrix = (SAPbouiCOM.Matrix)oBaseForm.Items.Item("mtx").Specific;
                                oBaseMatrix.FlushToDataSource();

                                for (int i = 0; i < list.Count; i++)
                                {
                                    string itemCode = list[i].ItemCode;
                                    if (i > 0)
                                    {
                                        string odNo = oDBDataSource.GetValue(clsDailyPlan.matrixAdviceNoColumnUDF, rowNo - 1);
                                        string odEn = oDBDataSource.GetValue(clsDailyPlan.matrixAdviceDocEntryColumnUDF, rowNo - 1);
                                        string odDate = oDBDataSource.GetValue(clsDailyPlan.matrixAdviceDateColumnUDF, rowNo - 1);

                                        oDBDataSource.InsertRecord(rowNo);
                                        rowNo++;

                                        oDBDataSource.SetValue(clsDailyPlan.matrixAdviceNoColumnUDF, rowNo - 1, odNo);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixAdviceDocEntryColumnUDF, rowNo - 1, odEn);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixAdviceDateColumnUDF, rowNo - 1, odDate);

                                    }
                                    sbQuery = new StringBuilder();
                                    sbQuery.Append(" SELECT T0.\"" + clsMachineMaster.ProcessUDF + "\",T1.* ");
                                    sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                    sbQuery.Append(" INNER JOIN \"" + clsMachineMaster.rowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\" = T1.\"" + CommonFields.Code + "\" ");
                                    sbQuery.Append(" WHERE T0.\"" + CommonFields.Code + "\" = '" + machineCode + "' ");
                                    sbQuery.Append(" AND T1.\"" + clsDailyPlan.matrixProductCodeColumnUDF + "\" = '" + itemCode + "' ");
                                    SAPbobsCOM.Recordset oRsMachine = objclsComman.returnRecord(sbQuery.ToString());
                                    //if (oRsMachine.RecordCount == 0)
                                    //{
                                    //    oApplication.StatusBar.SetText("Item is not linked with machine master", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    //    BubbleEvent = false;
                                    //    return;
                                    //}
                                    string process = oRsMachine.Fields.Item(clsMachineMaster.ProcessUDF).Value;
                                    string defTime = objclsComman.SelectRecord("SELECT \"U_DefTime\" FROM \"@PROCESSMASTER\" WHERE \"" + CommonFields.Code + "\" = '" + process + "'");
                                    string scrapRate = objclsComman.SelectRecord("SELECT \"" + clsDailyPlan.Budgted_Scrap_RateUDF + "\" FROM OITM WHERE \"" + CommonFields.ItemCode + "\" ='" + list[i].SOItemCode + "' ");
                                    string exSize = objclsComman.SelectRecord("SELECT \"U_EXTSIZE\" FROM OITM WHERE \"" + CommonFields.ItemCode + "\" ='" + list[i].SOItemCode + "' ");

                                    string salUOM = objclsComman.SelectRecord("SELECT SalUnitMsr FROM OITM WHERE \"" + CommonFields.ItemCode + "\" ='" + list[i].SOItemCode + "' ");

                                    double dblScrapRate = scrapRate == string.Empty ? 0 : double.Parse(scrapRate);
                                    dblScrapRate = dblScrapRate == 0 ? 0 : dblScrapRate;
                                    double dblQuantity = double.Parse(list[i].PlanQty);
                                    double dblPackQty = 0;
                                    oDBDataSource = oBaseForm.DataSources.DBDataSources.Item(clsDailyPlan.rowTable);

                                    if (salUOM.ToLower() == "nos")
                                    {
                                        string thousand = objclsComman.SelectRecord("SELECT U_WTPERTHSD FROM OITM WHERE \"" + CommonFields.ItemCode + "\" ='" + list[i].SOItemCode + "' ");
                                        double dblthousand = thousand == string.Empty ? 0 : double.Parse(thousand);
                                        dblPackQty = double.Parse(list[i].Qty);
                                        dblPackQty = (dblPackQty * dblthousand) / 1000;
                                        oDBDataSource.SetValue(clsDailyPlan.matrixQuantityColumnUDF, rowNo - 1, dblPackQty.ToString());
                                        oDBDataSource.SetValue(clsDailyPlan.matrixBaseQtyColumnUDF, rowNo - 1, dblPackQty.ToString());
                                        dblPackQty = ((dblScrapRate / 100) * dblPackQty) + dblPackQty;

                                        oDBDataSource.SetValue(clsDailyPlan.matrixPackQtyColumnUDF, rowNo - 1, dblPackQty.ToString());
                                    }
                                    else
                                    {
                                        oDBDataSource.SetValue(clsDailyPlan.matrixQuantityColumnUDF, rowNo - 1, list[i].PlanQty);
                                        dblPackQty = double.Parse(list[i].PlanQty);
                                        dblPackQty = ((dblScrapRate / 100) * dblPackQty) + dblPackQty;

                                        oDBDataSource.SetValue(clsDailyPlan.matrixPackQtyColumnUDF, rowNo - 1, dblPackQty.ToString());
                                        oDBDataSource.SetValue(clsDailyPlan.matrixBaseQtyColumnUDF, rowNo - 1, list[i].PlanQty);
                                    }


                                    oDBDataSource.SetValue(clsDailyPlan.matrixProductCodeColumnUDF, rowNo - 1, itemCode);
                                    oDBDataSource.SetValue(clsDailyPlan.matrixAdviceItemColumnUDF, rowNo - 1, list[i].SOItemCode);
                                    oDBDataSource.SetValue(clsDailyPlan.matrixSOQuantityColumnUDF, rowNo - 1, list[i].Qty);
                                    oDBDataSource.SetValue(clsDailyPlan.matrixBreakTimeColumnUDF, rowNo - 1, defTime);
                                    oDBDataSource.SetValue("U_ExtSize", rowNo - 1, exSize);

                                    if (process.ToLower() == "bag making")
                                    {
                                        oDBDataSource.SetValue(clsDailyPlan.matrixCapacityColumnUDF, rowNo - 1, oRsMachine.Fields.Item("U_MacSpeed").Value);
                                    }
                                    else
                                    {
                                        oDBDataSource.SetValue(clsDailyPlan.matrixCapacityColumnUDF, rowNo - 1, oRsMachine.Fields.Item("U_Cap").Value);
                                    }
                                    sbQuery.Length = 0;
                                    sbQuery.Append(" SELECT  T0.\"" + CommonFields.WhsCode + "\", T0.\"" + CommonFields.Price + "\"");
                                    sbQuery.Append(" ,T0.\"NumPerMsr\",T0.\"" + CommonFields.UomCode + "\" ");
                                    sbQuery.Append(" ,T1.\"" + clsDailyPlan.pcsPerWeightUDF + "\",T1.\"OnHand\",T1.\"InvntryUom\",T1.\"ItemName\",T1.\"U_EXTSIZE\" ");
                                    sbQuery.Append(" FROM \"" + CommonTables.SalesOrderRowTable + "\" T0 ");
                                    sbQuery.Append(" INNER JOIN \"" + CommonTables.ItemMasterData + "\" T1 ON T0.\"" + CommonFields.ItemCode + "\" = T1.\"" + CommonFields.ItemCode + "\" ");
                                    sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = '" + soDocEntry + "' ");
                                    sbQuery.Append(" AND T0.\"" + CommonFields.ItemCode + "\" = '" + itemCode + "' ");

                                    SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                    if (oRs.RecordCount > 0)
                                    {
                                        //oDBDataSource.SetValue(clsDailyPlan.matrixWhsCodeColumnUDF, rowNo - 1, oRs.Fields.Item(CommonFields.WhsCode).Value);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixProductNameColumnUDF, rowNo - 1, oRs.Fields.Item(CommonFields.ItemName).Value);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixSORateColumnUDF, rowNo - 1, oRs.Fields.Item(CommonFields.Price).Value);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixPerPCWtColumnUDF, rowNo - 1, oRs.Fields.Item("IWeight1").Value);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixNumPerMsColumnUDF, rowNo - 1, oRs.Fields.Item("NumPerMsr").Value);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixPackUnitColumnUDF, rowNo - 1, oRs.Fields.Item("UomCode").Value);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixStockQtyColumnUDF, rowNo - 1, oRs.Fields.Item("OnHand").Value);
                                        oDBDataSource.SetValue(clsDailyPlan.matrixStockUnitColumnUDF, rowNo - 1, oRs.Fields.Item("InvntryUom").Value);
                                    }
                                    else
                                    {
                                        sbQuery.Length = 0;
                                        sbQuery.Append(" SELECT  ");
                                        sbQuery.Append(" T1.\"" + CommonFields.InvntryUom + "\" AS \"UomCode\",T1.\"ItemName\" ");
                                        sbQuery.Append(" ,T1.\"" + clsDailyPlan.pcsPerWeightUDF + "\",T1.\"OnHand\",T1.\"InvntryUom\",T1.\"U_EXTSIZE\" ");
                                        sbQuery.Append(" FROM  \"" + CommonTables.ItemMasterData + "\" T1  ");
                                        sbQuery.Append(" WHERE T1.\"" + CommonFields.ItemCode + "\" = '" + itemCode + "' ");
                                        oRs = objclsComman.returnRecord(sbQuery.ToString());
                                        if (oRs.RecordCount > 0)
                                        {
                                            //oDBDataSource.SetValue(clsDailyPlan.matrixWhsCodeColumnUDF, rowNo - 1, oRs.Fields.Item(CommonFields.WhsCode).Value);
                                            //oDBDataSource.SetValue(clsDailyPlan.matrixSORateColumnUDF, rowNo - 1, oRs.Fields.Item(CommonFields.Price).Value);
                                            oDBDataSource.SetValue(clsDailyPlan.matrixProductNameColumnUDF, rowNo - 1, oRs.Fields.Item("ItemName").Value);
                                            oDBDataSource.SetValue(clsDailyPlan.matrixPerPCWtColumnUDF, rowNo - 1, oRs.Fields.Item("IWeight1").Value);
                                            oDBDataSource.SetValue(clsDailyPlan.matrixNumPerMsColumnUDF, rowNo - 1, "1");
                                            oDBDataSource.SetValue(clsDailyPlan.matrixPackUnitColumnUDF, rowNo - 1, oRs.Fields.Item("UomCode").Value);
                                            oDBDataSource.SetValue(clsDailyPlan.matrixStockQtyColumnUDF, rowNo - 1, oRs.Fields.Item("OnHand").Value);
                                            oDBDataSource.SetValue(clsDailyPlan.matrixStockUnitColumnUDF, rowNo - 1, oRs.Fields.Item("InvntryUom").Value);
                                        }
                                    }

                                    objclsComman.ReleaseObject(oRsMachine);
                                    objclsComman.ReleaseObject(oRs);

                                }
                                oBaseMatrix.LoadFromDataSource();

                                if (oBaseForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oBaseForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                                }
                            }
                            #endregion

                            #region Get Plan Qty
                            if (pVal.ItemUID == buttonGetPlanQty)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDT = oForm.DataSources.DataTables.Item(gridDataTableUID);
                                string barCode = string.Empty;
                                List<clsItemEntity> list = new List<clsItemEntity>();
                                for (int i = 0; i < oDT.Rows.Count; i++)
                                {
                                    if (oDT.GetValue("Chk", i) == "Y")
                                    {
                                        list.Add(new clsItemEntity()
                                        {
                                            LineId = i.ToString(),
                                            ItemCode = oDT.GetValue("ItemCode", i),
                                            Qty = oDT.GetValue("Quantity", i).ToString(),
                                            SFGQty = oDT.GetValue("SFGQty", i).ToString()
                                        });
                                    }
                                }
                                if (list.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("No row selected", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                if (list.Count > 1)
                                {
                                    oApplication.StatusBar.SetText("Please select only 1 row", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                int rowNo = int.Parse(oForm.DataSources.UserDataSources.Item(rowNoUID).Value.ToString());
                                string soDocEntry = oForm.DataSources.UserDataSources.Item(soDocEntryUID).Value.ToString();
                                string machineCode = oForm.DataSources.UserDataSources.Item(machineCodeUID).Value.ToString();
                                string soItemCode = oForm.DataSources.UserDataSources.Item(soItemCodeUID).Value.ToString();

                                string itemCode = list[0].ItemCode;
                                string soQty = list[0].Qty;
                                string sfgBOMeaderQuantity = list[0].SFGQty;

                                string fgBOMeaderQuantity = objclsComman.SelectRecord("SELECT \"" + CommonFields.Qauntity + "\" FROM \"" + CommonTables.BOMHeaderTable + "\" Where \"" + CommonFields.Code + "\" = '" + soItemCode + "'  ");
                                //string sfgBOMeaderQuantity = objclsComman.SelectRecord("SELECT \"" + clsBOMMaster.quantityUDF + "\" FROM \"" + clsBOMMaster.headerTable + "\" Where \"" + clsBOMMaster.productCodeUDF + "\" = '" + itemCode + "' AND \"" + clsBOMMaster.machineCodeUDF + "\" = '" + machineCode + "' ");

                                sbQuery.Length = 0;
                                double dblSOQty = double.Parse(soQty);
                                double dblFGBOMHeaderQuantity = fgBOMeaderQuantity == string.Empty ? 0 : double.Parse(fgBOMeaderQuantity);
                                double dblSFGBOMHeaderQuantity = sfgBOMeaderQuantity == string.Empty ? 0 : double.Parse(sfgBOMeaderQuantity);

                                double dblPart1 = (dblSFGBOMHeaderQuantity / dblFGBOMHeaderQuantity) * dblSOQty;
                                double dblPart2 = ((dblSFGBOMHeaderQuantity / dblFGBOMHeaderQuantity) * dblSOQty);// * (dblScrapRate / 100);

                                oDT.SetValue("PlanQty", int.Parse(list[0].LineId), Convert.ToString(dblPart1 + dblPart2));
                            }
                            #endregion
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        public void LoadForm(string rowNo, string soDocEntry, string machineCode, string itemCode)
        {
            objclsComman.LoadXML(formMenuUID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
            oForm = oApplication.Forms.ActiveForm;
            oForm.DataSources.UserDataSources.Add(rowNoUID, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(rowNoUID).Specific;
            oEdit.DataBind.SetBound(true, "", rowNoUID);
            oEdit.String = rowNo;

            oForm.DataSources.UserDataSources.Add(soDocEntryUID, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 40);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(soDocEntryUID).Specific;
            oEdit.DataBind.SetBound(true, "", soDocEntryUID);
            oEdit.String = soDocEntry;

            oForm.DataSources.UserDataSources.Add(machineCodeUID, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 40);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(machineCodeUID).Specific;
            oEdit.DataBind.SetBound(true, "", machineCodeUID);
            oEdit.String = machineCode;

            //oForm.DataSources.UserDataSources.Add(soItemCodeUID, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 40);
            //oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(soItemCodeUID).Specific;
            //oEdit.DataBind.SetBound(true, "", soItemCodeUID);
            //oEdit.String = itemCode;
        }

        public void FillGrid(string query)
        {
            oForm = oApplication.Forms.ActiveForm;
            objclsComman.FillGrid(oForm.UniqueID, gridUID, gridDataTableUID, query);
            oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;
            for (int i = 1; i < oGrid.Columns.Count; i++)
            {
                oGrid.Columns.Item(i).Editable = false;
            }
            oGrid.Columns.Item("Chk").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
        }

        #endregion
    }
}
