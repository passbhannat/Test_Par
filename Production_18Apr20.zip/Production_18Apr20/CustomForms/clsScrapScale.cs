using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using Production.Classes;

namespace Production
{
    class clsScrapScale : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formTypeEx = "SCRAPSCALE";
        const string formMenuUID = "SCRAPSCALE";
        public const string objType = "SCRAPSCALE";

        public const string headerTable = "@SCRAPSCALE";
        public const string rowTable = "@SCRAPSCALE1";

        const string CFL_JC = "CFL_JC";
        const string CFL_ITEM = "CFL_ITEM";
        const string CFL_MAC = "CFL_MAC";
        const string CFL_RITEM = "CFL_RITEM";
        const string CFL_RWHS = "CFL_RWHS";

        const string docDateUDF = "U_DocDate";
        const string jbDocNumUID = "JBNo";
        const string jbDocNumUDF = "U_JBNo";
        const string jbDocEntryUDF = "U_JBEn";
        const string jbDocDateUDF = "U_JBDate";
        const string machineCodeUDF = "U_MacCode";
        const string machineCodeUID = "MacCode";
        const string machineNameUDF = "U_MacName";
        const string productCodeUID = "PrdCode";
        const string productCodeUDF = "U_PrdCode";
        const string productNameUDF = "U_PrdName";
        const string receiptDateUDF = "U_RecDate";
        const string receiptDateUID = "RecDate";
        public const string receiptNoUDF = "U_RecNo";
        public const string receiptNoUID = "RecNo";
        public const string receiptEntryUDF = "U_RecEn";
        public const string shiftUDF = "U_Shift";
        public const string shiftUID = "Shift";

        const string matrixUID = "mtx";
        const string matrixPrimaryUDF = "U_PrdCode";
        const string matrixPrimaryColumnUID = "V_1";

        const string matrixProductCodeUDF = "U_PrdCode";
        const string matrixProductCodeUID = "V_1";

        const string matrixProductNameUDF = "U_PrdName";
        const string matrixWhsCodeUDF = "U_WhsCode";
        const string matrixWhsCodeUID = "V_3";

        public const string matrixQtyUDF = "U_Qty";
        //public const string matrixBatchUDF = "U_Batch";

        public const string matrixNetWtUDF = "U_NetWt";

        const string matrixScrapTypeUID = "V_4";

        const string fatherDocEntryUDF = "U_FathDocE";
        const string fatherDocNumUDF = "U_FathDocN";
        const string fatherObjectUDF = "U_FathObj";

        const string buttonCreateReceiptUID = "btnRec";
        const string buttonPushToJobCard = "btnPush";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank. Please select series.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(machineCodeUDF, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select Machine.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select ItemCode.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion

                            #region Create Receipt From Production
                            else if (pVal.ItemUID == buttonCreateReceiptUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                CreateReceiptFromProduction_PartialAuto(docEntry);
                            }
                            #endregion

                            #region Push To Job Card
                            else if (pVal.ItemUID == buttonPushToJobCard)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                PushItemsToProductionOrder(docEntry);
                            }
                            #endregion
                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == jbDocNumUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                string prdCode = oDbDataSource.GetValue(productCodeUDF, 0).Trim();
                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                temp = new ArrayList();
                                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                temp.Add(CommonFields.Status); //Condition Alias             
                                temp.Add("R"); //Condition Value
                                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                alCondVal.Add(temp);
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                sbQuery.Length = 0;
                                //sbQuery.Append(" SELECT T0.\"" + CommonFields.DocEntry + "\" ");
                                //sbQuery.Append(" FROM \"OWOR\" T0 ");
                                //sbQuery.Append(" WHERE  T0.\"" + CommonFields.Status + "\" = 'R' ");

                                //sbQuery.Append(" INNER JOIN \"WOR1\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\"   ");
                                //sbQuery.Append(" WHERE  ");
                                //sbQuery.Append(" T1.\"" + CommonFields.PlannedQty + "\" < 0  ");
                                //sbQuery.Append(" AND NOT EXISTS( ");
                                //sbQuery.Append(" SELECT 1 FROM \"" + headerTable + "\" IT0 WHERE T0.\"" + CommonFields.DocEntry + "\" = IT0.\"" + jbDocEntryUDF + "\")");

                                objclsComman.AddChooseFromList_WithCond(oForm, CFL_JC, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oProductionOrders), sbQuery.ToString(), CommonFields.DocEntry, alCondVal);
                            }
                            if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixProductCodeUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    string machineCode = oDbDataSource.GetValue(machineCodeUDF, 0).Trim();
                                    string itemGroupCode = objclsComman.SelectRecord("SELECT ItmsGrpCod FROM OITB WHERE ItmsGrpNam = 'BY Product'");
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    temp = new ArrayList();
                                    temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                    temp.Add(CommonFields.ItmsGrpCod); //Condition Alias             
                                    temp.Add(itemGroupCode); //Condition Value
                                    temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                    alCondVal.Add(temp);
                                    //string query = "Select \"U_PrdCode\" FROM \"" + clsMachineMaster.rowTable + "\" WHERE \"Code\" = '" + machineCode + "'";
                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_RITEM, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oItems), "", CommonFields.ItemCode, alCondVal);
                                }
                               else if (pVal.ColUID == matrixWhsCodeUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    temp = new ArrayList();
                                    temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                    temp.Add(CommonFields.WhsCode); //Condition Alias             
                                    temp.Add("SCRAP"); //Condition Value
                                    temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                    alCondVal.Add(temp);
                                    //string query = "Select \"U_PrdCode\" FROM \"" + clsMachineMaster.rowTable + "\" WHERE \"Code\" = '" + machineCode + "'";
                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_RWHS, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oWarehouses), "", CommonFields.WhsCode, alCondVal);
                                }
                            }

                            //else if (pVal.ItemUID == receiptNoUID)
                            //{
                            //    oForm = oApplication.Forms.Item(pVal.FormUID);
                            //    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                            //    string jbDocEntry = oDbDataSource.GetValue(jbDocEntryUDF, 0).Trim();
                            //    jbDocEntry = jbDocEntry == string.Empty ? "999999" : jbDocEntry;
                            //    ArrayList alCondVal = new ArrayList();
                            //    ArrayList temp = new ArrayList();
                            //    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            //    string query = "Select T0.\"DocEntry\" FROM \"OIGN\" T0 INNER JOIN \"IGN1\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" WHERE T1.\"BaseEntry\" = '" + jbDocEntry + "'";
                            //    objclsComman.AddChooseFromList_WithCond(oForm, CFL_REC, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry), query, CommonFields.DocEntry, alCondVal);
                            //}

                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == CFL_JC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(jbDocNumUDF, 0, oDataTable.GetValue(CommonFields.DocNum, 0).ToString());
                                oDbDataSource.SetValue(jbDocEntryUDF, 0, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());
                                DateTime docDate = DateTime.Parse(oDataTable.GetValue(CommonFields.PostDate, 0).ToString());
                                oDbDataSource.SetValue(jbDocDateUDF, 0, objclsComman.ConvertDateToSAPDateFormat(docDate));
                                oDbDataSource.SetValue(productCodeUDF, 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue(machineCodeUDF, 0, oDataTable.GetValue(machineCodeUDF, 0).ToString());

                                oDbDataSource.SetValue(productCodeUDF, 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                string itemName = objclsComman.SelectRecord("SELECT \"" + CommonFields.ItemName + "\" FROM OITM WHERE \"" + CommonFields.ItemCode + "\" = '" + oDataTable.GetValue(CommonFields.ItemCode, 0).ToString() + "' ");
                                oDbDataSource.SetValue(productNameUDF, 0, itemName);

                                sbQuery.Length = 0;
                                //sbQuery.Append(" SELECT T0.\"" + CommonFields.Code + "\",T0.\"" + CommonFields.Name + "\" ");
                                //sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                //sbQuery.Append(" INNER JOIN \"" + clsMachineMaster.rowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\" = T1.\"" + CommonFields.Code + "\" ");
                                //sbQuery.Append(" WHERE \"" + productCodeUDF + "\" = '" + oDataTable.GetValue(CommonFields.ItemCode, 0).ToString() + "' ");

                                //SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                //if (oRs.RecordCount > 0)
                                //{
                                //    oDbDataSource.SetValue(machineCodeUDF, 0, oRs.Fields.Item(CommonFields.Code).Value.ToString());
                                //    oDbDataSource.SetValue(machineNameUDF, 0, oRs.Fields.Item(CommonFields.Name).Value.ToString());
                                //}
                                sbQuery.Append(" SELECT T0.\"" + CommonFields.Name + "\" ");
                                sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                sbQuery.Append(" WHERE T0.\"" + CommonFields.Code + "\" = '" + oDataTable.GetValue(machineCodeUDF, 0).ToString() + "'");

                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                if (oRs.RecordCount > 0)
                                {
                                    //oDbDataSource.SetValue(machineCodeUDF, 0, oRs.Fields.Item(CommonFields.Code).Value.ToString());
                                    oDbDataSource.SetValue(machineNameUDF, 0, oRs.Fields.Item(CommonFields.Name).Value.ToString());
                                }
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oDbDataSource.Clear();
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT T0.\"" + CommonFields.ItemCode + "\" ,T1.\"" + CommonFields.ItemName + "\"  ");
                                sbQuery.Append(" ,T0.\"" + CommonFields.PlannedQty + "\",T0.\"wareHouse\"  ");
                                sbQuery.Append(" FROM WOR1 T0 ");
                                sbQuery.Append(" INNER JOIN OITM T1 ON  T0.\"" + CommonFields.ItemCode + "\" = T1.\"" + CommonFields.ItemCode + "\" ");
                                sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + oDataTable.GetValue(CommonFields.DocEntry, 0).ToString() + "' ");
                                sbQuery.Append(" AND T0.\"PlannedQty\" < 0 ");

                                oRs = objclsComman.returnRecord(sbQuery.ToString());
                                int row = 0;
                                while (!oRs.EoF)
                                {
                                    oDbDataSource.InsertRecord(row);
                                    oDbDataSource.SetValue(CommonFields.LineId, row, Convert.ToString(row + 1));
                                    oDbDataSource.SetValue(matrixProductCodeUDF, row, oRs.Fields.Item(CommonFields.ItemCode).Value.ToString());
                                    oDbDataSource.SetValue(matrixProductNameUDF, row, oRs.Fields.Item(CommonFields.ItemName).Value.ToString());
                                    oDbDataSource.SetValue(matrixQtyUDF, row, oRs.Fields.Item(CommonFields.PlannedQty).Value.ToString());
                                    oDbDataSource.SetValue(matrixWhsCodeUDF, row, oRs.Fields.Item("wareHouse").Value.ToString());

                                    oRs.MoveNext();
                                    row++;
                                }
                                if (oRs.RecordCount == 0)
                                {
                                    oDbDataSource.InsertRecord(row);
                                    oDbDataSource.SetValue(CommonFields.LineId, row, Convert.ToString(row + 1));
                                }
                                objclsComman.ReleaseObject(oRs);
                                oMatrix.LoadFromDataSource();
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_MAC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(machineCodeUDF, 0, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue(machineNameUDF, 0, oDataTable.GetValue(CommonFields.Name, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_ITEM)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(productCodeUDF, 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue(productNameUDF, 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_RITEM)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixProductCodeUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue(matrixProductNameUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                                oDbDataSource.SetValue(matrixWhsCodeUDF, pVal.Row - 1, "SCRAP");

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixProductCodeUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_RWHS)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixWhsCodeUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixWhsCodeUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formTypeEx)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypeEx && pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString();
                                    if (code.Trim() == string.Empty)
                                    {
                                        LoadForm(Convert.ToString((int)SAPMenuEnum.AddRecord));
                                        return;
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "Series")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                    if (oCombo.Value == null)
                                    {

                                    }
                                    else
                                    {
                                        int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                        string docNum = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), objType).ToString();
                                        oDBDataSource.SetValue(CommonFields.DocNum, 0, Convert.ToString(docNum));
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "DocDate")
                            {
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    objclsComman.FillCombo_Series_Custom(oForm, objType, pVal.ItemUID, "Load");
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                    if (oCombo.ValidValues.Count == 0)
                                    {
                                        oForm.DataSources.DBDataSources.Item(headerTable).SetValue(CommonFields.DocNum, 0, string.Empty);
                                    }
                                }
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;

                        AddRow(matrixUID, rowTable, matrixPrimaryUDF);

                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID, rowTable, matrixPrimaryUDF);
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  \"DocEntry\" ='" + docEntry + "' AND IFNULL(\"" + matrixPrimaryUDF + "\",'')=''");
                        }
                        else
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  \"DocEntry\" ='" + docEntry + "' AND ISNULL(\"" + matrixPrimaryUDF + "\",'')=''");
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        //DisableControls(BusinessObjectInfo.FormUID);
                        //string receiptDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(receiptEntryUDF, 0);
                        //if (receiptDocEntry != string.Empty)
                        //{
                        //    oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                        //    oItem = oForm.Items.Item(buttonCreateQCUID);
                        //    oItem.Enable();
                        //    DisableControls(oForm.UniqueID);
                        //}
                        //else
                        //{
                        //    oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                        //    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                        //    oMatrix.FlushToDataSource();
                        //    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                        //    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                        //    oMatrix.LoadFromDataSource();
                        //    EnableControls(oForm.UniqueID);
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        private void LoadForm(string MenuID)
        {
            try
            {
                clsVariables.boolCFLSelected = false;
                if (MenuID == formMenuUID)
                {
                    objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                    if (oMatrix.VisualRowCount == 0)
                    {
                        oMatrix.AddRow(1, 1);
                    }
                    oMatrix.CommonSetting.EnableArrowKey = true;

                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(shiftUID).Specific;
                    objclsComman.FillCombo(oCombo, "SELECT \"Code\",\"Name\" FROM \"@SHIFTMASTER\"");

                    oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixScrapTypeUID, 1);
                    objclsComman.FillCombo(oCombo, "SELECT \"Code\",\"Name\" FROM \"@SCRAPTYPEMASTER\"");
                }
                oForm = oApplication.Forms.ActiveForm;
                EnableControls(oForm.UniqueID);

                #region Series And DocNum

                try
                {
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                    oEdit.String = "t";

                    objclsComman.FillCombo_Series_Custom(oForm, objType, "DocDate", "Load");

                    #region Set DocNum
                    string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    if (defaultseries == string.Empty)
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                        defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    }
                    string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                    #endregion

                }
                catch { }
                #endregion

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }

                oItem = oForm.Items.Item("DocNum");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item("DocEntry");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item("Series");
                oItem.EnableinAddMode();

                oItem = oForm.Items.Item(machineCodeUID);
                oItem.EnableinAddMode();

                oItem = oForm.Items.Item(productCodeUID);
                oItem.EnableinAddMode();

                oItem = oForm.Items.Item(jbDocNumUID);
                oItem.EnableinAddMode();

                oItem = oForm.Items.Item(receiptNoUID);
                oItem.EnableinFindMode();
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsComman.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void DisableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), false);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), false);
            //oForm.Items.Item(woDocNumItemUID).Disable();
        }
        private void EnableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
            // oForm.Items.Item(woDocNumItemUID).Enable();
        }

        private void PushItemsToProductionOrder(string docEntry)
        {
            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.\"" + CommonFields.DocEntry + "\",T0.\"" + jbDocEntryUDF + "\",T1.\"" + productCodeUDF + "\" ");
            sbQuery.Append(" ,T1.\"" + matrixNetWtUDF + "\",T1.\"" + matrixWhsCodeUDF + "\"    ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + docEntry + "'  ");
            sbQuery.Append(" AND T1.\"U_Chk\" = 'Y'  ");

            //sbQuery.Append(" AND NOT EXISTS ( ");
            //sbQuery.Append(" SELECT 1 FROM " + CommonTables.ProductionOrderHeaderTable + " IT0   ");
            //sbQuery.Append(" INNER JOIN " + CommonTables.ProductionOrderRowTable + " IT1 ON IT0.\"" + CommonFields.DocEntry + "\" = IT1.\"" + CommonFields.DocEntry + "\"  ");
            //sbQuery.Append(" WHERE T0.\"" + jbDocEntryUDF + "\" = IT0.\"" + CommonFields.DocEntry + "\" AND T1.\"" + productCodeUDF + "\"=IT1.\"" + CommonFields.ItemCode + "\"  ) ");

            SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
            if (oRs.RecordCount == 0)
            {
                oApplication.StatusBar.SetText("There is no item to push in production order", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return;
            }
            int k = oApplication.MessageBox("Do you really want to push scrap item to production order?", 1, "Yes", "No", "");
            if (k == 2)
            {
                return;
            }
            string productionOrderDocEntry = oRs.Fields.Item(jbDocEntryUDF).Value.ToString();

            SAPbobsCOM.ProductionOrders objProduction;
            objProduction = oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oProductionOrders);

            if (objProduction.GetByKey(int.Parse(productionOrderDocEntry)))
            {
                while (!oRs.EoF)
                {
                    objProduction.Lines.Add();
                    objProduction.Lines.ItemNo = oRs.Fields.Item(productCodeUDF).Value.ToString();
                    objProduction.Lines.Warehouse = oRs.Fields.Item(matrixWhsCodeUDF).Value.ToString();

                    double quantity = double.Parse(oRs.Fields.Item(matrixNetWtUDF).Value.ToString());
                    objProduction.Lines.PlannedQuantity = quantity < 0 ? quantity : (-1) * quantity;
                    oRs.MoveNext();
                }
            }
            int i = objProduction.Update();
            if (i == 0)
            {
                oApplication.StatusBar.SetText("Production order has been updated successfully", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                objclsComman.SelectRecord("UPDATE T0 SET \"U_Chk\" = 'N' FROM \"" + rowTable + "\" T0 WHERE \"" + CommonFields.DocEntry + "\" = '" + docEntry + "'");
            }
            else
            {
                oApplication.StatusBar.SetText("Error: " + oCompany.GetLastErrorCode() + " : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            objclsComman.ReleaseObject(oRs);
            objclsComman.ReleaseObject(objProduction);
        }


        private void CreateReceiptFromProduction_PartialAuto(string DocEntry)
        {
            oForm = oApplication.Forms.ActiveForm;
            string receiptEn = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(receiptEntryUDF, 0).Trim();
            if (receiptEn != string.Empty)
            {
                oApplication.StatusBar.SetText("Receipt from production is already created", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return;
            }

            //oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            //oMatrix.FlushToDataSource();
            //oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            //for (int i = 0; i < oDbDataSource.Size; i++)
            //{
            //    double netQty = double.Parse(oDbDataSource.GetValue(matrixNetWtUDF, i));
            //    if (netQty == 0)
            //    {
            //        oApplication.StatusBar.SetText("Net weight can't be zero", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            //        return;
            //    }
            //}
            SAPbobsCOM.Recordset oRs = null;
            string orderDataTableUID = "receiptDT";
            string lineId = string.Empty;
            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.\"DocEntry\",T1.\"LineId\",T0.\"U_DocDate\", T0.\"U_JBEn\", T0.\"U_JBNo\",T1.\"U_PrdCode\",T0.\"" + shiftUDF + "\"");
            sbQuery.Append(" ,SUM(T1.\"" + matrixNetWtUDF + "\") AS \"" + matrixNetWtUDF + "\"  ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
            sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T0.\"U_PrdCode\" = T2.\"ItemCode\" ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "'  ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T0.\"" + receiptEntryUDF + "\",'') = '' ");
            }
            else
            {
                sbQuery.Append(" AND ISNULL(T0.\"" + receiptEntryUDF + "\",'') = '' ");
            }
            sbQuery.Append(" GROUP BY T0.\"DocEntry\",T1.\"LineId\",T0.\"U_DocDate\", T0.\"U_JBEn\", T0.\"U_JBNo\",T1.\"U_PrdCode\",T0.\"" + shiftUDF + "\"");
            try
            {
                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }
            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);

            try
            {
                oRs = objclsComman.returnRecord(sbQuery.ToString());

                if (oRs.RecordCount == 0)
                {
                    oApplication.MessageBox(" No Record found to create receipt from production. ", 1, "Ok", "", "");
                    return;
                }
                oDataTable.ExecuteQuery(sbQuery.ToString());

                int k = oApplication.MessageBox("Do you really want to create receipt from production?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }

                clsVariables.BaseJobEntry = oRs.Fields.Item(jbDocEntryUDF).Value.ToString();
                clsVariables.BaseJobNo = oRs.Fields.Item(jbDocNumUDF).Value.ToString();

                clsVariables.BaseEntry = oRs.Fields.Item("DocEntry").Value.ToString();
                clsVariables.BaseLine = oRs.Fields.Item("LineId").Value.ToString();
                clsVariables.BaseItemCode = oRs.Fields.Item("U_PrdCode").Value.ToString();
                clsVariables.BaseShift = oRs.Fields.Item(shiftUDF).Value.ToString();
                clsVariables.BaseObjectType = objType;
                List<clsItemEntity> list = new List<clsItemEntity>();

                int i = 0;
                while (!oRs.EoF)
                {
                    double quantity = double.Parse(oRs.Fields.Item(matrixNetWtUDF).Value.ToString());
                    quantity = quantity < 0 ? quantity * (-1) : quantity;
                    if (quantity != 0)
                    {
                        list.Add(new clsItemEntity() { ItemCode = oRs.Fields.Item("U_PrdCode").Value.ToString(), Qty = quantity.ToString() });
                    }
                    i++;
                    oRs.MoveNext();
                }
                clsVariables.ItemList = list;
                clsVariables.boolNewFormOpen = true;

                objclsComman.ReleaseObject(oRs);
                oApplication.ActivateMenuItem("4370");
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                objclsComman.ReleaseObject(oRs);
                objclsComman.ReleaseObject(oDataTable);
            }
        }


        private void CreateReceipt(string DocEntry)
        {
            oForm = oApplication.Forms.ActiveForm;
            string receiptEn = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(receiptEntryUDF, 0).Trim();
            if (receiptEn != string.Empty)
            {
                oApplication.StatusBar.SetText("Goods Receipt is already created", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return;
            }
            SAPbobsCOM.Recordset oRs = null;
            string orderDataTableUID = "receiptDT";
            string lineId = string.Empty;
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.\"U_DocDate\", T0.\"" + jbDocEntryUDF + "\", T0.\"" + jbDocNumUDF + "\",T1.\"U_PrdCode\",T1.\"" + matrixQtyUDF + "\",T0.\"" + shiftUDF + "\" ");
            sbQuery.Append(" ,T1.\"" + matrixWhsCodeUDF + "\",T2.\"" + CommonFields.ManBtchNum + "\" ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
            sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T0.\"U_PrdCode\" = T2.\"ItemCode\" ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T0.\"" + receiptEntryUDF + "\",'') = '' ");
            }
            else
            {
                sbQuery.Append(" AND ISNULL(T0.\"" + receiptEntryUDF + "\",'') = '' ");
            }

            try
            {
                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }

            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);
            oDataTable.ExecuteQuery(sbQuery.ToString());
            try
            {
                int k = oApplication.MessageBox("Do you really want to create receipt?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }

                StringBuilder sbMessage = new StringBuilder();
                SAPbobsCOM.Documents receipt = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenEntry);

                try
                {
                    receipt.DocDate = DateTime.Parse(oDataTable.GetValue(docDateUDF, 0).ToString());
                    receipt.BPL_IDAssignedToInvoice = 1;

                    receipt.UserFields.Fields.Item(fatherDocEntryUDF).Value = oDataTable.GetValue(jbDocEntryUDF, 0).ToString();
                    receipt.UserFields.Fields.Item(fatherDocNumUDF).Value = oDataTable.GetValue(jbDocNumUDF, 0).ToString();
                    receipt.UserFields.Fields.Item(fatherObjectUDF).Value = "202";
                    int row = 0;
                    for (int j = 0; j < oDataTable.Rows.Count; j++)
                    {
                        if (row > 0)
                        {
                            receipt.Lines.Add();
                        }
                        //receipt.Lines.BaseType = 202;
                        receipt.Lines.ItemCode = oDataTable.GetValue(matrixProductCodeUDF, j).ToString();
                        //receipt.Lines.BaseEntry = Int32.Parse(oDataTable.GetValue(jbDocEntryUDF, 0).ToString());
                        double qty = double.Parse(oDataTable.GetValue(matrixQtyUDF, j).ToString()); ;
                        qty = qty < 0 ? qty * (-1) : qty;
                        receipt.Lines.Quantity = qty;
                        receipt.Lines.WarehouseCode = oDataTable.GetValue(matrixWhsCodeUDF, j).ToString();
                        //receipt.Lines.TransactionType = SAPbobsCOM.BoTransactionTypeEnum.botrntComplete;
                        string manBatch = oDataTable.GetValue(CommonFields.ManBtchNum, j).ToString();
                        if (manBatch == "Y")
                        {
                            //receipt.Lines.BatchNumbers.ManufacturerSerialNumber = oDataTable.GetValue(matrixShiftUDF, j).ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                            //receipt.Lines.BatchNumbers.BatchNumber = oDataTable.GetValue(matrixBatchUDF, j).ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                            receipt.Lines.BatchNumbers.Quantity = qty;
                            receipt.Lines.BatchNumbers.Add();
                        }
                        receipt.Lines.SetCurrentLine(row);
                        row++;
                    }
                    int retVal = receipt.Add();
                    if (retVal != 0)
                    {
                        oApplication.StatusBar.SetText("Create Receipt From Production Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        sbMessage.Append(oCompany.GetLastErrorDescription());
                        sbMessage.Append(Environment.NewLine);
                    }
                    else
                    {
                        string newDocEntry = oCompany.GetNewObjectKey();
                        string newDocNum = objclsComman.SelectRecord("SELECT \"DocNum\" FROM OIGN WHERE \"DocEntry\" = '" + newDocEntry + "'");
                        sbQuery.Length = 0;
                        sbQuery.Append(" UPDATE T0 ");
                        sbQuery.Append(" SET \"" + receiptEntryUDF + "\" = '" + newDocEntry + "',\"" + receiptNoUDF + "\" = '" + newDocNum + "' ");
                        sbQuery.Append(" FROM \"" + headerTable + "\" T0 WHERE \"DocEntry\" ='" + DocEntry + "' ");
                        if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                        {
                            sbQuery.Append(" AND IFNULL(T0.\"" + receiptEntryUDF + "\",'') = '' ");
                        }
                        else
                        {
                            sbQuery.Append(" AND ISNULL(T0.\"" + receiptEntryUDF + "\",'') = '' ");
                        }
                        objclsComman.SelectRecord(sbQuery.ToString());
                        oApplication.StatusBar.SetText("Receipt from production Order " + newDocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    }
                }
                catch (Exception ex)
                {
                    SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                    oApplication.StatusBar.SetText("Catch1 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                }
                finally
                {

                }

                if (sbMessage.Length != 0)
                {
                    oApplication.MessageBox(sbMessage.ToString(), 1, "Ok", "", "");
                }
                objclsComman.RefreshRecord();
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable);
                }
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        #endregion
    }
}
