using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;

namespace Production
{
    class clsWeighingScaleQCParameter : Connection
    {
        #region Variables

        SAPbouiCOM.Item oItem;
        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        public const string formTypeEx = "WEIGHINGSCALEQCPAR";
        public const string formMenuUID = "WEIGHINGSCALEQCPAR";
        public const string objType = "WEIGHINGSCALEQCPAR";
        const string matrixUID = "mtx";
        const string matrixPrimaryUDF = "U_BarCode";
        const string matrixPrimaryColumnUID = "V_7";

        public const string headerTable = "@WEIGHINGSCALEQCPAR";
        public const string rowTable = "@WEIGHINGSCALEQCPAR1";

        public const string matrixQCEntryUDF = "U_QCEn";
        const string matrixQCEntryUID = "V_10";
        public const string matrixMinValueUDF = "U_MinValue";
        public const string matrixMaxValueUDF = "U_MaxValue";
        public const string matrixStdValueUDF = "U_StdValue";
        public const string matrixActValueUDF = "U_ActValue";
        public const string matrixActValueUID = "V_1";
        public const string matrixTolPerUDF = "U_TolPer";

        const string CFL_JC = "CFL_JC";
        const string CFL_BAR = "CFL_BAR";
        const string CFL_ITEM = "CFL_ITEM";
        const string CFL_REC = "CFL_REC";
        const string CFL_MAC = "CFL_MAC";

        public const string baseEntryUDF = "U_BaseEn";
        const string baseEntryUID = "BaseEn";

        public const string baseLineUDF = "U_BaseLine";
        const string baseLineUID = "BaseLine";

        const string productCodeUDF = "U_PrdCode";
        const string productDescriptionUDF = "U_PrdDesc";
        const string shiftUDF = "U_Shift";

        const string matrixGrossWtUID = "";
        const string matrixGrossWtUDF = "U_GrWt";

        const string matrixTareWtUID = "";
        const string matrixTareWtUDF = "U_TareWt";

        const string matrixNetWtUID = "";
        const string matrixNetWtUDF = "U_NetWt";

        const string qCStatusUDF = "U_QCStatus";

        const string receiptNoUDF = "U_RecNo";
        const string receiptEntryUDF = "U_RecEn";

        const string machineCodeUDF = "U_MacCode";
        const string machineNameUDF = "U_MacName";

        const string buttonCreateReceiptUID = "btnCR";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText(" Please select Product Code.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion

                        #region T_et_MATRIX_LINK_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_MATRIX_LINK_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixQCEntryUID)
                                {

                                }
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formTypeEx)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypeEx)
                                {
                                    if (pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).ToString();
                                        if (code.Trim() == string.Empty)
                                        {
                                            oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Cancel)).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                            oForm = oApplication.Forms.Item(clsVariables.BaseFormUID);
                                            oForm.Select();
                                            objclsComman.RefreshRecord();
                                        }
                                        //if (pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                        //{
                                        //    oForm = oApplication.Forms.Item(clsVariables.BaseFormUID);
                                        //    oForm.Select();
                                        //    objclsComman.RefreshRecord();
                                        //}
                                    }
                                }
                            }
                        }
                        #endregion

                        if (pVal.ItemChanged == true)
                        {
                            if (pVal.ColUID == matrixActValueUID)
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                int i = pVal.Row - 1;
                                string minValue = oDbDataSource.GetValue(matrixMinValueUDF, i);
                                string maxValue = oDbDataSource.GetValue(matrixMaxValueUDF, i);
                                string stdValue = oDbDataSource.GetValue(matrixStdValueUDF, i);
                                string actValue = oDbDataSource.GetValue(matrixActValueUDF, i);
                                string tolPer = oDbDataSource.GetValue(matrixTolPerUDF, i);

                                double dblTolPer = tolPer == string.Empty ? 1 : double.Parse(tolPer);
                                dblTolPer = dblTolPer == 0 ? 1 : dblTolPer;

                                double dblMinValue = minValue == string.Empty ? 0 : double.Parse(minValue);
                                double dblMaxValue = maxValue == string.Empty ? 0 : double.Parse(maxValue);
                                double dblStdValue = stdValue == string.Empty ? 0 : double.Parse(stdValue);
                                double dblActValue = actValue == string.Empty ? 0 : double.Parse(actValue);

                                double dblMinStdValue = dblStdValue;
                                double dblMaxStdValue = dblStdValue;

                                if (dblTolPer > 1)
                                {
                                    dblMinValue = dblMinValue - (dblMinValue * dblTolPer / 100);
                                    dblMaxValue = dblMaxValue + (dblMaxValue * dblTolPer / 100);
                                    dblMinStdValue = dblMinStdValue - (dblMinStdValue * dblTolPer / 100);
                                    dblMaxStdValue = dblMaxStdValue + (dblMaxStdValue * dblTolPer / 100);
                                }

                                if (dblActValue >= dblMinStdValue && dblActValue <= dblMaxStdValue)
                                {
                                    oMatrix.CommonSetting.SetRowBackColor(i + 1, -1);
                                    oMatrix.CommonSetting.SetRowFontColor(i + 1, -1);
                                    return;
                                }
                                else
                                {
                                    oMatrix.CommonSetting.SetRowBackColor(i + 1, (int)SAPCommonColorEnum.Red);
                                    oMatrix.CommonSetting.SetRowFontColor(i + 1, (int)SAPCommonColorEnum.White);
                                }

                                if (dblActValue >= dblMinValue && dblActValue <= dblMaxValue)
                                {
                                    oMatrix.CommonSetting.SetRowBackColor(i + 1, -1);
                                    oMatrix.CommonSetting.SetRowFontColor(i + 1, -1);
                                }
                                else
                                {
                                    oMatrix.CommonSetting.SetRowBackColor(i + 1, (int)SAPCommonColorEnum.Red);
                                    oMatrix.CommonSetting.SetRowFontColor(i + 1, (int)SAPCommonColorEnum.White);
                                }




                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }

            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        return;
                    }
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                    string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                    string baseEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(baseEntryUDF, 0);
                    string baseLine = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(baseLineUDF, 0);
                    string baseQCStatus = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(qCStatusUDF, 0);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                        {
                            sbQuery.Length = 0;
                            sbQuery.Append(" UPDATE \"" + clsWeighingScaleQC.rowTable + "\" ");
                            sbQuery.Append(" SET \"" + clsWeighingScaleQC.matrixQCEntryUDF + "\" = '" + docEntry + "'");
                            sbQuery.Append(" WHERE \"DocEntry\" = '" + baseEntry + "' AND \"LineId\" = '" + baseLine + "'");
                            objclsComman.SelectRecord(sbQuery.ToString());
                        }
                        sbQuery.Length = 0;
                        sbQuery.Append(" UPDATE \"" + clsWeighingScaleQC.rowTable + "\" ");
                        sbQuery.Append(" SET \"" + qCStatusUDF + "\" = '" + baseQCStatus + "'");
                        sbQuery.Append(" WHERE \"DocEntry\" = '" + baseEntry + "' AND \"" + clsWeighingScaleQC.matrixQCEntryUDF + "\" = '" + docEntry + "'");
                        objclsComman.SelectRecord(sbQuery.ToString());

                        string value = "";
                        sbQuery.Length = 0;
                        sbQuery.Append("SELECT Sum(\"" + clsWeighingScaleQC.matrixGrossWtUDF + "\") FROM \"" + clsWeighingScaleQC.rowTable + "\" WHERE \"" + clsWeighingScaleQC.matrixQCEntryUDF + "\" = '" + docEntry + "' AND \"" + clsWeighingScaleQC.matrixQCStatusUDF + "\" = 'P'");
                        string passValue = objclsComman.SelectRecord(sbQuery.ToString());

                        sbQuery.Length = 0;
                        sbQuery.Append("SELECT Sum(\"" + clsWeighingScaleQC.matrixGrossWtUDF + "\") FROM \"" + clsWeighingScaleQC.rowTable + "\" WHERE \"" + clsWeighingScaleQC.matrixQCEntryUDF + "\" = '" + docEntry + "' AND \"" + clsWeighingScaleQC.matrixQCStatusUDF + "\" = 'H'");
                        string holdValue = objclsComman.SelectRecord(sbQuery.ToString());

                        sbQuery.Length = 0;
                        sbQuery.Append("SELECT Sum(\"" + clsWeighingScaleQC.matrixGrossWtUDF + "\") FROM \"" + clsWeighingScaleQC.rowTable + "\" WHERE \"" + clsWeighingScaleQC.matrixQCEntryUDF + "\" = '" + docEntry + "' AND \"" + clsWeighingScaleQC.matrixQCStatusUDF + "\" = 'R'");
                        string rejectValue = objclsComman.SelectRecord(sbQuery.ToString());

                        sbQuery.Length = 0;
                        sbQuery.Append("SELECT Sum(\"" + clsWeighingScaleQC.matrixGrossWtUDF + "\") FROM \"" + clsWeighingScaleQC.rowTable + "\" WHERE \"" + clsWeighingScaleQC.matrixQCEntryUDF + "\" = '" + docEntry + "' AND \"" + clsWeighingScaleQC.matrixQCStatusUDF + "\" = 'V'");
                        string voidValue = objclsComman.SelectRecord(sbQuery.ToString());

                        sbQuery.Length = 0;
                        sbQuery.Append(" UPDATE \"" + clsWeighingScaleQC.headerTable + "\" ");
                        sbQuery.Append(" SET \"U_PassTot\" =  '" + passValue + "',\"U_HoldTot\" =  '" + holdValue + "'");
                        sbQuery.Append(" , \"U_RejTot\" =  '" + rejectValue + "',\"U_VoidTot\" =  '" + voidValue + "'");
                        sbQuery.Append(" WHERE \"DocEntry\" = '" + baseEntry + "'");

                        objclsComman.SelectRecord(sbQuery.ToString());
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;

                        oMatrix.FlushToDataSource();
                        oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                        for (int i = 0; i < oDbDataSource.Size; i++)
                        {
                            string minValue = oDbDataSource.GetValue(matrixMinValueUDF, i);
                            string maxValue = oDbDataSource.GetValue(matrixMaxValueUDF, i);
                            string stdValue = oDbDataSource.GetValue(matrixStdValueUDF, i);
                            string actValue = oDbDataSource.GetValue(matrixActValueUDF, i);
                            string tolPer = oDbDataSource.GetValue(matrixTolPerUDF, i);

                            double dblTolPer = tolPer == string.Empty ? 1 : double.Parse(tolPer);
                            dblTolPer = dblTolPer == 0 ? 1 : dblTolPer;

                            double dblMinValue = minValue == string.Empty ? 0 : double.Parse(minValue);
                            double dblMaxValue = maxValue == string.Empty ? 0 : double.Parse(maxValue);
                            double dblStdValue = stdValue == string.Empty ? 0 : double.Parse(stdValue);
                            double dblActValue = actValue == string.Empty ? 0 : double.Parse(actValue);

                            double dblMinStdValue = dblStdValue;
                            double dblMaxStdValue = dblStdValue;


                            if (dblTolPer > 1)
                            {
                                dblMinValue = dblMinValue - (dblMinValue * dblTolPer / 100);
                                dblMaxValue = dblMaxValue + (dblMaxValue * dblTolPer / 100);
                                dblMinStdValue = dblMinStdValue - (dblMinStdValue * dblTolPer / 100);
                                dblMaxStdValue = dblMaxStdValue + (dblMaxStdValue * dblTolPer / 100);
                            }

                            if (dblActValue >= dblMinStdValue && dblActValue <= dblMaxStdValue)
                            {
                                oMatrix.CommonSetting.SetRowBackColor(i + 1, -1);
                                oMatrix.CommonSetting.SetRowFontColor(i + 1, -1);
                                return;
                            }
                            else
                            {
                                oMatrix.CommonSetting.SetRowBackColor(i + 1, (int)SAPCommonColorEnum.Red);
                                oMatrix.CommonSetting.SetRowFontColor(i + 1, (int)SAPCommonColorEnum.White);
                            }

                            if (dblActValue >= dblMinValue && dblActValue <= dblMaxValue)
                            {
                                oMatrix.CommonSetting.SetRowBackColor(i + 1, -1);
                                oMatrix.CommonSetting.SetRowFontColor(i + 1, -1);
                            }
                            else
                            {
                                oMatrix.CommonSetting.SetRowBackColor(i + 1, (int)SAPCommonColorEnum.Red);
                                oMatrix.CommonSetting.SetRowFontColor(i + 1, (int)SAPCommonColorEnum.White);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        public void LoadForm(string MenuID)
        {
            try
            {
                clsVariables.boolCFLSelected = false;
                if (MenuID == formMenuUID)
                {
                    objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.FindRecord), false);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRecord), false);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.FirstRecord), false);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.LastRecord), false);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.NextRecord), false);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.PreviousRecord), false);
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                    oMatrix.CommonSetting.EnableArrowKey = true;
                    string addonName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name; //New Menu Name in Add-on Layouts

                    string ReportType = objclsComman.SelectRecord("SELECT \"CODE\" FROM RTYP WHERE \"MNU_ID\" = '" + MenuID + "' AND \"ADD_NAME\" = '" + addonName + "'");
                    if (ReportType != string.Empty)
                    {
                        oForm.ReportType = ReportType; //(Code of RTYP table)
                    }
                }
                oForm = oApplication.Forms.ActiveForm;
                oItem = oForm.Items.Item("DocEntry");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item(baseEntryUID);
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item(baseLineUID);
                oItem.EnableinFindMode();
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }
        #endregion
    }
}
