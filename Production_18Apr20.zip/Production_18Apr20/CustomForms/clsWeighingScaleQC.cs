using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;

namespace Production
{
    class clsWeighingScaleQC : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        public const string formTypeEx = "WEIGHINGSCALEQC";
        public const string formMenuUID = "WEIGHINGSCALEQC";
        public const string objType = "WEIGHINGSCALEQC";
        const string matrixUID = "mtx";
        const string matrixPrimaryUDF = "U_RecNo";
        const string matrixPrimaryColumnUID = "V_13";

        public const string headerTable = "@WEIGHINGSCALEQC";
        public const string rowTable = "@WEIGHINGSCALEQC1";

        public const string matrixQCEntryUDF = "U_QCEn";
        const string matrixQCEntryUID = "V_10";
        public const string matrixShiftUDF = "U_Shift";
        public const string matrixShiftUID = "V_14";

        const string CFL_JC = "CFL_JC";
        const string CFL_BAR = "CFL_BAR";
        const string CFL_ITEM = "CFL_ITEM";
        const string CFL_REC = "CFL_REC";
        const string CFL_MAC = "CFL_MAC";
        const string CFL_RWHS = "CFL_RWHS";
        const string CFL_RTWHS = "CFL_RTWHS";
        const string CFL_RBAT = "CFL_RBAT";

        const string docDateUDF = "U_DocDate";
        const string jbDocNumUID = "JBNo";
        const string jbDocNumUDF = "U_JBNo";
        const string jbDocEntryUDF = "U_JBEn";
        const string jbDocDateUDF = "U_JBDate";
        const string productCodeUDF = "U_PrdCode";
        const string productNameUDF = "U_PrdName";
        const string shiftUDF = "U_Shift";
        const string conversionRateUDF = "U_ConvRate";
        public const string matrixPackUnitUDF = "U_PackUnit";

        public const string matrixCheckUDF = "U_Chk";

        public const string matrixBarCodeUDF = "U_BarCode";
        const string matrixBarCodeUID = "V_7";

        const string matrixGrossWtUID = "";
        public const string matrixGrossWtUDF = "U_GrWt";

        const string matrixTareWtUID = "";
        public const string matrixTareWtUDF = "U_TareWt";

        const string matrixNetWtUID = "";
        public const string matrixNetWtUDF = "U_NetWt";
        const string matrixStkQtyUDF = "U_StkQty";
        public const string matrixPackQtyUDF = "U_PackQty";

        public const string matrixUOMBaseQtyUDF = "U_UOMBQty";
        const string matrixWhsCodeUDF = "U_WhsCode";
        const string matrixWhsCodeUID = "V_11";
        public const string matrixBatchUDF = "U_Batch";
        const string matrixBatchUID = "V_0";
        const string matrixWeighingScaleDocEntryUDF = "U_BaseEn";
        const string matrixBasePackQtyUDF = "U_BPackQty";

        const string matrixQCStatusUID = "V_9";
        public const string matrixQCStatusUDF = "U_QCStatus";

        public const string matrixReceiptNoUDF = "U_RecNo";
        const string matrixReceiptNoUID = "V_13";
        const string matrixReceiptEntryUDF = "U_RecEn";

        const string matrixToWhsCodeUDF = "U_ToWhs";
        const string matrixToWhsCodeUID = "V_17";

        const string machineCodeUDF = "U_MacCode";
        const string machineNameUDF = "U_MacName";

        const string matrixITDocNumUDF = "U_ITNo";
        const string matrixITDocEntryUDF = "U_ITEn";

        const string buttonCreateITUID = "btnIT";
        const string buttonMultipleQCAssignment = "btnMQC";
        const string buttonRefreshCalculation = "btnRef";

        const string unApprovedWhsCode = "QC-Unapp";
        const string passWhsCode = "QC-Pass";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank. Please select series.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select Product Code", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion

                            #region Create Inventory Transfer
                            else if (pVal.ItemUID == buttonCreateITUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                //string itEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(itDocEntryUDF, 0).Trim();
                                //string receiptEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(matrixReceiptEntryUDF, 0).Trim();
                                //if (receiptEntry == string.Empty)
                                //{
                                //    oApplication.StatusBar.SetText("Please select receipt entry.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                //    return;
                                //}
                                sbQuery.Length = 0;
                                sbQuery.Append("SELECT 1 FROM \"" + rowTable + "\" WHERE \"DocEntry\" = '" + docEntry + "' AND \"" + matrixQCEntryUDF + "\" = '0'");
                                string isExist = objclsComman.SelectRecord(sbQuery.ToString());
                                if (isExist.Trim() == "1")
                                {
                                    oApplication.StatusBar.SetText("Please create QC for all rows.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                CreateIT(docEntry);
                            }
                            #endregion

                            #region Multiple QC Assignment
                            else if (pVal.ItemUID == buttonMultipleQCAssignment)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).Trim();

                                clsVariables.BaseFormUID = oForm.UniqueID;
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                int lineId = objclsComman.GetSelectedRowNo(oMatrix);
                                if (lineId == -1)
                                {
                                    oApplication.StatusBar.SetText("Please select base QC entry row to copy to other rows.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                string qcEntry = oForm.DataSources.DBDataSources.Item(rowTable).GetValue(matrixQCEntryUDF, lineId - 1).Trim();
                                if (qcEntry == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please create QC entry first.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                string formDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                clsVariables.BaseForm = oForm;
                                clsMultipleQCAssignment obj = new clsMultipleQCAssignment();
                                obj.LoadForm(formDocEntry, qcEntry);
                            }
                            #endregion


                            #region Refresh Calculation
                            else if (pVal.ItemUID == buttonRefreshCalculation)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                RefreshCalc(oForm);
                            }
                            #endregion

                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion

                        #region T_et_MATRIX_LINK_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_MATRIX_LINK_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixQCEntryUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    if (!(oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_VIEW_MODE))
                                    {
                                        oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                        return;
                                    }
                                    string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                    string docNum = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).Trim();

                                    clsVariables.BaseFormUID = oForm.UniqueID;
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    string lineId = oForm.DataSources.DBDataSources.Item(rowTable).GetValue(CommonFields.LineId, pVal.Row - 1).Trim();
                                    string qcDocEntry = oForm.DataSources.DBDataSources.Item(rowTable).GetValue(matrixQCEntryUDF, pVal.Row - 1).Trim();
                                    qcDocEntry = qcDocEntry == string.Empty ? "0" : qcDocEntry;
                                    //string qcDocEntry = objclsComman.SelectRecord("SELECT \"DocEntry\" FROM \"" + clsWeighingScaleQCParameter.headerTable + "\" WHERE \"U_BaseEn\" = '" + docEntry + "' AND  \"" + clsWeighingScaleQCParameter.baseLineUDF + "\" = '" + lineId + "'");
                                    clsWeighingScaleQCParameter obj = new clsWeighingScaleQCParameter();
                                    obj.LoadForm(clsWeighingScaleQCParameter.formTypeEx);
                                    oForm = oApplication.Forms.ActiveForm;
                                    if (qcDocEntry != "0")
                                    {
                                        oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(CommonFields.DocEntry).Specific;
                                        oEdit.String = qcDocEntry;
                                        oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                    }
                                    else
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("BaseEn").Specific;
                                        oEdit.String = docEntry;
                                        string itemCode = string.Empty;
                                        sbQuery = new StringBuilder();
                                        sbQuery.Append(" SELECT \"" + productCodeUDF + "\",\"" + productNameUDF + "\",\"" + matrixTareWtUDF + "\",");
                                        sbQuery.Append(" \"" + matrixBarCodeUDF + "\",\"" + matrixNetWtUDF + "\",\"" + matrixGrossWtUDF + "\"  ");
                                        sbQuery.Append(" FROM \"" + headerTable + "\" T0");
                                        sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\"  = T1.\"DocEntry\" ");
                                        sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + docEntry + "' AND T1.\"LineId\" = '" + lineId + "'");

                                        SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                        if (!oRs.EoF)
                                        {
                                            oDbDataSource = oForm.DataSources.DBDataSources.Item(clsWeighingScaleQCParameter.headerTable);

                                            itemCode = oRs.Fields.Item(productCodeUDF).Value;
                                            oDbDataSource.SetValue(clsWeighingScaleQCParameter.baseLineUDF, 0, lineId);
                                            oDbDataSource.SetValue(productCodeUDF, 0, oRs.Fields.Item(productCodeUDF).Value);
                                            oDbDataSource.SetValue(productNameUDF, 0, oRs.Fields.Item(productNameUDF).Value);
                                            oDbDataSource.SetValue(matrixBarCodeUDF, 0, oRs.Fields.Item(matrixBarCodeUDF).Value);
                                            oDbDataSource.SetValue(matrixTareWtUDF, 0, oRs.Fields.Item(matrixTareWtUDF).Value);
                                            oDbDataSource.SetValue(matrixNetWtUDF, 0, oRs.Fields.Item(matrixNetWtUDF).Value);
                                            oDbDataSource.SetValue(matrixGrossWtUDF, 0, oRs.Fields.Item(matrixGrossWtUDF).Value);
                                        }
                                        objclsComman.ReleaseObject(oRs);

                                        string qcSpecHeaderTable = "@QCSPEC";
                                        string qcSpecRowTable = "@QCSPEC1";

                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                        oMatrix.FlushToDataSource();
                                        oDbDataSource = oForm.DataSources.DBDataSources.Item(clsWeighingScaleQCParameter.rowTable);
                                        oDbDataSource.Clear();
                                        sbQuery.Length = 0;
                                        sbQuery.Append(" SELECT \"U_ParaCode\",\"U_ParaName\",\"U_MinValue\",\"U_MaxValue\",\"U_StdValue\",\"U_TolPer\",\"U_MethAna\",\"U_Unit\" ");
                                        sbQuery.Append(" ,\"U_TolAcc\",\"U_LotSize\" ");
                                        sbQuery.Append(" FROM \"" + qcSpecHeaderTable + "\" T0 ");
                                        sbQuery.Append(" INNER JOIN \"" + qcSpecRowTable + "\" T1 ON T0.\"Code\" = T1.\"Code\" ");
                                        sbQuery.Append(" WHERE T0.\"" + productCodeUDF + "\" = '" + itemCode + "' ");

                                        oRs = objclsComman.returnRecord(sbQuery.ToString());
                                        int row = 0;
                                        while (!oRs.EoF)
                                        {
                                            oDbDataSource.InsertRecord(oDbDataSource.Size);
                                            oDbDataSource.SetValue("U_ParaCode", row, oRs.Fields.Item("U_ParaCode").Value);
                                            oDbDataSource.SetValue("U_ParaName", row, oRs.Fields.Item("U_ParaName").Value);
                                            oDbDataSource.SetValue("U_MinValue", row, oRs.Fields.Item("U_MinValue").Value);
                                            oDbDataSource.SetValue("U_MaxValue", row, oRs.Fields.Item("U_MaxValue").Value);
                                            oDbDataSource.SetValue("U_StdValue", row, oRs.Fields.Item("U_StdValue").Value);
                                            oDbDataSource.SetValue("U_TolPer", row, oRs.Fields.Item("U_TolPer").Value);
                                            oDbDataSource.SetValue("U_MethAna", row, oRs.Fields.Item("U_MethAna").Value);
                                            oDbDataSource.SetValue("U_TolAcc", row, oRs.Fields.Item("U_TolAcc").Value);
                                            oDbDataSource.SetValue("U_LotSize", row, oRs.Fields.Item("U_LotSize").Value);
                                            oDbDataSource.SetValue("U_Unit", row, oRs.Fields.Item("U_Unit").Value);
                                                
                                            oRs.MoveNext();
                                            row++;
                                        }
                                        oMatrix.LoadFromDataSource();
                                        objclsComman.ReleaseObject(oRs);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == jbDocNumUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);

                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;

                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT T0.\"" + jbDocEntryUDF + "\" ");
                                sbQuery.Append(" FROM \"" + clsWeighingScale.headerTable + "\" T0 ");
                                sbQuery.Append(" WHERE  \"" + CommonFields.Status + "\" != 'C' ");

                                objclsComman.AddChooseFromList_WithCond(oForm, CFL_JC, "202", sbQuery.ToString(), CommonFields.DocEntry, alCondVal);
                            }
                            else if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixReceiptNoUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    string jobEntry = oDbDataSource.GetValue(jbDocEntryUDF, 0).Trim();

                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;

                                    sbQuery.Length = 0;
                                    sbQuery.Append(" SELECT T1.\"" + matrixReceiptEntryUDF + "\" ");
                                    sbQuery.Append(" FROM \"" + clsWeighingScale.headerTable + "\" T0 ");
                                    sbQuery.Append(" INNER JOIN \"" + clsWeighingScale.rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
                                    sbQuery.Append(" WHERE T0.\"" + jbDocEntryUDF + "\" = '" + jobEntry + "'");

                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_REC, "59", sbQuery.ToString(), CommonFields.DocEntry, alCondVal);
                                }
                                else if (pVal.ColUID == matrixBarCodeUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    string itemCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).Trim();

                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string receiptEntry = oDbDataSource.GetValue(matrixReceiptEntryUDF, pVal.Row - 1).Trim();

                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;

                                    sbQuery.Length = 0;
                                    sbQuery.Append(" SELECT T1.\"" + clsWeighingScale.matrixBarCodeUDF + "\" ");
                                    sbQuery.Append(" FROM \"" + clsWeighingScale.headerTable + "\" T0 ");
                                    sbQuery.Append(" INNER JOIN \"" + clsWeighingScale.rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
                                    sbQuery.Append(" WHERE T1.\"" + matrixReceiptEntryUDF + "\" = '" + receiptEntry + "'");

                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_BAR, "10000044", sbQuery.ToString(), CommonFields.LotNumber, alCondVal);
                                }
                                else if (pVal.ColUID == matrixBatchUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    string itemCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).Trim();

                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string receiptEntry = oDbDataSource.GetValue(matrixReceiptEntryUDF, pVal.Row - 1).Trim();

                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;

                                    sbQuery.Length = 0;
                                    sbQuery.Append(objclsComman.GetBatchNoQuery(itemCode, receiptEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry)));

                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_RBAT, "10000044", sbQuery.ToString(), CommonFields.DistNumber, alCondVal);
                                }
                                //else if (pVal.ColUID == matrixToWhsCodeUID)
                                //{
                                //    oForm = oApplication.Forms.Item(pVal.FormUID);
                                //    string itemCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).Trim();

                                //    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                //    string qcStatus = oDbDataSource.GetValue(matrixQCStatusUDF, pVal.Row - 1).Trim();

                                //    ArrayList alCondVal = new ArrayList();
                                //    ArrayList temp = new ArrayList();
                                //    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;

                                //    sbQuery.Length = 0;
                                //    if (qcStatus == "P" || qcStatus == "R")
                                //    {
                                //        sbQuery.Append("SELECT\"WhsCode\" FROM OWHS Where \"U_QCStatus\" = '" + qcStatus + "' ");
                                //    }

                                //    objclsComman.AddChooseFromList_WithCond(oForm, CFL_RTWHS, "64", sbQuery.ToString(), CommonFields.WhsCode, alCondVal);
                                //}
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == CFL_JC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                string itemCode = oDataTable.GetValue(CommonFields.ItemCode, 0).ToString();
                                string isQCSPecificationExist = objclsComman.SelectRecord("SELECT 1 FROM \"" + clsQCSpecification.headerTable + "\" WHERE \"U_PrdCode\" = '" + itemCode + "'");
                                if (isQCSPecificationExist != "1")
                                {
                                    oApplication.StatusBar.SetText("Please specified the QC Specification for Job Card Item.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                oDbDataSource.SetValue(jbDocNumUDF, 0, oDataTable.GetValue(CommonFields.DocNum, 0).ToString());
                                oDbDataSource.SetValue(jbDocEntryUDF, 0, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());
                                DateTime docDate = DateTime.Parse(oDataTable.GetValue(CommonFields.PostDate, 0).ToString());
                                oDbDataSource.SetValue(jbDocDateUDF, 0, objclsComman.ConvertDateToSAPDateFormat(docDate));
                                oDbDataSource.SetValue(productCodeUDF, 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                string itemName = objclsComman.SelectRecord("SELECT \"" + CommonFields.ItemName + "\" FROM OITM WHERE \"" + CommonFields.ItemCode + "\" = '" + oDataTable.GetValue(CommonFields.ItemCode, 0).ToString() + "' ");
                                oDbDataSource.SetValue(productNameUDF, 0, itemName);
                                oDbDataSource.SetValue(machineCodeUDF, 0, oDataTable.GetValue(machineCodeUDF, 0).ToString());

                                sbQuery.Length = 0;
                                //sbQuery.Append(" SELECT T0.\"" + CommonFields.Code + "\",T0.\"" + CommonFields.Name + "\" ");
                                //sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                //sbQuery.Append(" INNER JOIN \"" + clsMachineMaster.rowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\" = T1.\"" + CommonFields.Code + "\" ");
                                //sbQuery.Append(" WHERE \"" + productCodeUDF + "\" = '" + oDataTable.GetValue(CommonFields.ItemCode, 0).ToString() + "' ");

                                //SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                //if (oRs.RecordCount > 0)
                                //{
                                //    oDbDataSource.SetValue(machineCodeUDF, 0, oRs.Fields.Item(CommonFields.Code).Value.ToString());
                                //    oDbDataSource.SetValue(machineNameUDF, 0, oRs.Fields.Item(CommonFields.Name).Value.ToString());
                                //}
                                sbQuery.Append(" SELECT T0.\"" + CommonFields.Name + "\" ");
                                sbQuery.Append(" FROM \"" + clsMachineMaster.headerTable + "\" T0 ");
                                sbQuery.Append(" WHERE T0.\"" + CommonFields.Code + "\" = '" + oDataTable.GetValue(machineCodeUDF, 0).ToString() + "'");

                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                if (oRs.RecordCount > 0)
                                {
                                    //oDbDataSource.SetValue(machineCodeUDF, 0, oRs.Fields.Item(CommonFields.Code).Value.ToString());
                                    oDbDataSource.SetValue(machineNameUDF, 0, oRs.Fields.Item(CommonFields.Name).Value.ToString());
                                }
                                objclsComman.ReleaseObject(oRs);
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_REC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixReceiptNoUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocNum, 0).ToString());
                                oDbDataSource.SetValue(matrixReceiptEntryUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());

                                string warehouse = objclsComman.SelectRecord(" SELECT \"" + CommonFields.WhsCode + "\" FROM IGN1 WHERE \"" + CommonFields.DocEntry + "\" = '" + oDataTable.GetValue(CommonFields.DocEntry, 0).ToString() + "'");
                                oDbDataSource.SetValue(matrixWhsCodeUDF, pVal.Row - 1, warehouse);
                                oDbDataSource.SetValue(matrixQCEntryUDF, pVal.Row - 1, "0");

                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixReceiptNoUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_BAR)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixBarCodeUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.LotNumber, 0).ToString());
                                oDbDataSource.SetValue(matrixBatchUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DistNumber, 0).ToString());

                                string recEntry = oDbDataSource.GetValue(matrixReceiptEntryUDF, pVal.Row - 1);
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT T0.\"" + clsWeighingScale.matrixCoreSrNoUDF + "\",T0.\"" + clsWeighingScale.matrixGrossWtUDF + "\" ");
                                sbQuery.Append(" ,T0.\"" + clsWeighingScale.matrixTareWtUDF + "\",T0.\"" + clsWeighingScale.matrixStkQtyUDF + "\",T0.\"" + clsWeighingScale.matrixPackQtyUDF + "\"  ");
                                sbQuery.Append(" ,T0.\"" + clsWeighingScale.matrixPackUnitUDF + "\" ,T0.\"" + CommonFields.DocEntry + "\" ");
                                sbQuery.Append(" FROM \"" + clsWeighingScale.rowTable + "\" T0");
                                sbQuery.Append(" WHERE \"" + matrixReceiptEntryUDF + "\" = '" + recEntry + "'  ");
                                sbQuery.Append(" AND \"" + clsWeighingScale.matrixBarCodeUDF + "\" = '" + oDataTable.GetValue(CommonFields.LotNumber, 0).ToString() + "'  ");

                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                if (oRs.RecordCount > 0)
                                {
                                    oDbDataSource.SetValue(clsWeighingScale.matrixCoreSrNoUDF, pVal.Row - 1, oRs.Fields.Item(clsWeighingScale.matrixCoreSrNoUDF).Value);
                                    oDbDataSource.SetValue(clsWeighingScale.matrixGrossWtUDF, pVal.Row - 1, oRs.Fields.Item(clsWeighingScale.matrixGrossWtUDF).Value);
                                    oDbDataSource.SetValue(clsWeighingScale.matrixTareWtUDF, pVal.Row - 1, oRs.Fields.Item(clsWeighingScale.matrixTareWtUDF).Value);
                                    oDbDataSource.SetValue(clsWeighingScale.matrixStkQtyUDF, pVal.Row - 1, oRs.Fields.Item(clsWeighingScale.matrixStkQtyUDF).Value);
                                    oDbDataSource.SetValue(clsWeighingScale.matrixPackQtyUDF, pVal.Row - 1, oRs.Fields.Item(clsWeighingScale.matrixPackQtyUDF).Value);
                                    oDbDataSource.SetValue(matrixBasePackQtyUDF, pVal.Row - 1, oRs.Fields.Item(clsWeighingScale.matrixPackQtyUDF).Value);
                                    oDbDataSource.SetValue(clsWeighingScale.matrixPackUnitUDF, pVal.Row - 1, oRs.Fields.Item(clsWeighingScale.matrixPackUnitUDF).Value);
                                    oDbDataSource.SetValue(matrixWeighingScaleDocEntryUDF, pVal.Row - 1, oRs.Fields.Item(CommonFields.DocEntry).Value);

                                }
                                objclsComman.ReleaseObject(oRs);
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixReceiptNoUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_MAC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(machineCodeUDF, 0, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue(machineNameUDF, 0, oDataTable.GetValue(CommonFields.Name, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_ITEM)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue(productCodeUDF, 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue(productNameUDF, 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_RBAT)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixBatchUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DistNumber, 0).ToString());
                                oMatrix.LoadFromDataSource();

                                string shift = oDataTable.GetValue(CommonFields.MnfSerial, 0).ToString();
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue(shiftUDF, 0, shift);
                                oMatrix.Columns.Item(matrixBatchUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_RWHS)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixWhsCodeUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixWhsCodeUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_RTWHS)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixToWhsCodeUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixToWhsCodeUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formTypeEx)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypeEx && pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString();
                                    if (code.Trim() == string.Empty)
                                    {
                                        LoadForm(Convert.ToString((int)SAPMenuEnum.AddRecord));
                                        return;
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "Series")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                    if (oCombo.Value == null)
                                    {

                                    }
                                    else
                                    {
                                        int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                        string docNum = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), objType).ToString();
                                        oDBDataSource.SetValue(CommonFields.DocNum, 0, Convert.ToString(docNum));
                                    }
                                }
                            }
                            else if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixQCStatusUID)
                                {
                                    RefreshCalc(oForm);
                                }
                            }
                        }
                        #endregion

                        #region F_et_KEY_DOWN
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            string jbDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(jbDocEntryUDF, 0).Trim();
                            string productCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(productCodeUDF, 0).Trim();

                            if (pVal.ColUID == matrixBarCodeUID)
                            {
                                if (pVal.CharPressed == 9)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string recEn = oDbDataSource.GetValue(matrixReceiptEntryUDF, pVal.Row - 1);
                                    clsVariables.BaseFormUID = oForm.UniqueID;
                                    clsVariables.BaseFormTypeEx = oForm.TypeEx;
                                    clsBarCodeSelection objclsBarCodeSelection = new clsBarCodeSelection();
                                    objclsBarCodeSelection.LoadForm(pVal.Row.ToString(), recEn, productCode);
                                }
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "DocDate")
                            {
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    objclsComman.FillCombo_Series_Custom(oForm, objType, pVal.ItemUID, "Load");
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                    if (oCombo.ValidValues.Count == 0)
                                    {
                                        oForm.DataSources.DBDataSources.Item(headerTable).SetValue(CommonFields.DocNum, 0, string.Empty);
                                    }
                                }
                            }

                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;

                        AddRow(matrixUID, rowTable, matrixPrimaryUDF);

                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID, rowTable, matrixPrimaryUDF);
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  IFNULL(\"" + matrixReceiptNoUDF + "\",'')='' AND \"DocEntry\" = '" + docEntry + "'");
                        }
                        else
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  ISNULL(\"" + matrixReceiptNoUDF + "\",'')='' AND \"DocEntry\" = '" + docEntry + "'");
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                        {
                            oMatrix.FlushToDataSource();
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            for (int i = 0; i < oDbDataSource.Size; i++)
                            {
                                sbQuery.Length = 0;
                                if (oDbDataSource.GetValue(matrixQCEntryUDF, i) == string.Empty)
                                {
                                    oMatrix.CommonSetting.SetRowBackColor(i + 1, (int)SAPCommonColorEnum.White);
                                    continue;
                                }
                                sbQuery.Append(" SELECT \"U_QCOffSt\" FROM \"" + clsWeighingScaleQCParameter.headerTable + "\" ");
                                sbQuery.Append(" WHERE \"" + CommonFields.DocEntry + "\" ='" + oDbDataSource.GetValue(matrixQCEntryUDF, i) + "'");
                                string QCOffSt = objclsComman.SelectRecord(sbQuery.ToString());
                                if (QCOffSt == "Y")
                                {
                                    oMatrix.CommonSetting.SetRowBackColor(i + 1, (int)SAPCommonColorEnum.Green);
                                }
                                else
                                {
                                    oMatrix.CommonSetting.SetRowBackColor(i + 1, (int)SAPCommonColorEnum.White);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        public void LoadForm(string MenuID)
        {
            try
            {
                clsVariables.boolCFLSelected = false;
                if (MenuID == formMenuUID)
                {
                    objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                    oMatrix.CommonSetting.EnableArrowKey = true;
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
                    oMatrix.AddRow(1, 1);
                    //oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixActivityColumnUID, 1);
                    //objclsComman.FillCombo(oCombo, "SELECT TaskID,Name FROM PMC6");
                }
                oForm = oApplication.Forms.ActiveForm;
                EnableControls(oForm.UniqueID);

                #region Series And DocNum

                try
                {
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                    oEdit.String = "t";

                    objclsComman.FillCombo_Series_Custom(oForm, objType, "DocDate", "Load");

                    #region Set DocNum
                    string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    if (defaultseries == string.Empty)
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                        defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    }
                    string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                    #endregion

                }
                catch { }
                #endregion

                oItem = oForm.Items.Item("DocNum");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item("DocEntry");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item("Series");
                oItem.EnableinAddMode();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_ConvRate", 0, "1");
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsComman.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void DisableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            //oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), false);
            //oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), false);
            //oForm.Items.Item(woDocNumItemUID).Disable();
        }
        private void EnableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            //oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
            //oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
            // oForm.Items.Item(woDocNumItemUID).Enable();
        }


        private void CreateIT(string DocEntry)
        {

            SAPbobsCOM.StockTransfer oDoc = (SAPbobsCOM.StockTransfer)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oStockTransfer);
            oDoc.DocDate = DateTime.Now;
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT T1.\"" + matrixWhsCodeUDF + "\" AS \"From_WhsCode\",T1.\"" + matrixToWhsCodeUDF + "\" AS \"To_WhsCode\",T0.\"" + productCodeUDF + "\" ");
                sbQuery.Append(" ,T2.\"" + CommonFields.ManBtchNum + "\" ");
                sbQuery.Append(" ,SUM(T1.\"" + matrixPackQtyUDF + "\" ) AS \"" + matrixPackQtyUDF + "\"  ");
                sbQuery.Append(" ,T1.\"" + matrixBarCodeUDF + "\" ");
                sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
                sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
                sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T0.\"" + productCodeUDF + "\" = T2.\"" + CommonFields.ItemCode + "\" ");
                sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' AND T1.\"" + matrixCheckUDF + "\" ='Y'  ");
                //sbQuery.Append(" GROUP BY T0.\"" + matrixWhsCodeUDF + "\",T1.\"" + matrixWhsCodeUDF + "\",T0.\"" + productCodeUDF + "\" ");
                //sbQuery.Append(" ,T0.\"" + matrixReceiptEntryUDF + "\",T2.\"" + CommonFields.ManBtchNum + "\" ");
                if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                {
                    sbQuery.Append(" AND IFNULL(T1.\"" + matrixITDocEntryUDF + "\",'') = '' ");
                }
                else
                {
                    sbQuery.Append(" AND ISNULL(T1.\"" + matrixITDocEntryUDF + "\",'') = '' ");
                }
                sbQuery.Append(" GROUP BY T1.\"" + matrixWhsCodeUDF + "\",T1.\"" + matrixToWhsCodeUDF + "\",T0.\"" + productCodeUDF + "\" ");
                sbQuery.Append(" ,T2.\"" + CommonFields.ManBtchNum + "\" ");
                sbQuery.Append("  ,T1.\"" + matrixBarCodeUDF + "\" ");

                oRs = objclsComman.returnRecord(sbQuery.ToString());
                if (oRs.RecordCount == 0)
                {
                    oApplication.StatusBar.SetText("No Rows for inventory transfer", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    return;
                }

                //string receiptDocEntry = oRs.Fields.Item(matrixReceiptEntryUDF).Value.ToString();
                string packQuantity = oRs.Fields.Item(matrixPackQtyUDF).Value.ToString() == string.Empty ? "0" : oRs.Fields.Item(matrixPackQtyUDF).Value.ToString();

                //string stockQuantity = oRs.Fields.Item(matrixStkQtyUDF).Value.ToString() == string.Empty ? "0" : oRs.Fields.Item(matrixStkQtyUDF).Value.ToString();
                double dblPackQuantity = double.Parse(packQuantity);
                if (dblPackQuantity == 0)
                {
                    oApplication.StatusBar.SetText("Pack quantity can't be zero", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    return;
                }
                int i = oApplication.MessageBox("Do you really want to Create Inventory Transfer", 1, "Yes", "No");
                if (i == 2)
                {
                    return;
                }
                oDoc.FromWarehouse = oRs.Fields.Item("From_WhsCode").Value.ToString();
                int row = 0;
                while (!oRs.EoF)
                {
                    if (row > 0)
                    {
                        oDoc.Lines.Add();
                    }
                    if (row == 0)
                    {
                        oDoc.ToWarehouse = oRs.Fields.Item("To_WhsCode").Value.ToString();
                    }
                    string itemCode = oRs.Fields.Item(productCodeUDF).Value.ToString();
                    oDoc.Lines.ItemCode = itemCode;
                    oDoc.Lines.WarehouseCode = oRs.Fields.Item("To_WhsCode").Value.ToString();
                    packQuantity = oRs.Fields.Item(matrixPackQtyUDF).Value.ToString() == string.Empty ? "0" : oRs.Fields.Item(matrixPackQtyUDF).Value.ToString();
                    dblPackQuantity = double.Parse(packQuantity);

                    oDoc.Lines.Quantity = dblPackQuantity;
                    if (oRs.Fields.Item(CommonFields.ManBtchNum).Value.ToString() == "Y")
                    {
                        //oDoc.Lines.SetCurrentLine(0);
                        oDoc.Lines.BatchNumbers.BatchNumber = oRs.Fields.Item(matrixBarCodeUDF).Value.ToString(); //objclsComman.SelectRecord(objclsComman.GetBatchNoQuery(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry)));
                        oDoc.Lines.BatchNumbers.Quantity = dblPackQuantity;
                        //oDoc.Lines.BatchNumbers.ManufacturerSerialNumber = oRs.Fields.Item(shiftUDF).Value.ToString(); //oDataTable.GetValue(shiftUDF, j).ToString(); //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                      //  oDoc.Lines.BatchNumbers.InternalSerialNumber = oRs.Fields.Item(matrixBarCodeUDF).Value.ToString(); //; //objclsComman.GetBatchNo(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));
                        oDoc.Lines.BatchNumbers.Add();
                    }
                    oDoc.Lines.SetCurrentLine(row);
                    oRs.MoveNext();
                    row++;
                }

                int retVal = oDoc.Add();
                if (retVal != 0)
                {
                    oApplication.StatusBar.SetText("Create Inventory Transfer Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                }
                else
                {
                    string newDocEntry = oCompany.GetNewObjectKey();
                    string newDocNum = objclsComman.SelectRecord("SELECT \"DocNum\" FROM OWTR WHERE \"DocEntry\" = '" + newDocEntry + "'");
                    sbQuery.Length = 0;
                    sbQuery.Append("UPDATE T0 SET \"" + matrixITDocEntryUDF + "\" = '" + newDocEntry + "',\"" + matrixITDocNumUDF + "\" = '" + newDocNum + "' FROM \"" + rowTable + "\" T0 WHERE \"DocEntry\" ='" + DocEntry + "' AND \"" + matrixCheckUDF + "\" = 'Y' ");
                    if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                    {
                        sbQuery.Append(" AND IFNULL(T0.\"" + matrixITDocEntryUDF + "\",'') = '' ");
                    }
                    else
                    {
                        sbQuery.Append(" AND ISNULL(T0.\"" + matrixITDocEntryUDF + "\",'') = '' ");
                    }
                    objclsComman.SelectRecord(sbQuery.ToString());
                    oApplication.StatusBar.SetText("Inventory Order Transfer " + newDocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    objclsComman.RefreshRecord();
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Create IT catch exception :" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                objclsComman.ReleaseObject(oRs);
            }
        }

        private void RefreshCalc(SAPbouiCOM.Form oForm)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);

            double netWtvalue = 0;
            double qtyalue = 0;

            double totalpassTot = 0;
            double totalholdTot = 0;
            double totalrejTot = 0;
            double totalvoidTot = 0;
            double totalpassQTot = 0;
            double totalholdQTot = 0;
            double totalrejQTot = 0;
            double totalvoidQTot = 0;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string qcStatus = oDbDataSource.GetValue(matrixQCStatusUDF, i);
                netWtvalue = double.Parse(oDbDataSource.GetValue(matrixNetWtUDF, i));
                qtyalue = double.Parse(oDbDataSource.GetValue(matrixPackQtyUDF, i));

                if (qcStatus == "P")
                {
                    totalpassTot = totalpassTot + netWtvalue;
                    totalpassQTot = totalpassQTot + qtyalue;
                }
                else if (qcStatus == "H")
                { 
                    totalholdTot = totalholdTot + netWtvalue;
                    totalholdQTot= totalholdQTot + qtyalue;
                }
                else if (qcStatus == "R")
                { 
                    totalrejTot = totalrejTot + netWtvalue;
                    totalrejQTot = totalrejQTot + qtyalue;
                }
                else if (qcStatus == "V")
                { 
                    totalvoidTot = totalvoidTot + netWtvalue;
                    totalvoidQTot = totalvoidQTot + qtyalue;
                }
            }

            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_PassTot", 0, totalpassTot.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_HoldTot", 0, totalholdTot.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_RejTot", 0, totalrejTot.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_VoidTot", 0, totalvoidTot.ToString());

            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_PassQTot", 0, totalpassQTot.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_HoldQTot", 0, totalholdQTot.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_RejQTot", 0, totalrejQTot.ToString());
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_VoidQTot", 0, totalvoidQTot.ToString());
            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
            {
                oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
            }
        }
        #endregion
    }
}
