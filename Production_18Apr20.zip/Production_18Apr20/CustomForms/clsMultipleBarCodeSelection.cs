using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;

namespace Production
{
    class clsMultipleBarCodeSelection : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Grid oGrid;
        SAPbouiCOM.EditText oEdit;

        const string formTypeEx = "MULTIBARCODESEL";
        const string formMenuUID = "MULTIBARCODESEL";
        const string gridUID = "grd1";
        const string gridDataTableUID = "grdDT";

        const string jbDocEntryUDF = "U_JBEn";
        const string productCodeUDF = "U_PrdCode";

        const string buttonSelect = "btnSelect";

        StringBuilder sbQuery = new StringBuilder();

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Select
                            if (pVal.ItemUID == buttonSelect)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.DataTable oDT = oForm.DataSources.DataTables.Item(gridDataTableUID);
                                string barCode = string.Empty;
                                ArrayList alBarCode = new ArrayList();
                                for (int i = 0; i < oDT.Rows.Count; i++)
                                {
                                    if (oDT.GetValue("Select", i) == "Y")
                                    {
                                        alBarCode.Add(oDT.GetValue("BarCode", i));
                                    }
                                }
                                if (alBarCode.Count == 0)
                                {
                                    oApplication.StatusBar.SetText("No row selected", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }

                                string itemCode = oForm.DataSources.UserDataSources.Item(CommonFields.ItemCode).Value.ToString();

                                oForm.Items.Item("2").Click(SAPbouiCOM.BoCellClickType.ct_Regular);

                                SAPbouiCOM.Form oBaseForm = oApplication.Forms.Item(clsVariables.BaseFormUID);
                                SAPbouiCOM.Matrix oBaseMatrix = (SAPbouiCOM.Matrix)oBaseForm.Items.Item("mtx").Specific;
                                SAPbouiCOM.DBDataSource oDBDataSource = oBaseForm.DataSources.DBDataSources.Item(clsBarCodeAssignment.rowTable);
                                oBaseMatrix.FlushToDataSource();
                                oDBDataSource.Clear();
                                int rowNo = 1;
                                
                                for (int i = 0; i < alBarCode.Count; i++)
                                {
                                    oDBDataSource.InsertRecord(rowNo-1);
                                    
                                    oDBDataSource.SetValue("LineId", rowNo - 1, rowNo.ToString());
                                    oDBDataSource.SetValue("U_BarCode", rowNo - 1, alBarCode[i].ToString());
                                    oDBDataSource.SetValue("U_Chk", rowNo - 1, "Y");
                                    
                                    rowNo++;
                                }
                                oBaseMatrix.LoadFromDataSource();

                            }
                            #endregion

                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        public void LoadForm(string jbDocEntry, string productCode)
        {
            objclsComman.LoadXML(formMenuUID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_OK_MODE);
            oForm = oApplication.Forms.ActiveForm;

            oForm.DataSources.UserDataSources.Add(CommonFields.ItemCode, SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 50);
            oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(CommonFields.ItemCode).Specific;
            oEdit.DataBind.SetBound(true, "", CommonFields.ItemCode);
            oEdit.String = productCode;
            FillGrid(jbDocEntry, productCode);
        }

        public void FillGrid(string jbDocEntry, string productCode)
        {
            oForm = oApplication.Forms.ActiveForm;

            sbQuery.Length = 0;
            sbQuery.Append(" SELECT ROW_NUMBER() OVER (ORDER BY \"U_BarCode\" DESC) AS \"SrNo\",'N' \"Select\",\"U_BarCode\" AS \"BarCode\" ");
            sbQuery.Append(" FROM \"" + clsBarCodeGeneration.headerTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + clsBarCodeGeneration.rowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
            sbQuery.Append(" WHERE   NOT EXISTS ( ");
            sbQuery.Append(" SELECT 1  ");
            sbQuery.Append(" FROM \"" + clsBarCodeAssignment.rowTable + "\" IT0 WHERE T1.\"U_BarCode\" = IT0.\"U_BarCode\")");

            objclsComman.FillGrid(oForm.UniqueID, gridUID, gridDataTableUID, sbQuery.ToString());
            oGrid = (SAPbouiCOM.Grid)oForm.Items.Item(gridUID).Specific;
            for (int i = 0; i < oGrid.Columns.Count; i++)
            {
                if (oGrid.Columns.Item(i).TitleObject.Caption != "Select")
                {
                    oGrid.Columns.Item(i).Editable = false;
                }
            }
            oGrid.Columns.Item("Select").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox;
        }

        #endregion
    }
}
