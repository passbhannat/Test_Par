using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using System.Linq;

namespace Production
{
    class clsBatchInward : Connection
    {
        #region Variables

        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Form oBaseForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;

        string rowsFromDocumentTable = "SBDR";

        const string matrixDocUID = "35";
        const string matrixCreatedBatchesUID = "3";

        string matrixDocItemUID = "5";
        string matrixBatchBatchQuantityColumn = "5";
        string matrixBatchBatchQuantity1Column = "234000024";
        string matrixBatchBatchAttribute2Column = "8";

        const string matrixUID = "3";
        const string matrixBatchUID = "2";
        const string matrixShiftUID = "7";

        public const string headerTable = "OIGN";
        public const string rowTable = "IGN1";

        const string buttonPushBatchDetailsUID = "btnPush";
        const string buttonPushBatchDetailsCaption = "Push Batch";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {

                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Push Button 

                            if (pVal.ItemUID == buttonPushBatchDetailsUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oBaseForm = clsVariables.BaseForm;

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixDocUID).Specific;
                                int selectedRow = oMatrix.GetNextSelectedRow(0, SAPbouiCOM.BoOrderType.ot_SelectionOrder);
                                string baseItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixDocItemUID, selectedRow)).String;
                                SAPbobsCOM.Recordset oRs;
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT * ");
                                sbQuery.Append(" FROM \"" + clsWeighingScale.rowTable + "\" T0");
                                sbQuery.Append(" WHERE  \"" + CommonFields.DocEntry + "\" = '" + clsVariables.BaseEntry + "'");
                                sbQuery.Append(" AND T0.\"" + clsWeighingScale.matrixCheckUDF + "\" ='Y' AND ISNULL(T0.\"" + clsWeighingScale.matrixReceiptEntryUDF + "\",'') = '' ");

                                oRs = objclsComman.returnRecord(sbQuery.ToString());
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixCreatedBatchesUID).Specific;
                                int i = 1;
                                while (!oRs.EoF)
                                {
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBatchUID, i);
                                    oEdit.String = oRs.Fields.Item(clsWeighingScale.matrixBarCodeUDF).Value.ToString();
                                    try
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBatchBatchQuantityColumn, i);
                                        oEdit.String = oRs.Fields.Item(clsWeighingScale.matrixQtyUDF).Value.ToString();
                                    }
                                    catch
                                    {
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBatchBatchQuantity1Column, i);
                                        oEdit.String = oRs.Fields.Item(clsWeighingScale.matrixQtyUDF).Value.ToString();
                                    }
                                    //oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixShiftUID, i);
                                    //oEdit.String = oRs.Fields.Item("U_BatchAt1").Value.ToString();
                                    //oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBatchBatchAttribute2Column, i);
                                    //oEdit.String = oRs.Fields.Item("U_BatchAt2").Value.ToString();
                                    oRs.MoveNext();
                                    i++;
                                }
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE)
                                {
                                    oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                }
                                objclsComman.ReleaseObject(oRs);
                            }
                            #endregion

                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (clsVariables.BaseObjectType == clsWeighingScale.objType)
                            {
                                SAPbouiCOM.Item oNewItem = oForm.Items.Add(buttonPushBatchDetailsUID, SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                                oItem = oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Cancel));
                                oNewItem.Left = oItem.Left + oItem.Width + 10;
                                oNewItem.Top = oItem.Top;
                                oNewItem.Height = oItem.Height;
                                oNewItem.Width = oItem.Width;
                                SAPbouiCOM.Button oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                                oButton.Caption = buttonPushBatchDetailsCaption;
                            }

                        }
                        #endregion

                        #region F_et_KEY_DOWN
                       else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_KEY_DOWN)
                        {
                            if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixBatchUID)
                                {
                                    if (clsVariables.BaseObjectType == clsWeighingScale.objType)
                                    {
                                        if (pVal.CharPressed == 9)
                                        {
                                            oForm = oApplication.Forms.Item(pVal.FormUID);
                                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                            //oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(pVal.ColUID, pVal.Row);
                                            //oEdit.String = clsVariables.BaseBatch;
                                            //try
                                            //{
                                            //    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixShiftUID, pVal.Row);
                                            //    oEdit.String = clsVariables.BaseShift;
                                            //}
                                            //catch { }
                                        }
                                    }
                                }
                            }

                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion
    }
}
