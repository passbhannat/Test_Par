using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using System.Linq;

namespace Production
{
    class clsReceiptFromProduction : Connection
    {
        #region Variables

        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.ComboBox oCombo;

        const string matrixUID = "13";

        public const string headerTable = "OIGN";
        public const string rowTable = "IGN1";

        const string matrixOrdNoUID = "61";
        const string matrixOrdSeriesUID = "10001006";
        const string matrixItemCodeUID = "1";
        const string matrixQuantityUID = "9";
        const string matrixTotalWtUID = "U_TotWt";

        const string matrixBaseLineUDF = "U_BaseLine";
        const string matrixBaseEntryUDF = "U_BaseEn";
        const string matrixBaseObjectTypeUDF = "U_BaseObj";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {

                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.ReceiptFromProductionUDFForm))
                            {
                                SAPbouiCOM.Form oBaseForm = oApplication.Forms.Item(pVal.FormUID);
                                oEdit = (SAPbouiCOM.EditText)oBaseForm.Items.Item("U_Shift").Specific;
                                oEdit.String = clsVariables.BaseShift;
                            }
                            if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.ReceiptFromProduction))
                            {
                                if (clsVariables.boolNewFormOpen)
                                {
                                    if (clsVariables.BaseObjectType == clsWeighingScale.objType)
                                    {
                                        clsVariables.boolNewFormOpen = false;
                                        oForm = oApplication.Forms.GetFormByTypeAndCount(pVal.FormType, pVal.FormTypeCount);

                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixOrdNoUID, 1);
                                        oEdit.String = clsVariables.BaseJobNo;

                                        string poSeries = objclsComman.SelectRecord("SELECT \"" + CommonFields.Series + "\" FROM OWOR WHERE \"" + CommonFields.DocEntry + "\" = '" + clsVariables.BaseJobEntry + "'");
                                        oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixOrdSeriesUID, 1);
                                        oCombo.Select(poSeries, SAPbouiCOM.BoSearchKey.psk_ByValue);
                                        for (int i = 1; i < oMatrix.VisualRowCount; i++)
                                        {
                                            string itemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).String;
                                            var match = clsVariables.ItemList
                                                .FirstOrDefault(stringToCheck => stringToCheck.ItemCode.Contains(itemCode));
                                            if (match != null)
                                            {
                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseEntryUDF, i);
                                                oEdit.String = clsVariables.BaseEntry;

                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseObjectTypeUDF, i);
                                                oEdit.String = clsVariables.BaseObjectType;

                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixQuantityUID, i);
                                                oEdit.String = match.Qty;

                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixTotalWtUID, i);
                                                oEdit.String = match.GrossWt;
                                            }
                                        }
                                        objclsComman.DeleteMatrixRow(oMatrix, matrixBaseEntryUDF);
                                    }
                                    if (clsVariables.BaseObjectType == clsScrapScale.objType)
                                    {
                                        clsVariables.boolNewFormOpen = false;
                                        oForm = oApplication.Forms.Item(pVal.FormUID);
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                        oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixOrdNoUID, 1);
                                        oEdit.String = clsVariables.BaseJobNo;

                                        string poSeries = objclsComman.SelectRecord("SELECT \"" + CommonFields.Series + "\" FROM OWOR WHERE \"" + CommonFields.DocEntry + "\" = '" + clsVariables.BaseJobEntry + "'");
                                        oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixOrdSeriesUID, 1);
                                        oCombo.Select(poSeries, SAPbouiCOM.BoSearchKey.psk_ByValue);
                                        for (int i = 1; i < oMatrix.VisualRowCount; i++)
                                        {
                                            string itemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).String;
                                            var match = clsVariables.ItemList
                                                .FirstOrDefault(stringToCheck => stringToCheck.ItemCode.Contains(itemCode) && stringToCheck.Selected == null);
                                            if (match != null)
                                            {
                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseEntryUDF, i);
                                                oEdit.String = clsVariables.BaseEntry;

                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseObjectTypeUDF, i);
                                                oEdit.String = clsVariables.BaseObjectType;

                                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixQuantityUID, i);
                                                oEdit.String = match.Qty;

                                                match.Selected = "Y";
                                            }
                                        }
                                        objclsComman.DeleteMatrixRow(oMatrix, matrixBaseEntryUDF);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {

                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        sbQuery.Length = 0;
                        sbQuery.Append(" SELECT \"" + matrixBaseObjectTypeUDF + "\" ");
                        sbQuery.Append(" FROM " + rowTable + " ");
                        sbQuery.Append(" WHERE \"" + CommonFields.DocEntry + "\" ='" + docEntry + "' ");
                        string baseObj = objclsComman.SelectRecord(sbQuery.ToString());
                        if (baseObj == clsWeighingScale.objType)
                        {
                            sbQuery.Length = 0;
                            sbQuery.Append(" UPDATE T0 ");
                            sbQuery.Append(" SET  T0.\"" + clsWeighingScale.matrixReceiptEntryUDF + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                            sbQuery.Append("  , T0.\"" + clsWeighingScale.matrixReceiptNoUDF + "\" = T2.\"" + CommonFields.DocNum + "\" ");
                            sbQuery.Append(" FROM  \"" + clsWeighingScale.rowTable + "\" T0 ");
                            sbQuery.Append(" INNER JOIN   \"" + rowTable + "\"  T1 ON T0.\"" + CommonFields.DocEntry + "\" =   T1.\"" + matrixBaseEntryUDF + "\" ");
                            //AND T0.\"" + CommonFields.LineId + "\" =   T1.\"" + matrixBaseLineUDF + "\" ");
                            sbQuery.Append(" INNER JOIN   \"" + headerTable + "\"  T2 ON T1.\"" + CommonFields.DocEntry + "\" =   T2.\"" + CommonFields.DocEntry + "\"  ");

                            sbQuery.Append(" WHERE T1.\"" + CommonFields.DocEntry + "\" ='" + docEntry + "' AND  T0.\"" + clsWeighingScale.matrixCheckUDF + "\" ='Y' ");
                            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                            {
                                sbQuery.Append("  AND  IFNULL(\"" + clsWeighingScale.matrixReceiptEntryUDF + "\",'')='' ");
                            }
                            else
                            {
                                sbQuery.Append("  AND  ISNULL(\"" + clsWeighingScale.matrixReceiptEntryUDF + "\",'')='' ");
                            }
                            objclsComman.SelectRecord(sbQuery.ToString());
                        }
                        else if (clsVariables.BaseObjectType == clsScrapScale.objType)
                        {
                            sbQuery.Length = 0;
                            sbQuery.Append(" UPDATE T0 ");
                            sbQuery.Append(" SET  T0.\"" + clsScrapScale.receiptEntryUDF + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                            sbQuery.Append("  , T0.\"" + clsScrapScale.receiptNoUDF + "\" = T2.\"" + CommonFields.DocNum + "\" ");
                            sbQuery.Append(" FROM  \"" + clsScrapScale.headerTable + "\" T0 ");
                            sbQuery.Append(" INNER JOIN   \"" + rowTable + "\"  T1 ON T0.\"" + CommonFields.DocEntry + "\" =   T1.\"" + matrixBaseEntryUDF + "\" ");
                            sbQuery.Append(" INNER JOIN   \"" + headerTable + "\"  T2 ON T1.\"" + CommonFields.DocEntry + "\" =   T2.\"" + CommonFields.DocEntry + "\"  ");
                            sbQuery.Append(" WHERE T1.\"" + CommonFields.DocEntry + "\" ='" + docEntry + "'  ");

                            objclsComman.SelectRecord(sbQuery.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion
    }
}
