using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using System.Linq;

namespace Production
{
    class clsIssueForProduction : Connection
    {
        #region Variables

        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.StaticText oStatic;
        SAPbouiCOM.Matrix oMatrix;
        SAPbobsCOM.Recordset oRs;
        const string matrixUID = "13";

        public const string headerTable = "OIGE";
        public const string rowTable = "IGE1";
        const string CFL_WS = "CFL_WS";
        const string CFL_SC = "CFL_SC";

        const string stWeighingScaleDocEntry = "stWSDocEn";
        const string edWeighingScaleDocEntry = "edWSDocEn";
        const string weighingScaleDocEntryUDF = "U_WSDocEn";

        const string stWeighingScaleDocNum = "stWSDocNo";
        const string edWeighingScaleDocNum = "edWSDocNo";
        const string weighingScaleDocNumUDF = "U_WSDocNo";

        const string stWeighingScaleQty = "stWSDocQty";
        const string edWeighingScaleQty = "edWSDocQty";
        const string weighingScaleQtyUDF = "U_WSDocQty";

        const string stWeighingScaleDocNW = "stWSDocNW";
        const string edWeighingScaleDocNW = "edWSDocNW";
        const string weighingScaleDocNWUDF = "U_WSDocNW";

        const string stScrapScaleDocNum = "stScDocNo";
        const string edScrapScaleDocNum = "edScDocNo";
        const string scrapScaleDocNumUDF = "U_ScDocNo";

        const string stScrapScaleDocEntry = "stScDocEn";
        const string edScrapScaleDocEntry = "edScDocEn";
        const string scrapScaleDocEntryUDF = "U_ScDocEn";

        const string stScrapScaleQty = "stScDocQty";
        const string edScrapScaleQty = "edScDocQty";
        const string scrapScaleQtyUDF = "U_ScDocQty";


        const string stScrapScaleDocNW = "stScDocNW";
        const string edScrapScaleDocNW = "edScDocNW";
        const string scrapScaleDocNWUDF = "U_ScDocNW";

        const string buttonCalculation = "btnCalc";
        const string buttonCalculationCaption = "Calc";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == buttonCalculation)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string weighingDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(weighingScaleDocEntryUDF, 0).ToString();
                                string weighingQuantity = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(weighingScaleQtyUDF, 0).ToString();
                                string scrapNetWt = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(scrapScaleDocNWUDF, 0).ToString();
                                string weighingNetWt = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(weighingScaleDocNWUDF, 0).ToString();

                                if (string.IsNullOrEmpty(weighingDocEntry))
                                {
                                    oApplication.StatusBar.SetText("Please select weighing scale", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }


                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                string poDocNum = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("61", 1)).String;
                                string poSeries = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("10001006", 1)).Value.Trim();
                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord("SELECT \"" + CommonFields.DocEntry + "\",\"" + CommonFields.ItemCode + "\",\"U_MacCode\" FROM \"" + CommonTables.ProductionOrderHeaderTable + "\" WHERE  \"" + CommonFields.DocNum + "\" ='" + poDocNum + "' AND \"" + CommonFields.Series + "\" ='" + poSeries + "'");
                                string poDocEntry = oRs.Fields.Item(CommonFields.DocEntry).Value.ToString();
                                string bomItemCode = oRs.Fields.Item(CommonFields.ItemCode).Value.ToString();
                                string machineCode = oRs.Fields.Item("U_MacCode").Value.ToString();

                                //string positiveQty = objclsComman.SelectRecord("SELECT SUM( \"" + CommonFields.PlannedQty + "\") FROM \"" + CommonTables.ProductionOrderRowTable + "\" WHERE  \"" + CommonFields.DocEntry + "\" ='" + poDocEntry + "' AND \"" + CommonFields.PlannedQty + "\" > 0 AND \"" + CommonFields.UomCode + "\" ='Kgs' ");
                                //string negativeQty = objclsComman.SelectRecord("SELECT SUM( \"" + CommonFields.PlannedQty + "\") FROM \"" + CommonTables.ProductionOrderRowTable + "\" WHERE  \"" + CommonFields.DocEntry + "\" ='" + poDocEntry + "' AND \"" + CommonFields.PlannedQty + "\" < 0 AND \"" + CommonFields.UomCode + "\" ='Kgs' ");

                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT SUM(\"" + CommonFields.Quantity + "\") FROM \"" + CommonTables.BOMHeaderTable + "\"  T0 ");
                                sbQuery.Append(" INNER JOIN \"" + CommonTables.BOMRowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\"  = T1.\"" + CommonFields.Father + "\" ");
                                sbQuery.Append(" INNER JOIN \"" + CommonTables.ItemMasterData + "\" T2 ON T1.\"" + CommonFields.Code + "\"  = T2.\"" + CommonFields.ItemCode + "\" ");

                                sbQuery.Append(" WHERE  T0.\"" + CommonFields.Code + "\" ='" + bomItemCode + "'");
                                sbQuery.Append(" AND T1.\"" + CommonFields.Quantity + "\" > 0 AND T2.\"" + CommonFields.InvntryUom + "\" ='Kgs' ");
                                string positiveQty = objclsComman.SelectRecord(sbQuery.ToString());

                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT SUM(\"" + CommonFields.Quantity + "\") FROM \"" + CommonTables.BOMHeaderTable + "\"  T0 ");
                                sbQuery.Append(" INNER JOIN \"" + CommonTables.BOMRowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\"  = T1.\"" + CommonFields.Father + "\" ");
                                sbQuery.Append(" INNER JOIN \"" + CommonTables.ItemMasterData + "\" T2 ON T1.\"" + CommonFields.Code + "\"  = T2.\"" + CommonFields.ItemCode + "\" ");

                                sbQuery.Append(" WHERE  T0.\"" + CommonFields.Code + "\" ='" + bomItemCode + "'");
                                sbQuery.Append(" AND T1.\"" + CommonFields.Quantity + "\" < 0 AND T2.\"" + CommonFields.InvntryUom + "\" ='Kgs' ");
                                string negativeQty = objclsComman.SelectRecord(sbQuery.ToString());

                                //sbQuery.Append(" SELECT SUM(\"" + clsBOMMaster.matrixQuantityColumnUDF + "\") FROM \"" + clsBOMMaster.headerTable + "\"  T0 ");
                                //sbQuery.Append(" INNER JOIN \"" + clsBOMMaster.rowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\"  = T1.\"" + CommonFields.Code + "\" ");
                                //sbQuery.Append(" WHERE  \"" + clsBOMMaster.productCodeUDF + "\" ='" + bomItemCode + "'");
                                //sbQuery.Append(" AND T0.\"" + clsBOMMaster.machineCodeUDF + "\" ='" + machineCode + "' ");
                                //sbQuery.Append(" AND \"" + clsBOMMaster.matrixQuantityColumnUDF + "\" < 0 AND \"" + clsBOMMaster.matrixUOMColumnUDF + "\" ='Kgs' ");
                                //string negativeQty = objclsComman.SelectRecord(sbQuery.ToString());

                                string bomHeaderQuantity = objclsComman.SelectRecord("SELECT \"" + CommonFields.Qauntity + "\" FROM \"" + CommonTables.BOMHeaderTable + "\" Where \"" + CommonFields.Code + "\" = '" + bomItemCode + "' ");// AND \"" + clsBOMMaster.machineCodeUDF + "\" = '" + machineCode + "' ");
                                string bomHeaderItemPerPcWeight = objclsComman.SelectRecord("SELECT \"IWeight1\" FROM OITM Where \"" + CommonFields.ItemCode + "\" = '" + bomItemCode + "' ");
                                string bomHeaderItemUOM = objclsComman.SelectRecord("SELECT \"" + CommonFields.InvntryUom + "\" FROM OITM Where \"" + CommonFields.ItemCode + "\" = '" + bomItemCode + "' ");

                                double dblTotalQuantity = double.Parse(weighingNetWt) + double.Parse(scrapNetWt);

                                double dblPositiveQty = positiveQty == string.Empty ? 1 : double.Parse(positiveQty);
                                double dblNegativeQty = negativeQty == string.Empty ? 0 : (-1) * double.Parse(negativeQty);
                                double dblScrapPer = (dblNegativeQty * 100) / dblPositiveQty;

                                double dblCalc1 = 0;
                                string componentCode = "";
                                string childBOMQty = "";
                                double dblChildBOMQty = 0;
                                string baseRef = "";
                                string baseSeries = "";
                                int baseRow = 0;
                                string baseLayer = "";
                                string uomCode = "";
                                for (int i = 1; i < oMatrix.VisualRowCount; i++)
                                {
                                    baseRef = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("61", i)).String;
                                    baseSeries = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("10001006", i)).Value.Trim();
                                    baseRow = int.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("60", i)).String) - 1;
                                    uomCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1001", i)).String;

                                    sbQuery.Length = 0;
                                    sbQuery.Append(" SELECT T1.\"U_Layer\",T0.\"U_MacCode\" ");
                                    sbQuery.Append(" FROM \"" + CommonTables.ProductionOrderHeaderTable + "\" T0 ");
                                    sbQuery.Append(" INNER JOIN \"" + CommonTables.ProductionOrderRowTable + "\" T1 ON T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                                    sbQuery.Append(" WHERE T0.\"" + CommonFields.DocNum + "\" ='" + baseRef + "' AND  T0.\"" + CommonFields.Series + "\" ='" + baseSeries + "' ");
                                    sbQuery.Append(" AND T1.\"" + CommonFields.LineNum + "\" ='" + baseRow.ToString() + "' ");

                                    oRs = objclsComman.returnRecord(sbQuery.ToString());
                                    baseLayer = oRs.Fields.Item("U_Layer").Value.ToString();
                                    //machineCode = oRs.Fields.Item("U_MacCode").Value.ToString();

                                    componentCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("1", i)).String;

                                    sbQuery.Length = 0;
                                    sbQuery.Append(" SELECT \"" + CommonFields.Quantity + "\" FROM \"" + CommonTables.BOMHeaderTable + "\"  T0 ");
                                    sbQuery.Append(" INNER JOIN \"" + CommonTables.BOMRowTable + "\" T1 ON T0.\"" + CommonFields.Code + "\"  = T1.\"" + CommonFields.Father + "\" ");
                                    sbQuery.Append(" WHERE T1.\"" + CommonFields.Code + "\" ='" + componentCode + "' AND T1.\"" + CommonFields.Father + "\" ='" + bomItemCode + "'");
                                    //sbQuery.Append(" AND T0.\"" + clsBOMMaster.machineCodeUDF + "\" ='" + machineCode + "' ");

                                    if (baseLayer != string.Empty)
                                    {
                                        sbQuery.Append(" AND \"U_Layer\" ='" + baseLayer + "' ");
                                    }
                                    childBOMQty = objclsComman.SelectRecord(sbQuery.ToString());

                                    dblChildBOMQty = childBOMQty == string.Empty ? 0 : double.Parse(childBOMQty);
                                    //double childBOMQty = double.Parse(((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("87", i)).String);
                                    dblCalc1 = (dblChildBOMQty * dblScrapPer) / 100;
                                    dblCalc1 = dblChildBOMQty - dblCalc1;
                                    double dblPcBOMQuantity = 0;
                                    if (bomHeaderItemUOM .ToLower()== "kgs")
                                    {
                                        dblPcBOMQuantity = double.Parse(bomHeaderQuantity);
                                    }
                                    else
                                    {
                                        dblPcBOMQuantity = double.Parse(bomHeaderQuantity) * double.Parse(bomHeaderItemPerPcWeight);
                                    }
                                    dblCalc1 = (dblCalc1 / dblPcBOMQuantity) * dblTotalQuantity;
                                    dblCalc1 = dblCalc1 == 0 ? 1 : dblCalc1;
                                    if (uomCode.ToLower() == "kgs")
                                    {
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("9", i)).String = Math.Round(dblCalc1, 3).ToString();
                                    }
                                    else
                                    {
                                        dblCalc1 = (dblChildBOMQty / double.Parse(bomHeaderQuantity)) * double.Parse(weighingQuantity);
                                        dblCalc1 = dblCalc1 == 0 ? 1 : dblCalc1;
                                        ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("9", i)).String = Math.Ceiling(dblCalc1).ToString();
                                    }
                                }

                                objclsComman.ReleaseObject(oRs);
                            }
                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == edWeighingScaleDocEntry)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                string poDocNum = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("61", 1)).String;
                                string poSeries = ((SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("10001006", 1)).Value.Trim();
                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord("SELECT \"" + CommonFields.DocEntry + "\",\"" + CommonFields.ItemCode + "\",\"U_MacCode\" FROM \"" + CommonTables.ProductionOrderHeaderTable + "\" WHERE  \"" + CommonFields.DocNum + "\" ='" + poDocNum + "' AND \"" + CommonFields.Series + "\" ='" + poSeries + "'");
                                string poDocEntry = oRs.Fields.Item(CommonFields.DocEntry).Value.ToString();
                                objclsComman.ReleaseObject(oRs);

                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT \"" + CommonFields.DocEntry + "\" ");
                                sbQuery.Append(" FROM \"" + clsWeighingScale.headerTable + "\" T0 ");
                                sbQuery.Append(" WHERE  \"" + clsWeighingScale.jbDocEntryUDF + "\" ='" + poDocEntry + "' ");
                                sbQuery.Append(" AND NOT EXISTS ( ");
                                sbQuery.Append(" SELECT 1 FROM " + headerTable + " IT0 ");
                                sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = IT0.\"" + weighingScaleDocEntryUDF + "\" ) ");

                                objclsComman.AddChooseFromList_WithCond(oForm, CFL_WS, clsWeighingScale.objType, sbQuery.ToString(), CommonFields.DocEntry, alCondVal);
                            }
                            else if (pVal.ItemUID == edScrapScaleDocEntry)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT \"" + CommonFields.DocEntry + "\" ");
                                sbQuery.Append(" FROM \"" + clsScrapScale.headerTable + "\" T0 ");
                                sbQuery.Append(" WHERE NOT EXISTS ( ");
                                sbQuery.Append(" SELECT 1 FROM " + headerTable + " IT0 ");
                                sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = IT0.\"" + scrapScaleDocEntryUDF + "\" ) ");

                                objclsComman.AddChooseFromList_WithCond(oForm, CFL_SC, clsScrapScale.objType, sbQuery.ToString(), CommonFields.DocEntry, alCondVal);
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            SAPbouiCOM.Item oNewItem;
                            SAPbouiCOM.Item oItem;
                            oNewItem = oForm.Items.Add(stWeighingScaleQty, SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item("31");
                            oStatic = oNewItem.Specific;
                            oStatic.Caption = "Qty";
                            oNewItem.Top = oItem.Top + oItem.Height + 10;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left;

                            oNewItem = oForm.Items.Add(stWeighingScaleDocNW, SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item("30");
                            oStatic = oNewItem.Specific;
                            oStatic.Caption = "Net Wt";
                            oNewItem.Top = oItem.Top + oItem.Height + 10;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left;


                            #region Weighing Scale 

                            oNewItem = oForm.Items.Add(stWeighingScaleDocEntry, SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item("8");
                            oStatic = oNewItem.Specific;
                            oStatic.Caption = "Weighing Entry";
                            oNewItem.Top = oForm.Items.Item(stWeighingScaleQty).Top + oItem.Height + 10;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left;

                            oNewItem = oForm.Items.Add(edWeighingScaleDocEntry, SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("7");
                            oNewItem.Top = oForm.Items.Item(stWeighingScaleDocNW).Top + oItem.Height + 10;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left;
                            oEdit = oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, headerTable, weighingScaleDocEntryUDF);

                            ArrayList alCondVal = new ArrayList();
                            ArrayList temp = new ArrayList();
                            //sbQuery.Length = 0;
                            //sbQuery.Append(" SELECT \"" + CommonFields.DocEntry + "\" ");
                            //sbQuery.Append(" FROM \"" + clsWeighingScale.headerTable + "\" T0 ");
                            //sbQuery.Append(" WHERE NOT EXISTS ( ");
                            //sbQuery.Append(" SELECT 1 FROM " + headerTable + " IT0 ");
                            //sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\" = IT0.\"" + weighingScaleDocEntryUDF + "\" ) ");

                            objclsComman.AddChooseFromList_WithCond(oForm, CFL_WS, clsWeighingScale.objType, "", CommonFields.DocEntry, alCondVal);
                            oEdit.ChooseFromListUID = CFL_WS;
                            oEdit.ChooseFromListAlias = CommonFields.DocEntry;

                            //oNewItem = oForm.Items.Add(stWeighingScaleDocNum, SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            //oItem = oForm.Items.Item("31");
                            //oStatic = oNewItem.Specific;
                            //oStatic.Caption = "No";
                            //oNewItem.Top = oItem.Top + oItem.Height + 10;
                            //oNewItem.Height = oItem.Height;
                            //oNewItem.Width = oItem.Width;
                            //oNewItem.Left = oItem.Left;

                            oNewItem = oForm.Items.Add(edWeighingScaleQty, SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("31");
                            oNewItem.Top = oForm.Items.Item(stWeighingScaleQty).Top + oItem.Height + 10;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left;
                            oEdit = oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, headerTable, weighingScaleQtyUDF);
                            oNewItem.Disable();

                            oNewItem = oForm.Items.Add(edWeighingScaleDocNW, SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item("30");
                            oNewItem.Top = oForm.Items.Item(stWeighingScaleDocNW).Top + oItem.Height + 10;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left;
                            oEdit = oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, headerTable, weighingScaleDocNWUDF);
                            oNewItem.Disable();

                            //oNewItem = oForm.Items.Add(stWeighingScaleQty, SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            //oItem = oForm.Items.Item(stWeighingScaleDocNum);
                            //oStatic = oNewItem.Specific;
                            //oStatic.Caption = "Qty";
                            //oNewItem.Top = oItem.Top;
                            //oNewItem.Height = oItem.Height;
                            //oNewItem.Width = oItem.Width;
                            //oNewItem.Left = oForm.Items.Item(edWeighingScaleDocNum).Left + oItem.Width + 10;

                            //oNewItem = oForm.Items.Add(edWeighingScaleQty, SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            //oItem = oForm.Items.Item(edWeighingScaleDocNum);
                            //oNewItem.Top = oItem.Top;
                            //oNewItem.Height = oItem.Height;
                            //oNewItem.Width = oItem.Width;
                            //oNewItem.Left = oForm.Items.Item(edWeighingScaleDocNum).Left + oItem.Width + 10;
                            //oEdit = oNewItem.Specific;
                            //oEdit.DataBind.SetBound(true, headerTable, weighingScaleQtyUDF);
                            //oNewItem.Disable();

                            #endregion

                            #region Scrap Scale

                            oNewItem = oForm.Items.Add(stScrapScaleDocEntry, SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            oItem = oForm.Items.Item(stWeighingScaleDocEntry);
                            oStatic = oNewItem.Specific;
                            oStatic.Caption = "Scrap Entry";
                            oNewItem.Top = oItem.Top + oItem.Height + 10;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left;

                            oNewItem = oForm.Items.Add(edScrapScaleDocEntry, SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item(edWeighingScaleDocEntry);
                            oNewItem.Top = oItem.Top + oItem.Height + 10;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left;
                            oEdit = oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, headerTable, scrapScaleDocEntryUDF);
                            objclsComman.AddChooseFromList_WithCond(oForm, CFL_SC, clsScrapScale.objType, "", CommonFields.DocEntry, alCondVal);
                            oEdit.ChooseFromListUID = CFL_SC;
                            oEdit.ChooseFromListAlias = CommonFields.DocEntry;

                            oNewItem = oForm.Items.Add(edScrapScaleQty, SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item(edWeighingScaleQty);
                            oNewItem.Top = oItem.Top + oItem.Height + 10;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left;
                            oEdit = oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, headerTable, scrapScaleQtyUDF);
                            oNewItem.Disable();

                            oNewItem = oForm.Items.Add(edScrapScaleDocNW, SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            oItem = oForm.Items.Item(edWeighingScaleDocNW);
                            oNewItem.Top = oItem.Top + oItem.Height + 10;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left;
                            oEdit = oNewItem.Specific;
                            oEdit.DataBind.SetBound(true, headerTable, scrapScaleDocNWUDF);
                            oNewItem.Disable();

                            //oNewItem = oForm.Items.Add(edScrapScaleDocEntry, SAPbouiCOM.BoFormItemTypes.it_EDIT);
                            //oItem = oForm.Items.Item(edScrapScaleDocNum);
                            //oNewItem.Top = oItem.Top;
                            //oNewItem.Height = oItem.Height;
                            //oNewItem.Width = 1;
                            //oNewItem.Left = oItem.Left;
                            //oNewItem.Disable();
                            //oEdit = oNewItem.Specific;
                            //oEdit.DataBind.SetBound(true, headerTable, scrapScaleDocEntry_UDF);

                            //oNewItem = oForm.Items.Add(stScrapScaleQty, SAPbouiCOM.BoFormItemTypes.it_STATIC);
                            //oItem = oForm.Items.Item(stWeighingScaleQty);
                            //oStatic = oNewItem.Specific;
                            //oStatic.Caption = "Qty";
                            //oNewItem.Top = oItem.Top + oItem.Height + 10;
                            //oNewItem.Height = oItem.Height;
                            //oNewItem.Width = oItem.Width;
                            //oNewItem.Left = oItem.Left;


                            #endregion

                            #region Button

                            oNewItem = oForm.Items.Add(buttonCalculation, SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            oItem = oForm.Items.Item("2");
                            SAPbouiCOM.Button oButton = oNewItem.Specific;
                            oButton.Caption = buttonCalculationCaption;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left + oItem.Width + 10;

                            #endregion
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {

                            }
                        }
                        #endregion

                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == CFL_WS)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                try
                                {
                                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(edWeighingScaleDocNum).Specific;
                                    oEdit.String = oDataTable.GetValue(CommonFields.DocNum, 0).ToString();
                                }
                                catch { }
                                try
                                {
                                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(edWeighingScaleDocEntry).Specific;
                                    oEdit.String = oDataTable.GetValue(CommonFields.DocEntry, 0).ToString();
                                }
                                catch { }

                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT SUM(\"" + clsWeighingScale.matrixQtyUDF + "\" * \"" + clsWeighingScale.matrixUOMBaseQtyUDF + "\" ) AS \"" + clsWeighingScale.matrixQtyUDF + "\"");
                                sbQuery.Append(" ,SUM(\"" + clsWeighingScale.matrixNetWtUDF + "\")AS  \"" + clsWeighingScale.matrixNetWtUDF + "\"");
                                sbQuery.Append(" FROM \"" + clsWeighingScale.rowTable + "\" ");
                                sbQuery.Append(" WHERE \"" + CommonFields.DocEntry + "\" ='" + oDataTable.GetValue(CommonFields.DocEntry, 0).ToString() + "'");

                                oRs = objclsComman.returnRecord(sbQuery.ToString());
                                try
                                {
                                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(edWeighingScaleQty).Specific;
                                    oEdit.String = oRs.Fields.Item(clsWeighingScale.matrixQtyUDF).Value.ToString();
                                }
                                catch { }

                                try
                                {
                                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(edWeighingScaleDocNW).Specific;
                                    oEdit.String = oRs.Fields.Item(clsWeighingScale.matrixNetWtUDF).Value.ToString();
                                }
                                catch { }
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_SC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                try
                                {
                                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(edScrapScaleDocNum).Specific;
                                    oEdit.String = oDataTable.GetValue(CommonFields.DocNum, 0).ToString();
                                }
                                catch { }
                                try
                                {
                                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(edScrapScaleDocEntry).Specific;
                                    oEdit.String = oDataTable.GetValue(CommonFields.DocEntry, 0).ToString();
                                }
                                catch { }

                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT SUM(\"" + clsScrapScale.matrixQtyUDF + "\") AS \"" + clsScrapScale.matrixQtyUDF + "\"");
                                sbQuery.Append(" ,SUM(\"" + clsScrapScale.matrixNetWtUDF + "\") AS \"" + clsScrapScale.matrixNetWtUDF + "\"");
                                sbQuery.Append(" FROM \"" + clsScrapScale.rowTable + "\" ");
                                sbQuery.Append(" WHERE \"" + CommonFields.DocEntry + "\" ='" + oDataTable.GetValue(CommonFields.DocEntry, 0).ToString() + "'");
                                oRs = objclsComman.returnRecord(sbQuery.ToString());
                                try
                                {
                                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(edScrapScaleQty).Specific;
                                    oEdit.String = oRs.Fields.Item(clsWeighingScale.matrixQtyUDF).Value.ToString();
                                }
                                catch { }

                                try
                                {
                                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(edScrapScaleDocNW).Specific;
                                    oEdit.String = oRs.Fields.Item(clsWeighingScale.matrixNetWtUDF).Value.ToString();
                                }
                                catch { }
                            }
                        }

                        #endregion

                        #region F_ItemChanged
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == edWeighingScaleDocEntry)
                            {
                                string scDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(weighingScaleDocEntryUDF, 0);
                                if (scDocEntry == string.Empty)
                                {
                                    oEdit = oForm.Items.Item(edWeighingScaleDocNum).Specific;
                                    oEdit.String = "";
                                    oEdit = oForm.Items.Item(edWeighingScaleQty).Specific;
                                    oEdit.String = "";
                                }
                            }
                            else if (pVal.ItemUID == edScrapScaleDocEntry)
                            {
                                string scDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(scrapScaleDocEntryUDF, 0);
                                if (scDocEntry == string.Empty)
                                {
                                    oEdit = oForm.Items.Item(edScrapScaleDocNum).Specific;
                                    oEdit.String = "";
                                    oEdit = oForm.Items.Item(edScrapScaleQty).Specific;
                                    oEdit.String = "";
                                }
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {

                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion
    }
}
