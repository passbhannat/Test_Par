using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using System.Linq;

namespace Production
{
    class clsProduction : Connection
    {
        #region Variables

        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;

        const string matrixUID = "37";

        public const string headerTable = "OWOR";
        public const string rowTable = "WOR1";

        const string matrixTypeUID = "1880000002";
        const string matrixItemCodeUID = "4";
        const string matrixBaseQtyUID = "2";
        const string matrixPlannedQtyUID = "14";
        const string matrixWhsCodeUID = "10";
        const string matrixIssMethodUID = "9";
        const string matrixLayerUID = "U_Layer";
        const string matrixLayerPerUID = "U_Percent";
        const string matrixStaionUID = "U_Station";
        const string matrixStandardUID = "U_Std";
        const string matrixAniloxUID = "U_Anilox";
        const string matrixViscUID = "U_Viscocity";

        const string buttonCalc = "btnCalc";
        const string buttonCalcCaption = "Calc";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == buttonCalc)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                try
                                {
                                    oForm.Items.Item("uaf_0").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                }
                                catch(Exception ex) {
                                }
                                string itemCode = "";

                                string sizeMM = "";
                                string micron = "";
                                string density = "";
                                string prodRate = "";
                                string rollWtTole = "";
                                string gsmRange = "";
                                string gsmRange_Single = "";

                                string mtrRoll = "";
                                string kgsRollAvg = "";
                                string kgsRollMin = "";
                                string kgsRollMax = "";

                                //itemCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.ItemCode, 0).Trim();
                                string fgItemCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_OCItem", 0).Trim();
                                sizeMM = objclsComman.SelectRecord("SELECT U_SIZEMM FROM OITM WHERE ItemCode = '" + fgItemCode + "'");
                                micron = objclsComman.SelectRecord("SELECT U_MICRON FROM OITM WHERE ItemCode = '" + fgItemCode + "'");
                                density = objclsComman.SelectRecord("SELECT U_Density FROM OITM WHERE ItemCode = '" + fgItemCode + "'");
                                micron = micron == string.Empty ? "0" : micron;
                                density = density == string.Empty ? "0" : density;

                                prodRate = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_PRATE", 0).Trim();
                                prodRate = prodRate == string.Empty ? "0" : prodRate;

                                gsmRange = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_GSMR", 0).Trim();
                                gsmRange = gsmRange == string.Empty ? "0" : gsmRange;

                                gsmRange_Single = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_SINGLE", 0).Trim();
                                gsmRange_Single = gsmRange_Single == string.Empty ? "0" : gsmRange_Single;

                                rollWtTole = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_RWTP", 0).Trim();
                                rollWtTole = rollWtTole == string.Empty ? "0" : rollWtTole;

                                mtrRoll = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_MROLL", 0).Trim();
                                mtrRoll = mtrRoll == string.Empty ? "0" : mtrRoll;

                                oEdit = oForm.Items.Item("U_AGSM").Specific;
                                double dblAGSM = double.Parse(micron) * double.Parse(density);
                                oEdit.String = dblAGSM.ToString();

                                oEdit = oForm.Items.Item("U_MAGSM").Specific;
                                double dblMAGSM = dblAGSM - (dblAGSM * (double.Parse(gsmRange) / 100));
                                oEdit.String = dblMAGSM.ToString();

                                oEdit = oForm.Items.Item("U_MXAGSM").Specific;
                                double dblMXAGSM = dblAGSM + (dblAGSM * (double.Parse(gsmRange) / 100));
                                oEdit.String = dblMXAGSM.ToString();

                                oEdit = oForm.Items.Item("U_MSVGSM").Specific;
                                double dblMSVGSM = dblAGSM - (dblAGSM * (double.Parse(gsmRange_Single) / 100));
                                oEdit.String = dblMSVGSM.ToString();

                                oEdit = oForm.Items.Item("U_MXSVGSM").Specific;
                                double dblMXSVGSM = dblAGSM + (dblAGSM * (double.Parse(gsmRange_Single) / 100));
                                oEdit.String = dblMXSVGSM.ToString();

                                oEdit = oForm.Items.Item("U_YIELD").Specific;
                                double dblYIELD = 1;
                                if (dblAGSM > 0 && double.Parse(sizeMM) != 0)
                                {
                                    dblYIELD = (1000 / dblAGSM) / ((double.Parse(sizeMM) + 0) / 1000);
                                    oEdit.String = dblYIELD.ToString();
                                }

                                oEdit = oForm.Items.Item("U_KGRAVG").Specific;
                                double dblKGRAVG = double.Parse(mtrRoll) / dblYIELD;
                                oEdit.String = dblKGRAVG.ToString();

                                oEdit = oForm.Items.Item("U_KGRMIN").Specific;
                                double dblKGRMIN = dblKGRAVG - (dblKGRAVG * double.Parse(rollWtTole) / 100);
                                oEdit.String = dblKGRMIN.ToString();

                                oEdit = oForm.Items.Item("U_KGRMAX").Specific;
                                double dblKGRMAX = dblKGRAVG + (dblKGRAVG * double.Parse(rollWtTole) / 100);
                                oEdit.String = dblKGRMAX.ToString();



                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            #region Button

                            SAPbouiCOM.Item oNewItem = oForm.Items.Add(buttonCalc, SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                            SAPbouiCOM.Item oItem = oForm.Items.Item("2");
                            SAPbouiCOM.Button oButton = oNewItem.Specific;
                            oButton.Caption = buttonCalcCaption;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width;
                            oNewItem.Left = oItem.Left + oItem.Width + 10;

                            #endregion
                        }
                        #endregion

                        #region F_ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            if (pVal.ItemUID == "")
                            {

                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {

                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion
    }
}
