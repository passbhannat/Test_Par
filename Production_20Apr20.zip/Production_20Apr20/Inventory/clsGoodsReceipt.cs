using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;

namespace Production
{
    class clsGoodsReceipt : Connection
    {
        #region Variables

        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;

        const string matrixUID = "13";

        public const string headerTable = "OIGN";
        public const string rowTable = "IGN1";

        const string matrixItemCodeUID = "1";
        const string matrixQuantityUID = "9";
        const string matrixWhsCodeUID = "15";

        const string matrixBaseLineUDF = "U_BaseLine";
        const string matrixBaseEntryUDF = "U_BaseEn";
        const string matrixBaseObjectTypeUDF = "U_BaseObj";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {

                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_FORM_LOAD
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            if (clsVariables.boolNewFormOpen)
                            {
                                clsVariables.boolNewFormOpen = false;
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;

                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixItemCodeUID, 1);
                                oEdit.String = clsVariables.BaseItemCode;

                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseEntryUDF, 1);
                                oEdit.String = clsVariables.BaseEntry;

                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseLineUDF, 1);
                                oEdit.String = clsVariables.BaseLine;

                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixBaseObjectTypeUDF, 1);
                                oEdit.String = clsVariables.BaseObjectType;

                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixQuantityUID, 1);
                                oEdit.String = clsVariables.BaseQuantity.ToString();

                                oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific(matrixWhsCodeUID, 1);
                                oEdit.String = clsVariables.BaseWhsCode;
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {

                            }
                        }
                        #endregion

                        #region F_et_CHOOSE_FROM_LIST

                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (pVal.ColUID == "1")
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("13").Specific;
                                string itemCode = oDataTable.GetValue(CommonFields.ItemCode, 0).ToString();
                                string itmsGrpCode = oDataTable.GetValue(CommonFields.ItmsGrpCod, 0).ToString();
                                string itmsGrpName = objclsComman.SelectRecord("SELECT ItmsGrpNam FROM OITB WHERE ItmsGrpCod = '" + itmsGrpCode + "'");
                                if (itmsGrpName == "SPECIAL INK MIX")
                                {
                                    string fgItemCode = oDataTable.GetValue("U_SPINKCODE", 0).ToString();
                                    try
                                    {
                                        clsVariables.SpecialMixItemCode = fgItemCode;
                                        clsVariables.RowNo = pVal.Row;
                                    }
                                    catch { }
                                }
                            }
                        }
                        #endregion

                        #region F_et_CHOOSE_FROM_LIST

                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE || pVal.EventType == SAPbouiCOM.BoEventTypes.et_LOST_FOCUS)
                        {
                            try
                            {
                                if (clsVariables.SpecialMixItemCode != string.Empty)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    string price = objclsComman.GetItemCost(clsVariables.SpecialMixItemCode);
                                    clsVariables.SpecialMixItemCode = "";

                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("13").Specific;
                                    oEdit = (SAPbouiCOM.EditText)oMatrix.GetCellSpecific("10", clsVariables.RowNo);
                                    oEdit.String = Convert.ToString(double.Parse(price) * 60 / 100);

                                    clsVariables.RowNo = 0;
                                }
                            }
                            catch (Exception ex)
                            {
                                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " _et_FORM_ACTIVATE_Before Action = false: " + ex.Message);
                                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + "_et_FORM_ACTIVATE_ Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        sbQuery.Length = 0;
                        sbQuery.Append(" SELECT \"" + matrixBaseObjectTypeUDF + "\" ");
                        sbQuery.Append(" FROM " + rowTable + " ");
                        sbQuery.Append(" WHERE \"" + CommonFields.DocEntry + "\" ='" + docEntry + "' ");
                        string baseObj = objclsComman.SelectRecord(sbQuery.ToString());
                        if (baseObj == clsDailyPlan.objType)
                        {
                            sbQuery.Length = 0;
                            sbQuery.Append(" UPDATE T0 ");
                            sbQuery.Append(" SET  T0.\"" + clsDailyPlan.matrixRewindReceiptEnColumnUDF + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
                            sbQuery.Append("  , T0.\"" + clsDailyPlan.matrixRewindReceiptNoColumnUDF + "\" = T2.\"" + CommonFields.DocNum + "\" ");
                            sbQuery.Append(" FROM  \"" + clsDailyPlan.rowTable + "\" T0 ");
                            sbQuery.Append(" INNER JOIN   \"" + rowTable + "\"  T1 ON T0.\"" + CommonFields.DocEntry + "\" =   T1.\"" + matrixBaseEntryUDF + "\"  AND T0.\"" + CommonFields.LineId + "\" =   T1.\"" + matrixBaseLineUDF + "\" ");
                            sbQuery.Append(" INNER JOIN   \"" + headerTable + "\"  T2 ON T1.\"" + CommonFields.DocEntry + "\" =   T2.\"" + CommonFields.DocEntry + "\"  ");

                            sbQuery.Append(" WHERE T1.\"" + CommonFields.DocEntry + "\" ='" + docEntry + "' ");
                            objclsComman.SelectRecord(sbQuery.ToString());
                            clsVariables.boolRefreshForm = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion
    }
}
