using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;

namespace Production
{
    class clsScrapScale_Old : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formTypeEx = "SCRAPSCALE";
        const string formMenuUID = "SCRAPSCALE";
        const string objType = "SCRAPSCALE";
        const string headerTable = "@SCRAPSCALE";
        const string rowTable = "@SCRAPSCALE1";

        const string CFL_REC = "CFL_REC";
        const string CFL_MAC = "CFL_MAC";
        const string CFL_ITEM = "CFL_ITEM";
        const string CFL_JC = "CFL_JC";
        const string CFL_WHS = "CFL_WHS";
        const string CFL_MWHS = "CFL_MWHS";
        const string CFL_MBAT = "CFL_MBAT";

        const string docDateUDF = "U_DocDate";
        const string receiptDateUDF = "U_RecDate";
        const string receiptNoUID = "RecNo";
        const string receiptNoUDF = "U_RecNo";
        const string receiptEntryUDF = "U_RecEn";
        const string whsCodeUDF = "U_WhsCode";

        const string itDocNumUID = "ITNo";
        const string itDocNumUDF = "U_ITNo";
        const string itDocEntryUDF = "U_ITEn";

        const string matrixUID = "mtx";
        const string matrixPrimaryUDF = "U_JBNo";
        const string matrixPrimaryColumnUID = "V_7";

        const string matrixJobDocNumUDF = "U_JBNo";
        const string matrixJobDocNumUID = "V_7";
        const string matrixJobDocEntryUDF = "U_JBEn";
        const string matrixJobDocDateUDF = "U_JBDate";
        const string matrixMachineCodeUDF = "U_MacCode";
        const string matrixMachineCodeUID = "V_8";
        const string matrixMachineNameUDF = "U_MacName";

        const string matrixProductCodeUID = "V_3";
        const string matrixProductCodeUDF = "U_PrdCode";
        const string matrixProductNameUDF = "U_PrdName";
        const string matrixQuantityUDF = "U_Qty";
        const string matrixWhsCodeUDF = "U_WhsCode";
        const string matrixWhsCodeUID = "V_12";
        const string matrixBatchUDF = "U_Batch";
        const string matrixBatchUID = "V_1";

        const string matrixShiftUID = "V_5";
        const string matrixScrapTypeUID = "V_4";

        const string buttonCreateITUID = "btnIT";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank. Please select series.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(receiptNoUDF, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please select Receipt No.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion

                            #region Create Inventory Transfer
                            else if (pVal.ItemUID == buttonCreateITUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                string itEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(itDocEntryUDF, 0).Trim();
                                string receiptEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(receiptEntryUDF, 0).Trim();
                                if (receiptEntry == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please select receipt entry.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                if (itEntry != string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Inventory transfer is already created.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                CreateIT(docEntry);
                            }
                            #endregion

                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == receiptNoUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                sbQuery.Length = 0;
                                sbQuery.Append(" Select T0.\"DocEntry\" ");
                                sbQuery.Append(" FROM \"OIGN\" T0 ");
                                sbQuery.Append(" INNER JOIN \"IGN1\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
                                sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T1.\"ItemCode\" = T2.\"ItemCode\" ");
                                sbQuery.Append(" INNER JOIN \"OITB\" T3 ON T2.\"ItmsGrpCod\" = T3.\"ItmsGrpCod\" ");
                                sbQuery.Append(" WHERE T1.\"BaseType\" = '202' AND T3.\"U_IsScrapG\" = 'Y'  ");

                                objclsComman.AddChooseFromList_WithCond(oForm, CFL_REC, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry), sbQuery.ToString(), CommonFields.DocEntry, alCondVal);
                            }
                            else if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixJobDocNumUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    string receiptEntry = oDbDataSource.GetValue(receiptEntryUDF, 0).Trim();
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    //temp = new ArrayList();
                                    //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                    //temp.Add(CommonFields.Code); //Condition Alias             
                                    //temp.Add(machineCode); //Condition Value
                                    //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                    //alCondVal.Add(temp);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string query = "Select \"BaseEntry\" FROM \"IGN1\" WHERE \"DocEntry\" = '" + receiptEntry + "'";
                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_JC, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oProductionOrders), query, CommonFields.DocEntry, alCondVal);
                                }
                                else if (pVal.ColUID == matrixMachineCodeUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string jobEntry = oDbDataSource.GetValue(matrixJobDocEntryUDF, 0).Trim();
                                    string productCode = objclsComman.SelectRecord("Select \"" + CommonFields.ItemCode + "\" FROM OWOR WHERE \"DocEntry\" = '" + jobEntry + "'"); ;

                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string query = "Select \"" + CommonFields.Code + "\" FROM \"" + clsMachineMaster.rowTable + "\" WHERE \"U_PrdCode\" = '" + productCode + "'";
                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_MAC, clsMachineMaster.objType, query, CommonFields.Code, alCondVal);
                                }
                                else if (pVal.ColUID == matrixProductCodeUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;

                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    string receiptEntry = oDbDataSource.GetValue(receiptEntryUDF, 0).Trim();
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string query = "Select \"ItemCode\" FROM \"IGN1\" WHERE \"DocEntry\" = '" + receiptEntry + "'";
                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_ITEM, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oItems), query, CommonFields.ItemCode, alCondVal);
                                }
                                else if (pVal.ColUID == matrixBatchUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    string receiptEntry = oDbDataSource.GetValue(receiptEntryUDF, 0).Trim();
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string whs = oDbDataSource.GetValue(matrixWhsCodeUDF, pVal.Row - 1).Trim();
                                    string itemCode = oDbDataSource.GetValue(matrixProductCodeUDF, pVal.Row - 1).Trim();
                                    sbQuery.Length = 0;
                                    sbQuery.Append(objclsComman.GetBatchNoQuery(itemCode, receiptEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry)));

                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_MBAT, "10000044", sbQuery.ToString(), CommonFields.DistNumber, alCondVal);
                                }
                            }
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            try
                            {
                                SAPbouiCOM.DataTable oDataTable = null;
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                                oDataTable = oCFLEvento.SelectedObjects;
                                string sCFL_ID = oCFLEvento.ChooseFromListUID;
                                string Value = string.Empty;

                                if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                                {
                                    return;
                                }

                                if (oCFLEvento.ChooseFromListUID == CFL_JC)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();

                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    oDbDataSource.SetValue(matrixJobDocNumUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocNum, 0).ToString());
                                    oDbDataSource.SetValue(matrixJobDocEntryUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());
                                    DateTime docDate = DateTime.Parse(oDataTable.GetValue(CommonFields.PostDate, 0).ToString());
                                    oDbDataSource.SetValue(matrixJobDocDateUDF, pVal.Row - 1, objclsComman.ConvertDateToSAPDateFormat(docDate));
                                    oDbDataSource.SetValue(matrixMachineCodeUDF, pVal.Row - 1, oDataTable.GetValue(matrixMachineCodeUDF, 0).ToString());
                                    oDbDataSource.SetValue(matrixMachineNameUDF, pVal.Row - 1, oDataTable.GetValue(matrixMachineNameUDF, 0).ToString());

                                    if (pVal.Row == oMatrix.RowCount)
                                    {
                                        oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                        int RowNo = 1;
                                        for (int i = 0; i < oDbDataSource.Size; i++)
                                        {
                                            oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                            RowNo = RowNo + 1;
                                        }
                                    }
                                    oMatrix.LoadFromDataSource();
                                    oMatrix.Columns.Item(matrixJobDocNumUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                    clsVariables.boolCFLSelected = true;
                                    SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                    clsVariables.ColNo = oPos.ColumnIndex;
                                    clsVariables.RowNo = oPos.rowIndex;
                                }
                                else if (oCFLEvento.ChooseFromListUID == CFL_ITEM)
                                {
                                    string receiptEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(receiptEntryUDF, 0).Trim();
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string itemCode = oDataTable.GetValue(CommonFields.ItemCode, 0).ToString();
                                    oDbDataSource.SetValue(matrixProductCodeUDF, pVal.Row - 1, itemCode);
                                    string itemName = objclsComman.SelectRecord("SELECT \"" + CommonFields.ItemName + "\" FROM OITM WHERE \"" + CommonFields.ItemCode + "\" = '" + itemCode + "' ");
                                    oDbDataSource.SetValue(matrixProductNameUDF, pVal.Row - 1, itemName);

                                    string quantity = objclsComman.SelectRecord("SELECT \"" + CommonFields.Quantity + "\" FROM IGN1 WHERE  \"" + CommonFields.DocEntry + "\" = '" + receiptEntry + "' AND \"" + CommonFields.ItemCode + "\" = '" + itemCode + "' ");
                                    oDbDataSource.SetValue(matrixQuantityUDF, pVal.Row - 1, quantity);


                                    oMatrix.LoadFromDataSource();
                                    oMatrix.Columns.Item(matrixProductCodeUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                    clsVariables.boolCFLSelected = true;
                                    SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                    clsVariables.ColNo = oPos.ColumnIndex;
                                    clsVariables.RowNo = oPos.rowIndex;
                                }
                                else if (oCFLEvento.ChooseFromListUID == CFL_WHS)
                                {
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    oDbDataSource.SetValue(whsCodeUDF, 0, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                                }
                                else if (oCFLEvento.ChooseFromListUID == CFL_MAC)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    oDbDataSource.SetValue(matrixMachineCodeUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                    oDbDataSource.SetValue(matrixMachineNameUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.Name, 0).ToString());

                                    oMatrix.LoadFromDataSource();
                                    oMatrix.Columns.Item(matrixMachineCodeUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                    clsVariables.boolCFLSelected = true;
                                    SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                    clsVariables.ColNo = oPos.ColumnIndex;
                                    clsVariables.RowNo = oPos.rowIndex;
                                }
                                else if (oCFLEvento.ChooseFromListUID == CFL_MWHS)
                                {
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    oDbDataSource.SetValue(matrixWhsCodeUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.WhsCode, 0).ToString());
                                    oMatrix.LoadFromDataSource();
                                    oMatrix.Columns.Item(matrixWhsCodeUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                    clsVariables.boolCFLSelected = true;
                                    SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                    clsVariables.ColNo = oPos.ColumnIndex;
                                    clsVariables.RowNo = oPos.rowIndex;
                                }
                                else if (oCFLEvento.ChooseFromListUID == CFL_REC)
                                {
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    oDbDataSource.SetValue(receiptNoUDF, 0, oDataTable.GetValue(CommonFields.DocNum, 0).ToString());
                                    oDbDataSource.SetValue(receiptEntryUDF, 0, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());
                                    DateTime docDate = DateTime.Parse(oDataTable.GetValue(CommonFields.DocDate, 0).ToString());
                                    oDbDataSource.SetValue(receiptDateUDF, 0, objclsComman.ConvertDateToSAPDateFormat(docDate));
                                    string whsCode = objclsComman.SelectRecord("SELECT TOP 1 \"" + CommonFields.WhsCode + "\" FROM IGN1 WHERE \"" + CommonFields.DocEntry + "\" = '" + oDataTable.GetValue(CommonFields.DocEntry, 0).ToString() + "' ");

                                    oDbDataSource.SetValue(whsCodeUDF, 0, whsCode);
                                }

                            }
                            catch (Exception ex)
                            {
                                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: et_ChooseFromList" + ex.Message);
                                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: et_ChooseFromList" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formTypeEx)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypeEx && pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString();
                                    if (code.Trim() == string.Empty)
                                    {
                                        LoadForm(Convert.ToString((int)SAPMenuEnum.AddRecord));
                                        return;
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "Series")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                    if (oCombo.Value == null)
                                    {

                                    }
                                    else
                                    {
                                        int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                        string docNum = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), objType).ToString();
                                        oDBDataSource.SetValue(CommonFields.DocNum, 0, Convert.ToString(docNum));
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "DocDate")
                            {
                                objclsComman.FillCombo_Series_Custom(oForm, objType, pVal.ItemUID, "Load");
                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                if (oCombo.ValidValues.Count == 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(CommonFields.DocNum, 0, string.Empty);
                                }
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;

                        AddRow(matrixUID, rowTable, matrixPrimaryUDF);

                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID, rowTable, matrixPrimaryUDF);
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  \"DocEntry\" ='" + docEntry + "' AND IFNULL(\"" + matrixPrimaryUDF + "\",'')=''");
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        //DisableControls(BusinessObjectInfo.FormUID);
                        string itDocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(itDocEntryUDF, 0);
                        if (itDocEntry != string.Empty)
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                            DisableControls(oForm.UniqueID);
                        }
                        else
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                            oMatrix.LoadFromDataSource();
                            EnableControls(oForm.UniqueID);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        private void LoadForm(string MenuID)
        {
            try
            {
                clsVariables.boolCFLSelected = false;
                if (MenuID == formMenuUID)
                {
                    objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                    if (oMatrix.VisualRowCount == 0)
                    {
                        oMatrix.AddRow(1, 1);
                    }
                    oMatrix.CommonSetting.EnableArrowKey = true;

                    oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixShiftUID, 1);
                    objclsComman.FillCombo(oCombo, "SELECT \"Code\",\"Name\" FROM \"@SHIFTMASTER\"");

                    oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixScrapTypeUID, 1);
                    objclsComman.FillCombo(oCombo, "SELECT \"Code\",\"Name\" FROM \"@SCRAPTYPEMASTER\"");
                }
                oForm = oApplication.Forms.ActiveForm;
                EnableControls(oForm.UniqueID);

                #region Series And DocNum

                try
                {
                    oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                    oEdit.String = "t";

                    objclsComman.FillCombo_Series_Custom(oForm, objType, "DocDate", "Load");

                    #region Set DocNum
                    string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    if (defaultseries == string.Empty)
                    {
                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                        defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                    }
                    string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                    #endregion

                }
                catch { }
                #endregion

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }

                oItem = oForm.Items.Item("DocNum");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item("DocEntry");
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item("Series");
                oItem.EnableinAddMode();

                oItem = oForm.Items.Item(itDocNumUID);
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item(receiptNoUID);
                oItem.EnableinAddMode();
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsComman.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void DisableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), false);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), false);
            //oForm.Items.Item(woDocNumItemUID).Disable();
        }
        private void EnableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
            // oForm.Items.Item(woDocNumItemUID).Enable();
        }



        private void CreateIT(string DocEntry)
        {

            SAPbobsCOM.StockTransfer oDoc = (SAPbobsCOM.StockTransfer)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oStockTransfer);
            oDoc.DocDate = DateTime.Now;
            SAPbobsCOM.Recordset oRs = null;
            try
            {
                sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT T0.\"" + whsCodeUDF + "\" AS \"FromWhsCode\",T1.\"" + matrixProductCodeUDF + "\",T1.\"" + matrixWhsCodeUDF + "\" ");
                sbQuery.Append(" ,T0.\"" + receiptEntryUDF + "\",T2.\"" + CommonFields.ManBtchNum + "\" ,T1.\"" + matrixBatchUDF + "\" ");
                sbQuery.Append(" ,SUM(T1.\"" + matrixQuantityUDF + "\") " + matrixQuantityUDF + " ");
                sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
                sbQuery.Append(" INNER JOIN \"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
                sbQuery.Append(" INNER JOIN \"OITM\" T2 ON T1.\"" + matrixProductCodeUDF + "\" = T2.\"" + CommonFields.ItemCode + "\" ");
                sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' ");
                sbQuery.Append(" GROUP BY T0.\"" + whsCodeUDF + "\",T1.\"" + matrixProductCodeUDF + "\" ");
                sbQuery.Append(" ,T0.\"" + receiptEntryUDF + "\",T2.\"" + CommonFields.ManBtchNum + "\",T1.\"" + matrixWhsCodeUDF + "\",T1.\"" + matrixBatchUDF + "\"  ");

                oRs = objclsComman.returnRecord(sbQuery.ToString());
                string fromWarehouseCode = oRs.Fields.Item("FromWhsCode").Value.ToString();
                string itemCode = oRs.Fields.Item(matrixProductCodeUDF).Value.ToString();
                string receiptDocEntry = oRs.Fields.Item(receiptEntryUDF).Value.ToString();
                string toWarehouseCode = oRs.Fields.Item(matrixWhsCodeUDF).Value.ToString();
                string stockQuantity = oRs.Fields.Item(matrixQuantityUDF).Value.ToString() == string.Empty ? "0" : oRs.Fields.Item(matrixQuantityUDF).Value.ToString();
                double dblStockQuantity = double.Parse(stockQuantity);
                if (itemCode == string.Empty)
                {
                    oApplication.StatusBar.SetText("Item can't be blank", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    return;
                }
                if (toWarehouseCode == string.Empty)
                {
                    oApplication.StatusBar.SetText("Row level warehouse can't be blank", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    return;
                }
                if (dblStockQuantity == 0)
                {
                    oApplication.StatusBar.SetText("Stock quantity can't be zero", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    return;
                }
                int i = oApplication.MessageBox("Do you really want to Create Inventory Transfer", 1, "Yes", "No");
                if (i == 2)
                {
                    return;
                }

                oDoc.FromWarehouse = fromWarehouseCode;
                oDoc.ToWarehouse = toWarehouseCode;

                oDoc.Lines.ItemCode = oRs.Fields.Item(matrixProductCodeUDF).Value.ToString();
                oDoc.Lines.WarehouseCode = toWarehouseCode;
                oDoc.Lines.Quantity = dblStockQuantity;
                if (oRs.Fields.Item(CommonFields.ManBtchNum).Value.ToString() == "Y")
                {
                    oDoc.Lines.SetCurrentLine(0);
                    oDoc.Lines.BatchNumbers.BatchNumber = oRs.Fields.Item(matrixBatchUDF).Value.ToString(); //objclsComman.SelectRecord(objclsComman.GetBatchNoQuery(itemCode, receiptDocEntry, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry)));
                    oDoc.Lines.BatchNumbers.Quantity = dblStockQuantity;
                    oDoc.Lines.BatchNumbers.Add();
                }

                int retVal = oDoc.Add();
                if (retVal != 0)
                {
                    oApplication.StatusBar.SetText("Create Inventory Transfer Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                }
                else
                {
                    string newDocEntry = oCompany.GetNewObjectKey();
                    string newDocNum = objclsComman.SelectRecord("SELECT \"DocNum\" FROM OWTR WHERE \"DocEntry\" = '" + newDocEntry + "'");
                    objclsComman.SelectRecord("UPDATE T0 SET \"" + itDocEntryUDF + "\" = '" + newDocEntry + "',\"" + itDocNumUDF + "\" = '" + newDocNum + "' FROM \"" + headerTable + "\" T0 WHERE \"DocEntry\" ='" + DocEntry + "'");
                    oApplication.StatusBar.SetText("Inventory Order Transfer " + newDocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    objclsComman.RefreshRecord();
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Create IT catch exception :" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                objclsComman.ReleaseObject(oRs);
            }
        }

        private void CreateReceiptFromProduction(string DocEntry)
        {
            oForm = oApplication.Forms.ActiveForm;
            string receiptEn = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(receiptEntryUDF, 0).Trim();
            if (receiptEn != string.Empty)
            {
                oApplication.StatusBar.SetText("Receipt From production is already created", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return;
            }
            SAPbobsCOM.Recordset oRs = null;
            string orderDataTableUID = "receiptDT";
            string lineId = string.Empty;
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.\"U_DocDate\", T0.\"U_JBEn\",T0.\"U_PrdCode\" ");
            sbQuery.Append(" ,(SELECT SUM(A.\"U_PackQty\") FROM \"" + rowTable + "\" A WHERE A.\"DocEntry\" = T0.\"DocEntry\") Quantity  ");
            sbQuery.Append(" FROM \"" + headerTable + "\" T0 ");
            sbQuery.Append(" WHERE T0.\"DocEntry\" = '" + DocEntry + "' ");

            try
            {
                oForm.DataSources.DataTables.Add(orderDataTableUID);
            }
            catch
            {
            }

            SAPbouiCOM.DataTable oDataTable = oForm.DataSources.DataTables.Item(orderDataTableUID);
            oDataTable.ExecuteQuery(sbQuery.ToString());
            try
            {
                int k = oApplication.MessageBox("Do you really want to create receipt from production?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }

                StringBuilder sbMessage = new StringBuilder();
                SAPbobsCOM.Documents receipt = (SAPbobsCOM.Documents)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenEntry);

                try
                {
                    receipt.DocDate = DateTime.Parse(oDataTable.GetValue(docDateUDF, 0).ToString());
                    receipt.Lines.BaseType = 202;
                    receipt.Lines.BaseEntry = Int32.Parse(oDataTable.GetValue(matrixJobDocEntryUDF, 0).ToString());
                    //receipt.Lines.Quantity = Quantity;
                    //receipt.Lines.WarehouseCode = WhsCode;
                    receipt.Lines.TransactionType = SAPbobsCOM.BoTransactionTypeEnum.botrntComplete;

                    int retVal = receipt.Add();
                    if (retVal != 0)
                    {
                        oApplication.StatusBar.SetText("Create Receipt From Production Error : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        sbMessage.Append(oCompany.GetLastErrorDescription());
                        sbMessage.Append(Environment.NewLine);
                    }
                    else
                    {
                        string PODocEntry = oCompany.GetNewObjectKey();
                        string PODocNum = objclsComman.SelectRecord("SELECT \"DocNum\" FROM OIGN WHERE \"DocEntry\" = '" + PODocEntry + "'");
                        objclsComman.SelectRecord("UPDATE T0 SET \"" + receiptEntryUDF + "\" = '" + PODocEntry + "',\"" + receiptNoUDF + "\" = '" + PODocNum + "' FROM \"" + rowTable + "\" T0 WHERE \"DocEntry\" ='" + DocEntry + "'");
                        oApplication.StatusBar.SetText("Production Order No " + PODocNum + " created successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    }

                }
                catch (Exception ex)
                {
                    SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                    oApplication.StatusBar.SetText("Catch1 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                }
                finally
                {

                }

                if (sbMessage.Length != 0)
                {
                    oApplication.MessageBox(sbMessage.ToString(), 1, "Ok", "", "");
                }
                objclsComman.RefreshRecord();
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText("Catch2 " + this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oDataTable != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oDataTable);
                }
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        #endregion
    }
}
