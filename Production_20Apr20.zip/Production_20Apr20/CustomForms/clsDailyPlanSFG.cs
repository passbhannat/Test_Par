using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;
using System.Data;
using System.Linq;

namespace Production
{
    class clsDailyPlanSFG : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();
        System.Data.DataTable dtSFGItems = new System.Data.DataTable();
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        const string CFL_MAC = "CFL_MAC";

        public const string formTypeEx = "DAILYPLANSFG";
        public const string formMenuUID = "DAILYPLANSFG";
        public const string objType = "DAILYPLANSFG";
        public const string headerTable = "@DAILYPLANSFG";
        public const string rowTable = "@DAILYPLANSFG1";

        public const string generalServiceHeaderTable = "DAILYPLAN";
        public const string generalServiceRowTable = "DAILYPLAN1";

        const string baseProductCodeUID = "BasePrd";
        const string baseProductCodeUDF = "U_BasePrd";
        const string baseEntryUID = "BaseEn";
        const string baseEntryUDF = "U_BaseEn";
        const string baseLineUID = "BaseLine";
        const string baseLineUDF = "U_BaseLine";

        const string matrixUID = "mtx";
        const string matrixPrimaryUDF = "U_MacCode";
        const string matrixPrimaryUID = "V_0";

        const string matrixMachineCodeUDF = "U_MacCode";
        const string matrixMachineCodeUID = "V_0";
        const string matrixMachineNameUDF = "U_MacName";

        const string matrixChkUDF = "U_Chk";
        const string matrixParentProductCodeUDF = "U_PPrdCode";
        const string matrixProductCodeUDF = "U_PrdCode";
        const string matrixProductNameUDF = "U_PrdName";
        const string matrixQuantityUDF = "U_StkQty";
        const string matrixCalcQuantityUDF = "U_CalcQty";

        const string matrixProdPlanNoUDF = "U_PlanNo";
        const string matrixProdPlanEntryUDF = "U_PlanEn";
        const string matrixProdPlanEntryUID = "V_1";

        const string buttonPushToProdPlanUID = "btnPush";
        const string buttonCalculateUID = "btnCalc";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(baseEntryUDF, 0).Trim() == string.Empty)
                                    {
                                        oApplication.StatusBar.SetText("Base entry can't blank", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion

                            #region Push To Prod Plan
                            else if (pVal.ItemUID == buttonPushToProdPlanUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                PushToProdPlan(docEntry);
                            }
                            #endregion

                            #region Calculate
                            else if (pVal.ItemUID == buttonCalculateUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != SAPbouiCOM.BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok Mode", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).Trim();
                                string baseEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(baseEntryUDF, 0).Trim();
                                string baseLine = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(baseLineUDF, 0).Trim();
                                sbQuery.Length = 0;
                                sbQuery.Append(" SELECT \"" + clsDailyPlan.matrixProductCodeColumnUDF + "\" ,\"" + clsDailyPlan.matrixPackQtyColumnUDF + "\"  ");
                                sbQuery.Append(" FROM \"" + clsDailyPlan.rowTable + "\"  ");
                                sbQuery.Append(" WHERE \"" + CommonFields.DocEntry + "\" = '" + baseEntry + "' AND  \"" + CommonFields.LineId + "\" = '" + baseLine + "' ");

                                SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
                                string dpFGItemCode = oRs.Fields.Item(clsDailyPlan.matrixProductCodeColumnUDF).Value;
                                string dpPackQty = oRs.Fields.Item(clsDailyPlan.matrixPackQtyColumnUDF).Value.ToString();
                                string packQty = "";
                                string bomHeaderQty = "";

                                oMatrix = oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                for (int i = 0; i < oDbDataSource.Size; i++)
                                {
                                    string itemCode = oDbDataSource.GetValue(matrixProductCodeUDF, i).ToString();
                                    string parentItemCode = oDbDataSource.GetValue(matrixParentProductCodeUDF, i).ToString();
                                    if (dpFGItemCode == parentItemCode)
                                    {
                                        bomHeaderQty = objclsComman.SelectRecord("SELECT T0.\"Qauntity\" FROM OITT T0 WHERE T0.\"Code\" = '" + parentItemCode + "' ");
                                        packQty = dpPackQty;
                                    }
                                    else
                                    {
                                        string lineID = objclsComman.SelectRecord("SELECT T0.\"" + CommonFields.LineId + "\" FROM  \"" + rowTable + "\" T0 WHERE T0.\"DocEntry\" = '" + docEntry + "' AND T0.\"" + matrixProductCodeUDF + "\" = '" + parentItemCode + "' ");
                                        bomHeaderQty = oDbDataSource.GetValue(matrixQuantityUDF, int.Parse(lineID) - 1).ToString();
                                        packQty = oDbDataSource.GetValue(matrixCalcQuantityUDF, int.Parse(lineID) - 1).ToString();

                                    }
                                    double dblPackQty = double.Parse(packQty);
                                    double dblBOMQty = double.Parse(bomHeaderQty);
                                    string scrapRate = objclsComman.SelectRecord(" SELECT \"" + clsDailyPlan.Budgted_Scrap_RateUDF + "\" FROM OITM WHERE \"ItemCode\" ='" + itemCode + "'");

                                    double dblScrapRate = scrapRate == string.Empty ? 1 : double.Parse(scrapRate);
                                    dblScrapRate = dblScrapRate == 0 ? 1 : dblScrapRate;

                                    double dblQuantity = double.Parse(oDbDataSource.GetValue(matrixQuantityUDF, i).ToString());
                                    double dblDPItemBOMQty = double.Parse(bomHeaderQty);

                                    double dblPart1 = (dblQuantity / dblBOMQty) * dblPackQty;
                                    double dblPart2 = ((dblQuantity / dblBOMQty) * dblPackQty) * (dblScrapRate / 100);

                                    string quantity = Convert.ToString(dblPart1 + dblPart2);
                                    oDbDataSource.SetValue(matrixCalcQuantityUDF, i, quantity);

                                }
                                oMatrix.LoadFromDataSource();
                                oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                            }
                            #endregion
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion

                        #region T_et_MATRIX_LINK_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_MATRIX_LINK_PRESSED)
                        {
                            if (pVal.ColUID == matrixProdPlanEntryUID)
                            {
                                BubbleEvent = false;

                                oForm = oApplication.Forms.Item(pVal.FormUID);

                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                string prodPlanDocEntry = oDbDataSource.GetValue(matrixProdPlanEntryUDF, pVal.Row - 1);
                                clsDailyPlan obj = new clsDailyPlan();
                                obj.LoadForm(clsDailyPlan.formMenuUID);
                                oForm = oApplication.Forms.ActiveForm;
                                oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(CommonFields.DocEntry).Specific;
                                oEdit.String = prodPlanDocEntry;
                                oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Add)).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            }

                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixMachineCodeUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string productCode = oDbDataSource.GetValue(matrixProductCodeUDF, pVal.Row - 1).Trim();
                                    string query = "Select \"" + CommonFields.Code + "\" FROM \"" + clsMachineMaster.rowTable + "\" WHERE \"U_PrdCode\" = '" + productCode + "'";
                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_MAC, clsMachineMaster.objType, query, CommonFields.Code, alCondVal);

                                }
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_MAC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixMachineCodeUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue(matrixMachineNameUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.Name, 0).ToString());

                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixMachineCodeUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formTypeEx)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypeEx && pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0).ToString();
                                    if (code.Trim() == string.Empty)
                                    {
                                        oApplication.ActivateMenuItem(Convert.ToString((int)SAPMenuEnum.PreviousRecord));
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "Series")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                    if (oCombo.Value == null)
                                    {

                                    }
                                    else
                                    {
                                        int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                        string docNum = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), objType).ToString();
                                        oDBDataSource.SetValue(CommonFields.DocNum, 0, Convert.ToString(docNum));
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "DocDate")
                            {
                                objclsComman.FillCombo_Series_Custom(oForm, objType, pVal.ItemUID, "Load");
                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                if (oCombo.ValidValues.Count == 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue(CommonFields.DocNum, 0, string.Empty);
                                }
                            }

                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;

                        AddRow(matrixUID, rowTable, matrixPrimaryUDF);

                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID, rowTable, matrixPrimaryUDF);
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        //DisableControls(BusinessObjectInfo.FormUID);
                        //string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.Status, 0);
                        //if (status == "C")
                        //{
                        //    oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                        //    DisableControls(oForm.UniqueID);
                        //}
                        //else
                        //{
                        //    oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                        //    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                        //    oMatrix.FlushToDataSource();
                        //    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                        //    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                        //    oMatrix.LoadFromDataSource();
                        //    EnableControls(oForm.UniqueID);
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        public void LoadForm(string MenuID)
        {
            try
            {
                clsVariables.boolCFLSelected = false;
                if (MenuID == formMenuUID)
                {
                    objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                    oForm = oApplication.Forms.ActiveForm;
                    oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                    oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                    oMatrix.CommonSetting.EnableArrowKey = true;
                    //oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixActivityColumnUID, 1);
                    //objclsComman.FillCombo(oCombo, "SELECT TaskID,Name FROM PMC6");
                }
                oForm = oApplication.Forms.ActiveForm;
                EnableControls(oForm.UniqueID);

                oItem = oForm.Items.Item(CommonFields.DocEntry);
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item(baseProductCodeUID);
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item(baseEntryUID);
                oItem.EnableinFindMode();

                oItem = oForm.Items.Item(baseLineUID);
                oItem.EnableinFindMode();
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void SetFormValues(string baseProductCode, string baseEntry, string baseLine)
        {
            string formDocEntry = objclsComman.SelectRecord("SELECT \"DocEntry\" FROM \"" + headerTable + "\" WHERE \"" + baseEntryUDF + "\" = '" + baseEntry + "' AND \"" + baseLineUDF + "\" = '" + baseLine + "' ");

            oForm = oApplication.Forms.ActiveForm;
            if (formDocEntry != string.Empty)
            {
                oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item(CommonFields.DocEntry).Specific;
                oEdit.String = formDocEntry;
                oForm.Items.Item("1").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
            }
            else
            {
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue(baseProductCodeUDF, 0, baseProductCode);
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue(baseEntryUDF, 0, baseEntry);
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue(baseLineUDF, 0, baseLine);

                dtSFGItems.Columns.Add(new System.Data.DataColumn("ItemCode", typeof(string)));
                dtSFGItems.Columns.Add(new System.Data.DataColumn("Quantity", typeof(double)));
                dtSFGItems.Columns.Add(new System.Data.DataColumn("PItemCode", typeof(string)));

                FillMatrix(baseProductCode, 1);
            }
        }

        public void FillMatrix(string itemCode, double quantity)
        {
            ArrayList Al = new ArrayList();
            ArrayList temp = new ArrayList();
            temp.Add(itemCode); //Condition Alias             
            temp.Add(quantity.ToString()); //Condition Value
            Al.Add(temp);
            InsertSFG(Al);

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
            oDbDataSource.Clear();

            var dtSFGItemsGroupBy = dtSFGItems.AsEnumerable()
               .GroupBy(r => r.Field<string>("ItemCode"))
               .Select(g =>
               {
                   var row = dtSFGItems.NewRow();
                   row["ItemCode"] = g.Key;
                   row["Quantity"] = g.Sum(r => r.Field<double>("Quantity"));
                   row["PItemCode"] = g.Max(r => r.Field<string>("PItemCode"));

                   return row;
               }).CopyToDataTable();

            for (int i = 0; i < dtSFGItemsGroupBy.Rows.Count; i++)
            {
                oDbDataSource.InsertRecord(i);
                oDbDataSource.SetValue(matrixProductCodeUDF, i, dtSFGItemsGroupBy.Rows[i]["ItemCode"].ToString());
                oDbDataSource.SetValue(matrixProductNameUDF, i, objclsComman.SelectRecord(objclsComman.GetItemName(dtSFGItemsGroupBy.Rows[i]["ItemCode"].ToString())));
                oDbDataSource.SetValue(matrixQuantityUDF, i, dtSFGItemsGroupBy.Rows[i]["Quantity"].ToString());
                oDbDataSource.SetValue(matrixParentProductCodeUDF, i, dtSFGItemsGroupBy.Rows[i]["PItemCode"].ToString());

            }
            oMatrix.LoadFromDataSource();
        }

        public void InsertSFG(ArrayList alItems)
        {
            ArrayList AlNewSFG = new ArrayList();
            ArrayList temp = new ArrayList();

            SAPbobsCOM.Recordset oRs = null;
            System.Data.DataRow dr;
            for (int i = 0; i < alItems.Count; i++)
            {
                string itemCode = (alItems[i] as ArrayList)[0].ToString();
                string quantity = (alItems[i] as ArrayList)[1].ToString();
                string bomHeaderQty = objclsComman.SelectRecord("SELECT T0.\"Qauntity\" FROM OITT T0 WHERE T0.\"Code\"='" + itemCode + "'");
                oRs = objclsComman.returnRecord(objclsComman.GetSFGQuery(itemCode));
                while (!oRs.EoF)
                {
                    dr = dtSFGItems.NewRow();
                    string sfgItemCode = oRs.Fields.Item("Code").Value;
                    string sfgQuantity = oRs.Fields.Item("Quantity").Value.ToString();
                    double qty = double.Parse(quantity) * (double.Parse(sfgQuantity) / double.Parse(bomHeaderQty));
                    dr["ItemCode"] = sfgItemCode;
                    if (dtSFGItems.Rows.Count == 0)
                    {
                        dr["Quantity"] = sfgQuantity.ToString();
                    }
                    else
                    {
                        dr["Quantity"] = qty.ToString();
                    }
                    dr["PItemCode"] = itemCode;

                    dtSFGItems.Rows.Add(dr);

                    temp = new ArrayList();
                    temp.Add(sfgItemCode); //Condition Alias             
                    temp.Add(sfgQuantity); //Condition Value
                    AlNewSFG.Add(temp);
                    oRs.MoveNext();
                }
            }
            if (AlNewSFG.Count > 0)
            {
                InsertSFG(AlNewSFG);
            }
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsComman.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void DisableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            //oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), false);
            //oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), false);
            //oForm.Items.Item(woDocNumItemUID).Disable();
        }
        private void EnableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            //oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
            //oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
            // oForm.Items.Item(woDocNumItemUID).Enable();
        }

        public void PushToProdPlan(string formDocEntry)
        {
            //SAPbobsCOM.Recordset oRs = null;
            bool recordUpdatedSuccessfully = false;
            SAPbobsCOM.Recordset oRs = null;
            SAPbobsCOM.Recordset oRsProdPlan = null;

            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.\"" + CommonFields.LineId + "\" AS \"SFG_LineId\",T0.\"" + matrixMachineCodeUDF + "\",  T0.\"" + matrixProductCodeUDF + "\" ,  T0.\"" + matrixQuantityUDF + "\",  T0.\"" + matrixCalcQuantityUDF + "\" ");
            sbQuery.Append(" ,T2.\"" + clsDailyPlan.matrixAdviceNoColumnUDF + "\", T2.\"" + clsDailyPlan.matrixAdviceDocEntryColumnUDF + "\", T2.\"" + clsDailyPlan.matrixAdviceDateColumnUDF + "\" ");
            sbQuery.Append(" ,T2.\"" + clsDailyPlan.matrixNumPerMsColumnUDF + "\",T2.\"" + clsDailyPlan.matrixPackQtyColumnUDF + "\" ,T2.\"" + clsDailyPlan.matrixPackUnitColumnUDF + "\"  ");
            sbQuery.Append(" ,T3.\"" + CommonFields.DocEntry + "\" AS \"ProdPlanDocEntry\",T3.\"" + CommonFields.DocNum + "\" AS \"ProdPlanDocNum\" ");
            sbQuery.Append(" ,T4.\"" + CommonFields.InvntryUom + "\", T4.\"" + CommonFields.OnHand + "\", T4.\"" + clsDailyPlan.Budgted_Scrap_RateUDF + "\" , T5.\"" + clsDailyPlan.Budgted_Scrap_RateUDF + "\" AS \"FG_Budgted_Scrap_Rate\" ");
            sbQuery.Append(" ,T2.\"" + clsDailyPlan.matrixPOEnColumnUDF + "\" ,T2.\"" + clsDailyPlan.matrixPONoColumnUDF + "\" ");
            sbQuery.Append(" ,T2.\"" + clsDailyPlan.matrixSOQuantityColumnUDF + "\" ,T2.\"" + clsDailyPlan.matrixQuantityColumnUDF + "\" AS \"DPItemQty\" ,T2.\"" + clsDailyPlan.matrixProductCodeColumnUDF + "\" AS \"DPItemCode\" ");
            sbQuery.Append(" ,T0.\"" + matrixParentProductCodeUDF + "\"   ");

            sbQuery.Append(" FROM \"" + rowTable + "\" T0 ");
            sbQuery.Append(" INNER JOIN \"" + headerTable + "\" T1 ON  T0.\"" + CommonFields.DocEntry + "\" = T1.\"" + CommonFields.DocEntry + "\" ");
            sbQuery.Append(" INNER JOIN \"" + clsDailyPlan.rowTable + "\" T2 ON  T1.\"" + baseEntryUDF + "\" = T2.\"" + CommonFields.DocEntry + "\" AND T1.\"" + baseLineUDF + "\" = T2.\"" + CommonFields.LineId + "\" ");
            sbQuery.Append(" INNER JOIN \"" + clsDailyPlan.headerTable + "\" T3 ON  T0.\"" + matrixMachineCodeUDF + "\" = T3.\"" + matrixMachineCodeUDF + "\" ");
            sbQuery.Append(" INNER JOIN \"" + CommonTables.ItemMasterData + "\" T4 ON T0.\"" + matrixProductCodeUDF + "\" = T4.\"" + CommonFields.ItemCode + "\" ");
            sbQuery.Append(" INNER JOIN \"" + CommonTables.ItemMasterData + "\" T5 ON T1.\"" + baseProductCodeUDF + "\" = T5.\"" + CommonFields.ItemCode + "\" ");

            sbQuery.Append(" WHERE T0.\"" + CommonFields.DocEntry + "\"='" + formDocEntry + "' AND T0.\"" + matrixChkUDF + "\" = 'Y' ");
            if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
            {
                sbQuery.Append(" AND IFNULL(T0.\"" + matrixProdPlanEntryUDF + "\",'') = '' ");
            }
            oRs = objclsComman.returnRecord(sbQuery.ToString());
            try
            {
                if (oRs.RecordCount == 0)
                {
                    oApplication.StatusBar.SetText("No Production Plan to create", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                    return;
                }
                int k = oApplication.MessageBox("Do you really want to proceed?", 1, "Yes", "No", "");
                if (k == 2)
                {
                    return;
                }

                while (!oRs.EoF)
                {
                    string calcQty = oRs.Fields.Item(matrixCalcQuantityUDF).Value.ToString();
                    calcQty = calcQty == string.Empty ? "0" : calcQty;
                    if (double.Parse(calcQty) == 0)
                    {
                        oApplication.StatusBar.SetText("Calculated quantity should not be 0. Please press calculate button", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        continue;
                    }
                    string lineId = oRs.Fields.Item("SFG_LineId").Value.ToString();
                    string prodPlanDocEntry = oRs.Fields.Item("ProdPlanDocEntry").Value.ToString();
                    string prodPlanDocNum = oRs.Fields.Item("ProdPlanDocNum").Value.ToString();
                    string itemCode = oRs.Fields.Item(matrixProductCodeUDF).Value.ToString();
                    string macCode = oRs.Fields.Item(matrixMachineCodeUDF).Value.ToString();
                    //string parentItemCode = oRs.Fields.Item(matrixParentProductCodeUDF).Value.ToString();
                    //string fgItemCode = oRs.Fields.Item("DPItemCode").Value.ToString();
                    //string fgScrapRate = oRs.Fields.Item("FG_Budgted_Scrap_Rate").Value.ToString();
                    //string scrapRate = oRs.Fields.Item(clsDailyPlan.Budgted_Scrap_RateUDF).Value.ToString();
                    //string bomHeaderQty = "";
                    //if (fgItemCode == parentItemCode)
                    //{
                    //    bomHeaderQty = objclsComman.SelectRecord("SELECT T0.\"Qauntity\" FROM OITT T0 WHERE T0.\"Code\" = '" + fgItemCode + "' ");
                    //}
                    //else
                    //{
                    //    bomHeaderQty = objclsComman.SelectRecord("SELECT T0.\"" + matrixQuantityUDF + "\" FROM  \"" + rowTable + "\" T0 WHERE T0.\"DocEntry\" = '" + formDocEntry + "' AND T0.\"" + matrixProductCodeUDF + "\" = '" + parentItemCode + "' ");
                    //}
                    //double dblFGScrapRate = fgScrapRate == string.Empty ? 1 : double.Parse(fgScrapRate);
                    //dblFGScrapRate = dblFGScrapRate == 0 ? 1 : dblFGScrapRate;

                    //double dblScrapRate = scrapRate == string.Empty ? 1 : double.Parse(scrapRate);
                    //dblScrapRate = dblScrapRate == 0 ? 1 : dblScrapRate;

                    //double dblQuantity = double.Parse(oRs.Fields.Item(matrixQuantityUDF).Value.ToString());
                    //double dblDPItemQty = double.Parse(oRs.Fields.Item("DPItemQty").Value.ToString());
                    //double dblPackQty = double.Parse(oRs.Fields.Item(clsDailyPlan.matrixPackQtyColumnUDF).Value.ToString());
                    //double dblDPItemBOMQty = double.Parse(bomHeaderQty);

                    //double dblPart1 = (dblQuantity / dblDPItemBOMQty) * dblPackQty;
                    //double dblPart2 = ((dblQuantity / dblDPItemBOMQty) * dblPackQty) * (dblScrapRate / 100);

                    ////double dblSFGPackQtyPercentage = dblQuantity * (dblScrapRate / 100) * (dblFGScrapRate / 100);
                    //string quantity = Convert.ToString(dblPart1 + dblPart2);//Convert.ToString(dblSFGPackQtyPercentage + dblQuantity);

                    string capacity = "";
                    sbQuery.Length = 0;
                    sbQuery.Append(" SELECT \"U_Cap\" ");
                    sbQuery.Append(" FROM \"" + clsMachineMaster.rowTable + "\" ");
                    sbQuery.Append(" WHERE \"" + CommonFields.Code + "\" = '" + macCode + "' ");
                    sbQuery.Append(" AND \"" + matrixProductCodeUDF + "\" = '" + itemCode + "' ");
                    SAPbobsCOM.Recordset oRsMachine = objclsComman.returnRecord(sbQuery.ToString());
                    if (oRsMachine.RecordCount > 0)
                    {
                        capacity = oRsMachine.Fields.Item("U_Cap").Value.ToString();
                    }
                    #region Adding Record in UDO

                    try
                    {
                        SAPbobsCOM.GeneralService oGeneralService;
                        SAPbobsCOM.GeneralData oGeneralData;
                        SAPbobsCOM.GeneralDataParams oGeneralParams;
                        SAPbobsCOM.CompanyService oCompService;
                        SAPbobsCOM.GeneralData oChild;
                        SAPbobsCOM.GeneralDataCollection oChildren;
                        oCompService = oCompany.GetCompanyService();

                        oGeneralService = oCompService.GetGeneralService(generalServiceHeaderTable);
                        oGeneralParams = (SAPbobsCOM.GeneralDataParams)oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralDataParams);
                        oGeneralParams.SetProperty(CommonFields.DocEntry, prodPlanDocEntry);

                        oGeneralData = oGeneralService.GetByParams(oGeneralParams);

                        // Adding data to Detail Line
                        oChildren = oGeneralData.Child(generalServiceRowTable);
                        oChild = oChildren.Add();
                        oChild.SetProperty(clsDailyPlan.matrixAdviceNoColumnUDF, oRs.Fields.Item(clsDailyPlan.matrixAdviceNoColumnUDF).Value.ToString());
                        oChild.SetProperty(clsDailyPlan.matrixAdviceDocEntryColumnUDF, oRs.Fields.Item(clsDailyPlan.matrixAdviceDocEntryColumnUDF).Value.ToString());
                        oChild.SetProperty(clsDailyPlan.matrixProductCodeColumnUDF, oRs.Fields.Item(matrixProductCodeUDF).Value.ToString());
                        //oChild.SetProperty(clsDailyPlan.matrixWhsCodeColumnUDF, oRs.Fields.Item("ProdPlanWhsCode").Value.ToString());
                        oChild.SetProperty(clsDailyPlan.matrixAdviceDateColumnUDF, oRs.Fields.Item(clsDailyPlan.matrixAdviceDateColumnUDF).Value.ToString());
                        oChild.SetProperty(clsDailyPlan.matrixSOQuantityColumnUDF, oRs.Fields.Item(clsDailyPlan.matrixSOQuantityColumnUDF).Value.ToString());
                        oChild.SetProperty(clsDailyPlan.matrixQuantityColumnUDF, calcQty);
                        oChild.SetProperty(clsDailyPlan.matrixPackQtyColumnUDF, calcQty);
                        //oChild.SetProperty(clsDailyPlan.matrixBaseQtyColumnUDF, calcQty);
                        oChild.SetProperty(clsDailyPlan.matrixPackUnitColumnUDF, oRs.Fields.Item(clsDailyPlan.matrixPackUnitColumnUDF).Value.ToString());
                        oChild.SetProperty(clsDailyPlan.matrixStockQtyColumnUDF, oRs.Fields.Item(CommonFields.OnHand).Value.ToString());
                        oChild.SetProperty(clsDailyPlan.matrixStockUnitColumnUDF, oRs.Fields.Item(CommonFields.InvntryUom).Value.ToString());
                        oChild.SetProperty(clsDailyPlan.matrixCapacityColumnUDF, capacity);
                        oChild.SetProperty(clsDailyPlan.matrixNumPerMsColumnUDF, oRs.Fields.Item(clsDailyPlan.matrixNumPerMsColumnUDF).Value.ToString());
                        oChild.SetProperty(clsDailyPlan.matrixBPONoUDF, oRs.Fields.Item(clsDailyPlan.matrixPONoColumnUDF).Value.ToString());
                        oChild.SetProperty(clsDailyPlan.matrixBPOEnUDF, oRs.Fields.Item(clsDailyPlan.matrixPOEnColumnUDF).Value.ToString());

                        oGeneralService.Update(oGeneralData);

                        sbQuery.Length = 0;
                        sbQuery.Append(" UPDATE T0 ");
                        sbQuery.Append(" SET \"" + matrixProdPlanEntryUDF + "\" = '" + prodPlanDocEntry + "',\"" + matrixProdPlanNoUDF + "\" = '" + prodPlanDocNum + "'  ");
                        sbQuery.Append(" FROM \"" + rowTable + "\" T0 ");
                        sbQuery.Append(" WHERE \"DocEntry\" ='" + formDocEntry + "' AND \"LineId\" = '" + lineId + "' ");
                        objclsComman.SelectRecord(sbQuery.ToString());
                        recordUpdatedSuccessfully = true;
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                    #endregion

                    oRs.MoveNext();
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
            finally
            {
                if (oRs != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                }
                if (oRsProdPlan != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oRsProdPlan);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            if (recordUpdatedSuccessfully == true)
            {
                objclsComman.RefreshRecord();
            }
        }

        public void a()
        {
            SAPbobsCOM.GeneralService oGeneralService = null;
            SAPbobsCOM.GeneralData oGeneralData = null;
            SAPbobsCOM.GeneralDataParams oGeneralParams = null;
            SAPbobsCOM.CompanyService oCompService = null;
            SAPbobsCOM.GeneralData oChild = null;
            SAPbobsCOM.GeneralDataCollection oChildren = null;
            oCompService = oCompany.GetCompanyService();
            try
            {
                oGeneralService = oCompService.GetGeneralService("UDOName");
                // Get UDO record               
                oGeneralParams = ((SAPbobsCOM.GeneralDataParams)(oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralDataParams)));
                oGeneralParams.SetProperty("DocEntry", "");
                oGeneralData = oGeneralService.GetByParams(oGeneralParams);
                // Add lines on UDO Child Table              
                oChildren = oGeneralData.Child("ChildTableNameWithout@");
                // Create data for rows in the child table                
                oChild = oChildren.Add();
                oChild.SetProperty("colUID", "TEST");
                // Update an existing line               
                oChild = oChildren.Item(1);
                oChild.SetProperty("colUID", "TEST");
                //Update the UDO Record              
                oGeneralService.Update(oGeneralData);
            }
            catch (Exception ex)
            {
                oApplication.MessageBox(ex.Message, 1, "OK", null, null);
            }
        }

        #endregion
    }
}
