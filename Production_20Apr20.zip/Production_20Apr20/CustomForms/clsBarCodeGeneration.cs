using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;

namespace Production
{
    class clsBarCodeGeneration : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;

        const string formTypeEx = "BARCODEGEN";
        const string formMenuUID = "BARCODEGEN";
        const string objType = "BARCODEGEN";
        const string matrixUID = "mtx";

        public const string headerTable = "@BARCODEGEN";
        public const string rowTable = "@BARCODEGEN1";

        const string CFL_JC = "CFL_JC";
        const string CFL_ITEM = "CFL_ITEM";
        const string CFL_REC = "CFL_REC";

        const string buttonGenerateBarCode = "btnGen";
        public const string fromBarCodeNoUDF = "U_FrBar";
        public const string toBarCodeNoUDF = "U_ToBar";
        const string noOfBarCodeUDF = "U_NoofBar";
        const string noOfBarCodeUID = "NoofBar";


        const string matrixPrimaryColumnUDF = "U_BarCode";
        const string matrixPrimaryColumnUID = "V_7";

        const string matrixBarCodeColumnUDF = "U_BarCode";
        const string matrixBarCodeColumnUID = "V_7";

        const string matrixPrintedByColumnUDF = "U_PrBy";
        const string matrixPrintedByColumnUID = "V_4";

        const string matrixIssuedByColumnUDF = "U_IssBy";
        const string matrixIssuedByColumnUID = "V_2";

        //const string matrixUsedByColumnUDF = "U_UsedBy";
        //const string matrixUsedByColumnUID = "V_1";

        const string matrixJobNoColumnUDF = "U_JBNo";
        const string matrixJobNoColumnUID = "V_11";
        const string matrixJobEntryColumnUDF = "U_JBEn";
        const string matrixJobDateColumnUDF = "U_JBDate";

        const string matrixRecNoColumnUDF = "U_RecNo";
        const string matrixRecNoColumnUID = "V_15";
        const string matrixRecEntryColumnUDF = "U_RecEn";

        const string matrixProductCodeColumnUID = "V_17";
        const string matrixProductCodeColumnUDF = "U_PrdCode";
        const string matrixProductNameColumnUDF = "U_PrdName";


        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank. Please select series.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion

                            #region Generate BarCode
                            else if (pVal.ItemUID == buttonGenerateBarCode)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);

                                string fromBarCodeNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(fromBarCodeNoUDF, 0).Trim();
                                string toBarCodeNo = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(toBarCodeNoUDF, 0).Trim();
                                if (fromBarCodeNo == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please enter From BarCode No", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                if (toBarCodeNo == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please enter To BarCode No", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                int k = oApplication.MessageBox("Do you really want to Generate barcodes", 1, "Yes", "No");
                                if (k == 1)
                                {
                                    oForm.Freeze(true);
                                    try
                                    {
                                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                        oMatrix.Clear();
                                        oMatrix.FlushToDataSource();
                                        oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                        oDbDataSource.Clear();
                                        Int32 iFromBarCodeNo = Int32.Parse(fromBarCodeNo);
                                        Int32 iToBarCodeNo = Int32.Parse(toBarCodeNo);

                                        int rowNo = 0;
                                        for (Int32 i = iFromBarCodeNo; i <= iToBarCodeNo; i++)
                                        {
                                            DateTime currentDate = DateTime.Now;
                                            string barcode = currentDate.Year.ToString().Substring(2, 2) + currentDate.Month.ToString().PadLeft(2, '0') + i.ToString().PadLeft(6, '0');
                                            if (isBarCodeAlreadyAdded(barcode) == true)
                                            {
                                                oApplication.StatusBar.SetText(" BarCode (" + barcode + ") already added", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                return;
                                            }

                                            oDbDataSource.InsertRecord(rowNo);
                                            oDbDataSource.SetValue(matrixBarCodeColumnUDF, rowNo, barcode);
                                            oDbDataSource.SetValue(CommonFields.LineId, rowNo, (rowNo + 1).ToString());

                                            oDbDataSource.SetValue("U_CrDate", rowNo, objclsComman.ConvertDateToSAPDateFormat(DateTime.Now));

                                            rowNo++;
                                        }
                                        oMatrix.LoadFromDataSource();
                                    }
                                    finally
                                    {
                                        oForm.Freeze(false);
                                    }
                                }
                            }
                            #endregion

                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == matrixRecNoColumnUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string jobEntry = oDbDataSource.GetValue(matrixJobEntryColumnUDF, 0).Trim();
                                    ArrayList alCondVal = new ArrayList();
                                    ArrayList temp = new ArrayList();
                                    string receiptRowTable = "IGN1";
                                    //temp = new ArrayList();
                                    //temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                                    //temp.Add(CommonFields.ItemCode); //Condition Alias             
                                    //temp.Add(machineCode); //Condition Value
                                    //temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                                    //alCondVal.Add(temp);
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                    string query = "Select \"BaseEntry\" FROM \"" + receiptRowTable + "\" WHERE \"DocEntry\" = '" + jobEntry + "'";
                                    objclsComman.AddChooseFromList_WithCond(oForm, CFL_REC, Convert.ToString((int)SAPbobsCOM.BoObjectTypes.oInventoryGenEntry), query, CommonFields.DocEntry, alCondVal);
                                }
                            }
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == CFL_JC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixJobNoColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocNum, 0).ToString());
                                oDbDataSource.SetValue(matrixJobEntryColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());
                                oDbDataSource.SetValue(matrixProductCodeColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue(matrixProductNameColumnUDF, pVal.Row - 1, objclsComman.SelectRecord(objclsComman.GetItemName(oDataTable.GetValue(CommonFields.ItemCode, 0).ToString())));


                                DateTime docDate = DateTime.Parse(oDataTable.GetValue(CommonFields.PostDate, 0).ToString());
                                oDbDataSource.SetValue(matrixJobDateColumnUDF, pVal.Row - 1, objclsComman.ConvertDateToSAPDateFormat(docDate));
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixJobNoColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_ITEM)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixProductCodeColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue(matrixProductNameColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixProductCodeColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_REC)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixRecNoColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocNum, 0).ToString());
                                oDbDataSource.SetValue(matrixRecEntryColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.DocEntry, 0).ToString());
                                oMatrix.LoadFromDataSource();

                                oMatrix.Columns.Item(matrixRecNoColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formTypeEx)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypeEx && pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocNum, 0).ToString();
                                    if (code.Trim() == string.Empty)
                                    {
                                        LoadForm(Convert.ToString((int)SAPMenuEnum.AddRecord));
                                        return;
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            if (pVal.ItemUID == "Series")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                    if (oCombo.Value == null)
                                    {

                                    }
                                    else
                                    {
                                        int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                        string docNum = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), objType).ToString();
                                        oDBDataSource.SetValue(CommonFields.DocNum, 0, Convert.ToString(docNum));
                                    }
                                }
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "DocDate")
                            {
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    objclsComman.FillCombo_Series_Custom(oForm, objType, pVal.ItemUID, "Load");
                                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                    if (oCombo.ValidValues.Count == 0)
                                    {
                                        oForm.DataSources.DBDataSources.Item(headerTable).SetValue(CommonFields.DocNum, 0, string.Empty);
                                    }
                                }
                            }
                            else if (pVal.ItemUID == noOfBarCodeUID)
                            {
                                string noOfBarCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(noOfBarCodeUDF, 0).Trim();
                                string fromBarCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(fromBarCodeNoUDF, 0).Trim();

                                int iNoOfBarCode = noOfBarCode == string.Empty ? 0 : int.Parse(noOfBarCode);
                                Int32 iFromNoOfBarCode = fromBarCode == string.Empty ? 0 : Int32.Parse(fromBarCode);
                                Int32 iToOfBarCode = iFromNoOfBarCode + iNoOfBarCode - 1;
                                oForm.DataSources.DBDataSources.Item(headerTable).SetValue(toBarCodeNoUDF, 0, iToOfBarCode.ToString());

                                //if (pVal.ColUID == matrixGrossWtUID || pVal.ColUID == matrixTareWtUID)
                                //{
                                //    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                //    oMatrix.FlushToDataSource();
                                //    oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);

                                //    oMatrix.LoadFromDataSource();
                                //}
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {

                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                    else if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        return;
                    }
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                        if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  IFNULL(\"" + matrixPrimaryColumnUDF + "\",'')='' AND \"DocEntry\" = '" + docEntry + "'");
                        }
                        else
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  ISNULL(\"" + matrixPrimaryColumnUDF + "\",'')='' AND \"DocEntry\" = '" + docEntry + "'");
                        }
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        //DisableControls(BusinessObjectInfo.FormUID);
                        string status = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.Status, 0);
                        if (status == "C")
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_VIEW_MODE;
                            DisableControls(oForm.UniqueID);
                        }
                        else
                        {
                            oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                            oMatrix.FlushToDataSource();
                            oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                            oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                            oMatrix.LoadFromDataSource();
                            EnableControls(oForm.UniqueID);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        private void LoadForm(string MenuID)
        {
            clsVariables.boolCFLSelected = false;
            if (MenuID == formMenuUID)
            {
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                oForm = oApplication.Forms.ActiveForm;
                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix.CommonSetting.EnableArrowKey = true;

                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixPrintedByColumnUID, 1);
                objclsComman.FillCombo(oCombo, "SELECT \"USERID\",\"U_NAME\" FROM OUSR");

                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixIssuedByColumnUID, 1);
                objclsComman.FillCombo(oCombo, "SELECT \"USERID\",\"U_NAME\" FROM OUSR");

                //oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific(matrixUsedByColumnUID, 1);
                //objclsComman.FillCombo(oCombo, "SELECT \"USERID\",\"U_NAME\" FROM OUSR");
                string addonName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name; //New Menu Name in Add-on Layouts

                string ReportType = objclsComman.SelectRecord("SELECT \"CODE\" FROM RTYP WHERE \"MNU_ID\" = '" + MenuID + "' AND \"ADD_NAME\" = '" + addonName + "'");
                if (ReportType != string.Empty)
                {
                    oForm.ReportType = ReportType; //(Code of RTYP table)
                }
            }
            oForm = oApplication.Forms.ActiveForm;
            EnableControls(oForm.UniqueID);

            #region Series And DocNum

            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                oEdit.String = "t";

                objclsComman.FillCombo_Series_Custom(oForm, objType, "DocDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                #endregion

            }
            catch { }
            #endregion

            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }

            oItem = oForm.Items.Item("DocNum");
            oItem.EnableinFindMode();

            oItem = oForm.Items.Item("DocEntry");
            oItem.EnableinFindMode();

            oItem = oForm.Items.Item("Series");
            oItem.EnableinAddMode();

            string barCodeNo = AutoBarCodeNo();
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue(fromBarCodeNoUDF, 0, barCodeNo);
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsComman.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private void DisableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), false);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), false);
            //oForm.Items.Item(woDocNumItemUID).Disable();
        }
        private void EnableControls(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);
            // oForm.Items.Item(woDocNumItemUID).Enable();
        }

        private string AutoBarCodeNo()
        {
            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT MAX(CAST(\"" + toBarCodeNoUDF + "\" AS INT)) FROM \"" + headerTable + "\" ");
            string barCodeNo = objclsComman.SelectRecord(sbQuery.ToString());
            barCodeNo = barCodeNo == string.Empty ? "1" : Convert.ToString(Int32.Parse(barCodeNo) + 1);
            return barCodeNo;
        }

        private bool isBarCodeAlreadyAdded(string barCode)
        {
            string query = "SELECT 1 FROM \"" + rowTable + "\" WHERE \"" + matrixBarCodeColumnUDF + "\" = '" + barCode + "'";
            query = objclsComman.SelectRecord(query);
            if (query == "1")
            {
                return true;
            }
            return false;
        }
        #endregion
    }
}
