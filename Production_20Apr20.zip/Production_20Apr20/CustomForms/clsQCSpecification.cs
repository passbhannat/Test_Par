using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using General;
using General.Extensions;
using General.Classes;

namespace Production
{
    class clsQCSpecification : Connection
    {
        #region Variables

        SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.ComboBox oCombo;
        const string formTypeEx = "QCSPEC";
        const string formMenuUID = "QCSPEC";
        const string objType = "QCSPEC";
        const string matrixUID = "mtx";

        public const string headerTable = "@QCSPEC";
        public const string rowTable = "@QCSPEC1";

        const string CFL_ITEM = "CFL_ITEM";
        const string CFL_PARA = "CFL_PARA";

        const string productCodeUID = "PrdCode";
        const string productCodeUDF = "U_PrdCode";
        const string productNameUDF = "U_PrdName";

        const string matrixPrimaryColumnUDF = "U_ParaCode";
        const string matrixPrimaryColumnUID = "V_7";

        const string matrixParameterCodeColumnUID = "V_7";
        const string matrixParameterCodeColumnUDF = "U_ParaCode";
        const string matrixParameterNameColumnUDF = "U_ParaName";

        StringBuilder sbQuery = new StringBuilder();
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region Add Record
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        string code = AutoNo();
                                        oForm.DataSources.DBDataSources.Item(headerTable).SetValue(CommonFields.Code, 0, code);
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion

                        #region T_et_CHOOSE_FROM_LIST
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            if (pVal.ItemUID == productCodeUID)
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);

                                ArrayList alCondVal = new ArrayList();
                                ArrayList temp = new ArrayList();
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;

                                //sbQuery.Length = 0;
                                //sbQuery.Append(" SELECT T0.\"" + CommonFields.ItemCode + "\" ");
                                //sbQuery.Append(" FROM \"" + CommonTables.ItemMasterData + "\" T0 ");
                                //sbQuery.Append(" WHERE NOT EXISTS ( ");
                                //sbQuery.Append(" SELECT  1 FROM \"" + headerTable + "\" IT0 WHERE T0.\"" + CommonFields.ItemCode + "\" = IT0.\"" + productCodeUDF + "\" )");

                                //objclsComman.AddChooseFromList_WithCond(oForm, CFL_ITEM, "4", sbQuery.ToString(), CommonFields.ItemCode, alCondVal);
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before action = true : " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }

                            if (oCFLEvento.ChooseFromListUID == CFL_ITEM)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                string isExist = objclsComman.SelectRecord("SELECT '1' FROM \"" + headerTable + "\" WHERE \"" + productCodeUDF + "\" ='" + oDataTable.GetValue(CommonFields.ItemCode, 0).ToString() + "'  ");
                                if (isExist == "1")
                                {
                                    oDbDataSource.SetValue(productCodeUDF, 0, string.Empty);
                                    oDbDataSource.SetValue(productNameUDF, 0, string.Empty);
                                    oApplication.StatusBar.SetText("Product code is already exists", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                oDbDataSource.SetValue(productCodeUDF, 0, oDataTable.GetValue(CommonFields.ItemCode, 0).ToString());
                                oDbDataSource.SetValue(productNameUDF, 0, oDataTable.GetValue(CommonFields.ItemName, 0).ToString());
                            }
                            else if (oCFLEvento.ChooseFromListUID == CFL_PARA)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                oMatrix.FlushToDataSource();
                                oDbDataSource.SetValue(matrixParameterCodeColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.Code, 0).ToString());
                                oDbDataSource.SetValue(matrixParameterNameColumnUDF, pVal.Row - 1, oDataTable.GetValue(CommonFields.Name, 0).ToString());
                                if (pVal.Row == oMatrix.RowCount)
                                {
                                    oDbDataSource.InsertRecord(oMatrix.VisualRowCount);
                                    int RowNo = 1;
                                    for (int i = 0; i < oDbDataSource.Size; i++)
                                    {
                                        oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                                        RowNo = RowNo + 1;
                                    }
                                }
                                oMatrix.LoadFromDataSource();
                                oMatrix.Columns.Item(matrixParameterCodeColumnUID).Cells.Item(pVal.Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                                clsVariables.boolCFLSelected = true;
                                SAPbouiCOM.ICellPosition oPos = oMatrix.GetCellFocus();
                                clsVariables.ColNo = oPos.ColumnIndex;
                                clsVariables.RowNo = oPos.rowIndex;
                            }
                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formTypeEx)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                if (pVal.FormTypeEx == formTypeEx && pVal.FormMode == (int)SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    string code = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.Code, 0).ToString();
                                    if (code.Trim() == string.Empty)
                                    {
                                        LoadForm(Convert.ToString((int)SAPMenuEnum.AddRecord));
                                        return;
                                    }
                                }
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message);
                        oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " Before Action = false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }

                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        AddRow(matrixUID, rowTable, matrixParameterCodeColumnUDF);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        DeleteRow(matrixUID, rowTable, matrixParameterCodeColumnUDF);
                    }

                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);

                        if (oCompany.DbServerType == SAPbobsCOM.BoDataServerTypes.dst_HANADB)
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  IFNULL(\"" + matrixParameterCodeColumnUDF + "\",'')='' AND \"DocEntry\" = '" + docEntry + "'");
                        }
                        else
                        {
                            objclsComman.SelectRecord("DELETE FROM \"" + rowTable + "\" WHERE  ISNULL(\"" + matrixParameterCodeColumnUDF + "\",'')='' AND \"DocEntry\" = '" + docEntry + "'");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region Method

        private void LoadForm(string MenuID)
        {
            clsVariables.boolCFLSelected = false;
            if (MenuID == formMenuUID)
            {
                objclsComman.LoadXML(MenuID, "Code", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                oForm = oApplication.Forms.ActiveForm;
                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);

                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                oMatrix.CommonSetting.EnableArrowKey = true;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oCombo = (SAPbouiCOM.ComboBox)oMatrix.GetCellSpecific("V_8",1);
                objclsComman.FillCombo(oCombo, "SELECT \"Code\",\"Name\" FROM \"@METHANALYSISMASTER\" ");

            }

            oForm = oApplication.Forms.ActiveForm;
            string code = AutoNo();
            oForm.DataSources.DBDataSources.Item(headerTable).SetValue(CommonFields.Code, 0, code);
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }
            oForm.Items.Item(CommonFields.Code).EnableinFindMode();
            oForm.Items.Item(productCodeUID).EnableinAddMode();
        }

        private void AddRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
                return;
            }
            oMatrix.FlushToDataSource();
            SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
            objclsComman.AddRow(oMatrix, oDBDataSource, value);
        }

        private void DeleteRow(string matrixUID, string tableName, string matrixPrimaryUDF)
        {
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(tableName);
            int RowNo = 1;
            for (int i = 0; i < oDbDataSource.Size; i++)
            {
                string value = oDbDataSource.GetValue(matrixPrimaryUDF, i).ToString().Trim();
                if (value == string.Empty)
                {
                    oDbDataSource.RemoveRecord(i);
                }
                oDbDataSource.SetValue(CommonFields.LineId, i, RowNo.ToString());
                RowNo = RowNo + 1;
            }
            oMatrix.LoadFromDataSource();
        }

        private string AutoNo()
        {
            sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT MAX(CAST(\"Code\" AS int)) FROM \"" + headerTable + "\" ");
            string planNo = objclsComman.SelectRecord(sbQuery.ToString());
            planNo = planNo == string.Empty ? "1" : Convert.ToString(Int32.Parse(planNo) + 1);
            return planNo;
        }

        #endregion
    }
}
